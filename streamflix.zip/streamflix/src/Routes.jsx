import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
import NotFound from "pages/NotFound";
import SearchResults from './pages/search-results';
import LoginPage from './pages/login';
import VideoPlayer from './pages/video-player';
import UserProfile from './pages/user-profile';
import ContentLibrary from './pages/content-library';
import Register from './pages/register';

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
      <ScrollToTop />
      <RouterRoutes>
        {/* Define your route here */}
        <Route path="/" element={<ContentLibrary />} />
        <Route path="/search-results" element={<SearchResults />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/video-player" element={<VideoPlayer />} />
        <Route path="/user-profile" element={<UserProfile />} />
        <Route path="/content-library" element={<ContentLibrary />} />
        <Route path="/register" element={<Register />} />
        <Route path="*" element={<NotFound />} />
      </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;
