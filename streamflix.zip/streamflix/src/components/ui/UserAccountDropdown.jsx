import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const UserAccountDropdown = ({ user, onLogout }) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);
  const navigate = useNavigate();

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef?.current && !dropdownRef?.current?.contains(event?.target)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Close dropdown on escape key
  useEffect(() => {
    const handleEscape = (e) => {
      if (e?.key === 'Escape' && isOpen) {
        setIsOpen(false);
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [isOpen]);

  const handleLogout = () => {
    setIsOpen(false);
    onLogout();
  };

  const handleMenuItemClick = () => {
    setIsOpen(false);
  };

  const menuItems = [
    {
      label: 'My Profile',
      path: '/user-profile',
      icon: 'User',
      description: 'Manage your account settings'
    },
    {
      label: 'Watch History',
      path: '/user-profile?tab=history',
      icon: 'History',
      description: 'View your viewing history'
    },
    {
      label: 'My List',
      path: '/user-profile?tab=watchlist',
      icon: 'Bookmark',
      description: 'Your saved movies and shows'
    },
    {
      label: 'Account Settings',
      path: '/user-profile?tab=settings',
      icon: 'Settings',
      description: 'Preferences and billing'
    }
  ];

  return (
    <div ref={dropdownRef} className="relative">
      {/* Trigger Button */}
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-2 hover:bg-muted/50 transition-colors"
      >
        {/* User Avatar */}
        <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center ring-2 ring-primary/20">
          {user?.avatar ? (
            <img 
              src={user?.avatar} 
              alt={user?.name}
              className="w-full h-full rounded-full object-cover"
            />
          ) : (
            <span className="text-xs font-heading font-semibold text-white">
              {user?.name?.charAt(0)?.toUpperCase() || 'U'}
            </span>
          )}
        </div>

        {/* User Name (Hidden on mobile) */}
        <div className="hidden md:block text-left">
          <div className="text-sm font-body font-medium text-foreground">
            {user?.name || 'User'}
          </div>
          <div className="text-xs text-muted-foreground">
            {user?.subscription || 'Premium'}
          </div>
        </div>

        {/* Chevron */}
        <Icon 
          name="ChevronDown" 
          size={16} 
          className={`text-muted-foreground transition-transform duration-200 ${
            isOpen ? 'rotate-180' : ''
          }`}
        />
      </Button>
      {/* Dropdown Menu */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-72 bg-popover border border-border rounded-lg shadow-elevation-2 z-1500 animate-slide-down">
          {/* User Info Header */}
          <div className="p-4 border-b border-border">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center">
                {user?.avatar ? (
                  <img 
                    src={user?.avatar} 
                    alt={user?.name}
                    className="w-full h-full rounded-full object-cover"
                  />
                ) : (
                  <span className="text-lg font-heading font-bold text-white">
                    {user?.name?.charAt(0)?.toUpperCase() || 'U'}
                  </span>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-base font-body font-semibold text-popover-foreground truncate">
                  {user?.name || 'User'}
                </div>
                <div className="text-sm text-muted-foreground truncate">
                  {user?.email || 'user@example.com'}
                </div>
                <div className="flex items-center mt-1">
                  <div className="w-2 h-2 bg-success rounded-full mr-2"></div>
                  <span className="text-xs text-muted-foreground">
                    {user?.subscription || 'Premium'} Plan
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Menu Items */}
          <div className="py-2">
            {menuItems?.map((item) => (
              <Link
                key={item?.path}
                to={item?.path}
                onClick={handleMenuItemClick}
                className="flex items-center px-4 py-3 hover:bg-muted/50 transition-colors group"
              >
                <div className="flex items-center justify-center w-8 h-8 bg-muted/50 rounded-md mr-3 group-hover:bg-primary/10 transition-colors">
                  <Icon 
                    name={item?.icon} 
                    size={16} 
                    className="text-muted-foreground group-hover:text-primary transition-colors" 
                  />
                </div>
                <div className="flex-1">
                  <div className="text-sm font-body font-medium text-popover-foreground">
                    {item?.label}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {item?.description}
                  </div>
                </div>
                <Icon 
                  name="ChevronRight" 
                  size={14} 
                  className="text-muted-foreground group-hover:text-primary transition-colors opacity-0 group-hover:opacity-100" 
                />
              </Link>
            ))}
          </div>

          {/* Divider */}
          <div className="border-t border-border my-2"></div>

          {/* Additional Actions */}
          <div className="py-2">
            <button
              onClick={() => {
                handleMenuItemClick();
                // Handle help action
              }}
              className="flex items-center w-full px-4 py-2 hover:bg-muted/50 transition-colors text-left"
            >
              <Icon name="HelpCircle" size={16} className="mr-3 text-muted-foreground" />
              <span className="text-sm font-body text-popover-foreground">Help & Support</span>
            </button>
            
            <button
              onClick={() => {
                handleMenuItemClick();
                // Handle feedback action
              }}
              className="flex items-center w-full px-4 py-2 hover:bg-muted/50 transition-colors text-left"
            >
              <Icon name="MessageSquare" size={16} className="mr-3 text-muted-foreground" />
              <span className="text-sm font-body text-popover-foreground">Send Feedback</span>
            </button>
          </div>

          {/* Divider */}
          <div className="border-t border-border my-2"></div>

          {/* Logout */}
          <div className="p-2">
            <button
              onClick={handleLogout}
              className="flex items-center w-full px-4 py-2 hover:bg-error/10 hover:text-error transition-colors rounded-md text-left group"
            >
              <Icon 
                name="LogOut" 
                size={16} 
                className="mr-3 text-muted-foreground group-hover:text-error transition-colors" 
              />
              <span className="text-sm font-body text-popover-foreground group-hover:text-error transition-colors">
                Sign Out
              </span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserAccountDropdown;