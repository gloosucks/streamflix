import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';
import Input from './Input';
import Button from './Button';

const SearchComponent = ({ onClose, isExpanded = false }) => {
  const [query, setQuery] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  
  const navigate = useNavigate();
  const inputRef = useRef(null);
  const containerRef = useRef(null);

  // Mock suggestions data
  const mockSuggestions = [
    { id: 1, title: 'Stranger Things', type: 'TV Series', year: 2016 },
    { id: 2, title: 'The Crown', type: 'TV Series', year: 2016 },
    { id: 3, title: 'Squid Game', type: 'TV Series', year: 2021 },
    { id: 4, title: 'Wednesday', type: 'TV Series', year: 2022 },
    { id: 5, title: 'The Witcher', type: 'TV Series', year: 2019 },
    { id: 6, title: 'Ozark', type: 'TV Series', year: 2017 },
    { id: 7, title: 'Dark', type: 'TV Series', year: 2017 },
    { id: 8, title: 'Money Heist', type: 'TV Series', year: 2017 },
  ];

  // Debounced search effect
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (query?.trim()?.length > 0) {
        setIsLoading(true);
        // Simulate API call
        setTimeout(() => {
          const filtered = mockSuggestions?.filter(item =>
            item?.title?.toLowerCase()?.includes(query?.toLowerCase())
          );
          setSuggestions(filtered?.slice(0, 6));
          setIsLoading(false);
          setShowSuggestions(true);
        }, 300);
      } else {
        setSuggestions([]);
        setShowSuggestions(false);
      }
    }, 300);

    return () => clearTimeout(timeoutId);
  }, [query]);

  // Focus input when expanded
  useEffect(() => {
    if (isExpanded && inputRef?.current) {
      inputRef?.current?.focus();
    }
  }, [isExpanded]);

  // Close suggestions when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (containerRef?.current && !containerRef?.current?.contains(event?.target)) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSubmit = (e) => {
    e?.preventDefault();
    if (query?.trim()) {
      navigate(`/search-results?q=${encodeURIComponent(query?.trim())}`);
      setQuery('');
      setShowSuggestions(false);
      onClose?.();
    }
  };

  const handleSuggestionClick = (suggestion) => {
    navigate(`/search-results?q=${encodeURIComponent(suggestion?.title)}`);
    setQuery('');
    setShowSuggestions(false);
    onClose?.();
  };

  const handleInputChange = (e) => {
    setQuery(e?.target?.value);
  };

  const handleClear = () => {
    setQuery('');
    setSuggestions([]);
    setShowSuggestions(false);
    inputRef?.current?.focus();
  };

  return (
    <div ref={containerRef} className="relative w-full max-w-2xl">
      <form onSubmit={handleSubmit} className="relative">
        <div className="relative">
          <Input
            ref={inputRef}
            type="search"
            placeholder="Search movies, TV shows, documentaries..."
            value={query}
            onChange={handleInputChange}
            className="w-full pl-12 pr-20 py-3 text-base bg-input border-border focus:border-primary focus:ring-primary/20"
          />
          
          {/* Search Icon */}
          <div className="absolute left-4 top-1/2 transform -translate-y-1/2">
            <Icon 
              name="Search" 
              size={20} 
              className="text-muted-foreground" 
            />
          </div>

          {/* Clear Button */}
          {query && (
            <Button
              type="button"
              variant="ghost"
              size="icon"
              onClick={handleClear}
              className="absolute right-12 top-1/2 transform -translate-y-1/2 h-8 w-8"
            >
              <Icon name="X" size={16} />
            </Button>
          )}

          {/* Submit Button */}
          <Button
            type="submit"
            variant="ghost"
            size="icon"
            className="absolute right-2 top-1/2 transform -translate-y-1/2 h-8 w-8 text-primary hover:text-primary/80"
          >
            <Icon name="ArrowRight" size={16} />
          </Button>
        </div>
      </form>
      {/* Suggestions Dropdown */}
      {showSuggestions && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-popover border border-border rounded-md shadow-elevation-2 z-1500 animate-slide-down">
          {isLoading ? (
            <div className="p-4 text-center">
              <div className="flex items-center justify-center space-x-2">
                <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
                <span className="text-sm text-muted-foreground">Searching...</span>
              </div>
            </div>
          ) : suggestions?.length > 0 ? (
            <div className="py-2">
              {suggestions?.map((suggestion) => (
                <button
                  key={suggestion?.id}
                  onClick={() => handleSuggestionClick(suggestion)}
                  className="w-full px-4 py-3 text-left hover:bg-muted/50 transition-colors flex items-center justify-between group"
                >
                  <div className="flex items-center space-x-3">
                    <Icon 
                      name="Play" 
                      size={16} 
                      className="text-muted-foreground group-hover:text-primary transition-colors" 
                    />
                    <div>
                      <div className="text-sm font-body font-medium text-popover-foreground">
                        {suggestion?.title}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {suggestion?.type} • {suggestion?.year}
                      </div>
                    </div>
                  </div>
                  <Icon 
                    name="ArrowUpRight" 
                    size={14} 
                    className="text-muted-foreground group-hover:text-primary transition-colors opacity-0 group-hover:opacity-100" 
                  />
                </button>
              ))}
              
              {/* View All Results */}
              <div className="border-t border-border mt-2 pt-2">
                <button
                  onClick={() => handleSubmit({ preventDefault: () => {} })}
                  className="w-full px-4 py-2 text-left hover:bg-muted/50 transition-colors flex items-center justify-between text-primary"
                >
                  <span className="text-sm font-body font-medium">
                    View all results for "{query}"
                  </span>
                  <Icon name="ArrowRight" size={14} />
                </button>
              </div>
            </div>
          ) : query?.trim() && (
            <div className="p-4 text-center">
              <Icon name="Search" size={24} className="text-muted-foreground mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">
                No suggestions found for "{query}"
              </p>
              <Button
                onClick={() => handleSubmit({ preventDefault: () => {} })}
                variant="ghost"
                size="sm"
                className="mt-2 text-primary"
              >
                Search anyway
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default SearchComponent;