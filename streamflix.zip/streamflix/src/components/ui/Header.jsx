import React, { useState, useEffect, useRef } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';
import Input from './Input';

const Header = () => {
  const [isSearchExpanded, setIsSearchExpanded] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);
  
  const location = useLocation();
  const navigate = useNavigate();
  const searchRef = useRef(null);
  const userMenuRef = useRef(null);

  // Mock authentication check
  useEffect(() => {
    const token = localStorage.getItem('authToken');
    const userData = localStorage.getItem('userData');
    if (token && userData) {
      setIsAuthenticated(true);
      setUser(JSON.parse(userData));
    }
  }, []);

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (searchRef?.current && !searchRef?.current?.contains(event?.target)) {
        setIsSearchExpanded(false);
      }
      if (userMenuRef?.current && !userMenuRef?.current?.contains(event?.target)) {
        setIsUserMenuOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location]);

  const handleSearch = (e) => {
    e?.preventDefault();
    if (searchQuery?.trim()) {
      navigate(`/search-results?q=${encodeURIComponent(searchQuery?.trim())}`);
      setIsSearchExpanded(false);
      setSearchQuery('');
    }
  };

  const handleSearchInputChange = (e) => {
    setSearchQuery(e?.target?.value);
  };

  const handleLogout = () => {
    localStorage.removeItem('authToken');
    localStorage.removeItem('userData');
    setIsAuthenticated(false);
    setUser(null);
    setIsUserMenuOpen(false);
    navigate('/login');
  };

  const navigationItems = [
    { label: 'Browse', path: '/content-library', icon: 'Grid3X3' },
    { label: 'Search', path: '/search-results', icon: 'Search' },
  ];

  const isActivePath = (path) => {
    return location?.pathname === path;
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-1000 bg-background/95 backdrop-blur-sm border-b border-border">
      <div className="flex items-center justify-between h-16 px-4 lg:px-6">
        {/* Logo */}
        <Link 
          to={isAuthenticated ? "/content-library" : "/"} 
          className="flex items-center space-x-2 hover:opacity-80 transition-opacity duration-200"
        >
          <div className="flex items-center justify-center w-8 h-8 bg-primary rounded">
            <Icon name="Play" size={20} color="white" />
          </div>
          <span className="text-xl font-heading font-bold text-foreground">
            StreamFlix
          </span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center space-x-8">
          {isAuthenticated && navigationItems?.map((item) => (
            <Link
              key={item?.path}
              to={item?.path}
              className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-body font-medium transition-all duration-200 ${
                isActivePath(item?.path)
                  ? 'text-primary bg-primary/10' :'text-muted-foreground hover:text-foreground hover:bg-muted/50'
              }`}
            >
              <Icon name={item?.icon} size={16} />
              <span>{item?.label}</span>
            </Link>
          ))}
        </nav>

        {/* Search & User Actions */}
        <div className="flex items-center space-x-4">
          {/* Search */}
          {isAuthenticated && (
            <div ref={searchRef} className="relative">
              <form onSubmit={handleSearch} className="flex items-center">
                <div className={`flex items-center transition-all duration-300 ${
                  isSearchExpanded ? 'w-80' : 'w-10'
                }`}>
                  <Input
                    type="search"
                    placeholder="Search movies, shows..."
                    value={searchQuery}
                    onChange={handleSearchInputChange}
                    onFocus={() => setIsSearchExpanded(true)}
                    className={`transition-all duration-300 ${
                      isSearchExpanded 
                        ? 'w-full opacity-100' :'w-0 opacity-0 pointer-events-none'
                    }`}
                  />
                  <Button
                    type="submit"
                    variant="ghost"
                    size="icon"
                    className={`ml-2 ${isSearchExpanded ? 'text-primary' : 'text-muted-foreground hover:text-foreground'}`}
                    onClick={() => !isSearchExpanded && setIsSearchExpanded(true)}
                  >
                    <Icon name="Search" size={20} />
                  </Button>
                </div>
              </form>
            </div>
          )}

          {/* Authentication / User Menu */}
          {isAuthenticated ? (
            <div ref={userMenuRef} className="relative">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                className="flex items-center space-x-2"
              >
                <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center">
                  <Icon name="User" size={16} color="white" />
                </div>
                <span className="hidden md:block text-sm font-body">
                  {user?.name || 'User'}
                </span>
                <Icon name="ChevronDown" size={16} />
              </Button>

              {/* User Dropdown */}
              {isUserMenuOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-popover border border-border rounded-md shadow-elevation-2 animate-slide-down">
                  <div className="py-1">
                    <Link
                      to="/user-profile"
                      className="flex items-center px-4 py-2 text-sm text-popover-foreground hover:bg-muted/50 transition-colors"
                      onClick={() => setIsUserMenuOpen(false)}
                    >
                      <Icon name="User" size={16} className="mr-3" />
                      My Profile
                    </Link>
                    <Link
                      to="/user-profile"
                      className="flex items-center px-4 py-2 text-sm text-popover-foreground hover:bg-muted/50 transition-colors"
                      onClick={() => setIsUserMenuOpen(false)}
                    >
                      <Icon name="Settings" size={16} className="mr-3" />
                      Settings
                    </Link>
                    <div className="border-t border-border my-1"></div>
                    <button
                      onClick={handleLogout}
                      className="flex items-center w-full px-4 py-2 text-sm text-popover-foreground hover:bg-muted/50 transition-colors"
                    >
                      <Icon name="LogOut" size={16} className="mr-3" />
                      Sign Out
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="flex items-center space-x-3">
              <Link to="/login">
                <Button variant="ghost" size="sm">
                  Sign In
                </Button>
              </Link>
              <Link to="/register">
                <Button variant="default" size="sm">
                  Sign Up
                </Button>
              </Link>
            </div>
          )}

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            <Icon name={isMobileMenuOpen ? "X" : "Menu"} size={20} />
          </Button>
        </div>
      </div>
      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-background border-t border-border animate-slide-down">
          <div className="px-4 py-4 space-y-2">
            {isAuthenticated && navigationItems?.map((item) => (
              <Link
                key={item?.path}
                to={item?.path}
                className={`flex items-center space-x-3 px-3 py-3 rounded-md text-base font-body transition-colors ${
                  isActivePath(item?.path)
                    ? 'text-primary bg-primary/10' :'text-muted-foreground hover:text-foreground hover:bg-muted/50'
                }`}
              >
                <Icon name={item?.icon} size={20} />
                <span>{item?.label}</span>
              </Link>
            ))}
            
            {!isAuthenticated && (
              <div className="pt-4 border-t border-border space-y-2">
                <Link to="/login" className="block">
                  <Button variant="ghost" fullWidth className="justify-start">
                    <Icon name="LogIn" size={20} className="mr-3" />
                    Sign In
                  </Button>
                </Link>
                <Link to="/register" className="block">
                  <Button variant="default" fullWidth className="justify-start">
                    <Icon name="UserPlus" size={20} className="mr-3" />
                    Sign Up
                  </Button>
                </Link>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;