import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import VideoControls from './components/VideoControls';
import VideoMetadata from './components/VideoMetadata';
import NextEpisodeOverlay from './components/NextEpisodeOverlay';
import LoadingSpinner from './components/LoadingSpinner';
import MobileControls from './components/MobileControls';
import QualitySelector from './components/QualitySelector';

const VideoPlayer = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const videoRef = useRef(null);
  const containerRef = useRef(null);
  const controlsTimeoutRef = useRef(null);

  // Video state
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [currentQuality, setCurrentQuality] = useState('auto');
  const [currentSpeed, setCurrentSpeed] = useState(1);
  const [brightness, setBrightness] = useState(1);

  // UI state
  const [showControls, setShowControls] = useState(true);
  const [showMetadata, setShowMetadata] = useState(false);
  const [showNextEpisode, setShowNextEpisode] = useState(false);
  const [showQualitySelector, setShowQualitySelector] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [isInWatchlist, setIsInWatchlist] = useState(false);

  // Mock content data
  const mockContent = {
    id: searchParams?.get('id') || '1',
    title: "Stranger Things",
    type: "TV Series",
    year: 2016,
    rating: "TV-14",
    imdbRating: "8.7",
    season: 4,
    episode: 7,
    episodeTitle: "The Massacre at Hawkins Lab",
    description: `In 1979, young Eleven is put through a series of tests by Dr. Brenner. Meanwhile, the gang tries to find a way into the Upside Down to save their friends. As the Mind Flayer's influence grows stronger, the residents of Hawkins face their greatest threat yet.`,
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    thumbnail: "https://images.unsplash.com/photo-1489599162163-3fb4b4b5b7b4?w=800&h=450&fit=crop",
    duration: 3840, // 64 minutes
    genres: ["Sci-Fi", "Horror", "Drama"],
    cast: ["Millie Bobby Brown", "Finn Wolfhard", "David Harbour"],
    director: "The Duffer Brothers"
  };

  const mockNextEpisode = {
    id: '2',
    title: "Papa",
    season: 4,
    episode: 8,
    description: "Eleven makes a desperate attempt to save her friends. The Mind Flayer\'s final assault begins as the fate of Hawkins hangs in the balance.",
    thumbnail: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=225&fit=crop",
    duration: 2580
  };

  // Check if mobile device
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Initialize video
  useEffect(() => {
    const video = videoRef?.current;
    if (!video) return;

    const handleLoadedData = () => {
      setDuration(video?.duration);
      setIsLoading(false);
    };

    const handleTimeUpdate = () => {
      setCurrentTime(video?.currentTime);
      
      // Show next episode overlay near the end
      if (video?.duration - video?.currentTime < 30 && !showNextEpisode) {
        setShowNextEpisode(true);
      }
    };

    const handlePlay = () => setIsPlaying(true);
    const handlePause = () => setIsPlaying(false);
    const handleVolumeChange = () => setVolume(video?.volume);

    video?.addEventListener('loadeddata', handleLoadedData);
    video?.addEventListener('timeupdate', handleTimeUpdate);
    video?.addEventListener('play', handlePlay);
    video?.addEventListener('pause', handlePause);
    video?.addEventListener('volumechange', handleVolumeChange);

    return () => {
      video?.removeEventListener('loadeddata', handleLoadedData);
      video?.removeEventListener('timeupdate', handleTimeUpdate);
      video?.removeEventListener('play', handlePlay);
      video?.removeEventListener('pause', handlePause);
      video?.removeEventListener('volumechange', handleVolumeChange);
    };
  }, [showNextEpisode]);

  // Auto-hide controls
  useEffect(() => {
    const resetControlsTimeout = () => {
      if (controlsTimeoutRef?.current) {
        clearTimeout(controlsTimeoutRef?.current);
      }
      
      setShowControls(true);
      
      if (isPlaying && !showMetadata && !showQualitySelector) {
        controlsTimeoutRef.current = setTimeout(() => {
          setShowControls(false);
        }, 3000);
      }
    };

    resetControlsTimeout();

    return () => {
      if (controlsTimeoutRef?.current) {
        clearTimeout(controlsTimeoutRef?.current);
      }
    };
  }, [isPlaying, showMetadata, showQualitySelector]);

  // Fullscreen handling
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyPress = (e) => {
      if (showQualitySelector || showNextEpisode) return;

      switch (e?.code) {
        case 'Space':
          e?.preventDefault();
          handlePlayPause();
          break;
        case 'ArrowLeft':
          e?.preventDefault();
          handleSeek(Math.max(0, currentTime - 10));
          break;
        case 'ArrowRight':
          e?.preventDefault();
          handleSeek(Math.min(duration, currentTime + 10));
          break;
        case 'ArrowUp':
          e?.preventDefault();
          handleVolumeChange(Math.min(1, volume + 0.1));
          break;
        case 'ArrowDown':
          e?.preventDefault();
          handleVolumeChange(Math.max(0, volume - 0.1));
          break;
        case 'KeyF':
          e?.preventDefault();
          handleFullscreen();
          break;
        case 'KeyM':
          e?.preventDefault();
          handleVolumeChange(volume === 0 ? 1 : 0);
          break;
        case 'Escape':
          if (isFullscreen) {
            handleFullscreen();
          } else {
            handleClose();
          }
          break;
      }
    };

    document.addEventListener('keydown', handleKeyPress);
    return () => document.removeEventListener('keydown', handleKeyPress);
  }, [currentTime, duration, volume, isFullscreen, showQualitySelector, showNextEpisode]);

  const handlePlayPause = () => {
    const video = videoRef?.current;
    if (!video) return;

    if (isPlaying) {
      video?.pause();
    } else {
      video?.play();
    }
  };

  const handleSeek = (time) => {
    const video = videoRef?.current;
    if (!video) return;

    video.currentTime = time;
    setCurrentTime(time);
  };

  const handleVolumeChange = (newVolume) => {
    const video = videoRef?.current;
    if (!video) return;

    video.volume = newVolume;
    setVolume(newVolume);
  };

  const handleFullscreen = async () => {
    const container = containerRef?.current;
    if (!container) return;

    try {
      if (!isFullscreen) {
        await container?.requestFullscreen();
      } else {
        await document.exitFullscreen();
      }
    } catch (error) {
      console.error('Fullscreen error:', error);
    }
  };

  const handleQualityChange = (quality) => {
    setCurrentQuality(quality);
    // In a real app, this would change the video source
    console.log('Quality changed to:', quality);
  };

  const handleSpeedChange = (speed) => {
    const video = videoRef?.current;
    if (!video) return;

    video.playbackRate = speed;
    setCurrentSpeed(speed);
  };

  const handleClose = () => {
    navigate('/content-library');
  };

  const handleNext = () => {
    // In a real app, this would load the next episode
    console.log('Playing next episode');
    setShowNextEpisode(false);
  };

  const handlePrevious = () => {
    // In a real app, this would load the previous episode
    console.log('Playing previous episode');
  };

  const handleAddToWatchlist = () => {
    setIsInWatchlist(!isInWatchlist);
    // In a real app, this would update the user's watchlist
  };

  const handleMouseMove = () => {
    if (!isMobile) {
      setShowControls(true);
    }
  };

  return (
    <>
      <Helmet>
        <title>{mockContent?.title} - StreamFlix</title>
        <meta name="description" content={mockContent?.description} />
      </Helmet>
      <div className="min-h-screen bg-background">
        {!isFullscreen && <Header />}
        
        <div 
          ref={containerRef}
          className={`relative ${isFullscreen ? 'h-screen' : 'h-screen pt-16'} bg-black overflow-hidden`}
          onMouseMove={handleMouseMove}
          onClick={() => isMobile && setShowControls(!showControls)}
        >
          {/* Video Element */}
          <video
            ref={videoRef}
            src={mockContent?.videoUrl}
            className="w-full h-full object-contain"
            style={{ filter: `brightness(${brightness})` }}
            preload="metadata"
            playsInline
          />

          {/* Loading Spinner */}
          <LoadingSpinner 
            isVisible={isLoading} 
            message="Loading video..." 
          />

          {/* Video Metadata Overlay */}
          <VideoMetadata
            content={mockContent}
            onClose={() => setShowMetadata(false)}
            onAddToList={handleAddToWatchlist}
            isInList={isInWatchlist}
          />

          {/* Desktop Controls */}
          {!isMobile && (
            <VideoControls
              isPlaying={isPlaying}
              onPlayPause={handlePlayPause}
              currentTime={currentTime}
              duration={duration}
              onSeek={handleSeek}
              volume={volume}
              onVolumeChange={handleVolumeChange}
              isFullscreen={isFullscreen}
              onFullscreen={handleFullscreen}
              onQualityChange={() => setShowQualitySelector(true)}
              currentQuality={currentQuality}
              onSpeedChange={handleSpeedChange}
              currentSpeed={currentSpeed}
              isVisible={showControls}
              onNext={handleNext}
              onPrevious={handlePrevious}
              hasNext={true}
              hasPrevious={true}
            />
          )}

          {/* Mobile Controls */}
          {isMobile && (
            <MobileControls
              isPlaying={isPlaying}
              onPlayPause={handlePlayPause}
              currentTime={currentTime}
              duration={duration}
              onSeek={handleSeek}
              volume={volume}
              onVolumeChange={handleVolumeChange}
              brightness={brightness}
              onBrightnessChange={setBrightness}
              isVisible={showControls}
              onClose={handleClose}
            />
          )}

          {/* Quality Selector */}
          <QualitySelector
            currentQuality={currentQuality}
            onQualityChange={handleQualityChange}
            isVisible={showQualitySelector}
            onClose={() => setShowQualitySelector(false)}
            connectionSpeed="good"
          />

          {/* Next Episode Overlay */}
          <NextEpisodeOverlay
            nextEpisode={mockNextEpisode}
            onPlayNext={handleNext}
            onCancel={() => setShowNextEpisode(false)}
            autoPlayDelay={10}
            isVisible={showNextEpisode}
          />
        </div>
      </div>
    </>
  );
};

export default VideoPlayer;