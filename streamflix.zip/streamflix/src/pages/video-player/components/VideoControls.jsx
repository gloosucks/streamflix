import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const VideoControls = ({ 
  isPlaying, 
  onPlayPause, 
  currentTime, 
  duration, 
  onSeek, 
  volume, 
  onVolumeChange, 
  isFullscreen, 
  onFullscreen,
  onQualityChange,
  currentQuality,
  onSpeedChange,
  currentSpeed,
  isVisible,
  onNext,
  onPrevious,
  hasNext,
  hasPrevious
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [showVolumeSlider, setShowVolumeSlider] = useState(false);
  const [showQualityMenu, setShowQualityMenu] = useState(false);
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);

  const formatTime = (time) => {
    const hours = Math.floor(time / 3600);
    const minutes = Math.floor((time % 3600) / 60);
    const seconds = Math.floor(time % 60);
    
    if (hours > 0) {
      return `${hours}:${minutes?.toString()?.padStart(2, '0')}:${seconds?.toString()?.padStart(2, '0')}`;
    }
    return `${minutes}:${seconds?.toString()?.padStart(2, '0')}`;
  };

  const handleProgressClick = (e) => {
    const rect = e?.currentTarget?.getBoundingClientRect();
    const clickX = e?.clientX - rect?.left;
    const newTime = (clickX / rect?.width) * duration;
    onSeek(newTime);
  };

  const handleProgressDrag = (e) => {
    if (!isDragging) return;
    const rect = e?.currentTarget?.getBoundingClientRect();
    const clickX = e?.clientX - rect?.left;
    const newTime = Math.max(0, Math.min((clickX / rect?.width) * duration, duration));
    onSeek(newTime);
  };

  const qualityOptions = [
    { value: '2160p', label: '4K (2160p)' },
    { value: '1080p', label: 'Full HD (1080p)' },
    { value: '720p', label: 'HD (720p)' },
    { value: '480p', label: 'SD (480p)' },
    { value: 'auto', label: 'Auto' }
  ];

  const speedOptions = [
    { value: 0.25, label: '0.25x' },
    { value: 0.5, label: '0.5x' },
    { value: 0.75, label: '0.75x' },
    { value: 1, label: 'Normal' },
    { value: 1.25, label: '1.25x' },
    { value: 1.5, label: '1.5x' },
    { value: 2, label: '2x' }
  ];

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div className={`absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent transition-opacity duration-300 ${
      isVisible ? 'opacity-100' : 'opacity-0'
    }`}>
      {/* Progress Bar */}
      <div className="px-4 pb-2">
        <div 
          className="relative h-1 bg-white/20 rounded-full cursor-pointer group hover:h-2 transition-all duration-200"
          onClick={handleProgressClick}
          onMouseMove={handleProgressDrag}
          onMouseDown={() => setIsDragging(true)}
          onMouseUp={() => setIsDragging(false)}
          onMouseLeave={() => setIsDragging(false)}
        >
          <div 
            className="absolute top-0 left-0 h-full bg-primary rounded-full transition-all duration-200"
            style={{ width: `${progress}%` }}
          />
          <div 
            className="absolute top-1/2 transform -translate-y-1/2 w-3 h-3 bg-primary rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-200"
            style={{ left: `${progress}%`, marginLeft: '-6px' }}
          />
        </div>
      </div>
      {/* Control Bar */}
      <div className="flex items-center justify-between px-4 pb-4">
        {/* Left Controls */}
        <div className="flex items-center space-x-3">
          {/* Play/Pause */}
          <Button
            variant="ghost"
            size="icon"
            onClick={onPlayPause}
            className="text-white hover:bg-white/20 w-12 h-12"
          >
            <Icon name={isPlaying ? "Pause" : "Play"} size={24} />
          </Button>

          {/* Previous/Next */}
          <div className="flex items-center space-x-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={onPrevious}
              disabled={!hasPrevious}
              className="text-white hover:bg-white/20 disabled:opacity-50"
            >
              <Icon name="SkipBack" size={20} />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={onNext}
              disabled={!hasNext}
              className="text-white hover:bg-white/20 disabled:opacity-50"
            >
              <Icon name="SkipForward" size={20} />
            </Button>
          </div>

          {/* Volume Control */}
          <div className="relative flex items-center">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowVolumeSlider(!showVolumeSlider)}
              className="text-white hover:bg-white/20"
            >
              <Icon 
                name={volume === 0 ? "VolumeX" : volume < 0.5 ? "Volume1" : "Volume2"} 
                size={20} 
              />
            </Button>
            
            {showVolumeSlider && (
              <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 bg-black/80 rounded-lg p-2">
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={volume}
                  onChange={(e) => onVolumeChange(parseFloat(e?.target?.value))}
                  className="w-20 h-1 bg-white/20 rounded-lg appearance-none slider"
                />
              </div>
            )}
          </div>

          {/* Time Display */}
          <div className="text-white text-sm font-mono">
            {formatTime(currentTime)} / {formatTime(duration)}
          </div>
        </div>

        {/* Right Controls */}
        <div className="flex items-center space-x-3">
          {/* Playback Speed */}
          <div className="relative">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowSpeedMenu(!showSpeedMenu)}
              className="text-white hover:bg-white/20 text-xs"
            >
              {currentSpeed}x
            </Button>
            
            {showSpeedMenu && (
              <div className="absolute bottom-full right-0 mb-2 bg-black/90 rounded-lg py-2 min-w-24">
                {speedOptions?.map((option) => (
                  <button
                    key={option?.value}
                    onClick={() => {
                      onSpeedChange(option?.value);
                      setShowSpeedMenu(false);
                    }}
                    className={`block w-full px-3 py-1 text-left text-sm hover:bg-white/20 transition-colors ${
                      currentSpeed === option?.value ? 'text-primary' : 'text-white'
                    }`}
                  >
                    {option?.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Quality Selection */}
          <div className="relative">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowQualityMenu(!showQualityMenu)}
              className="text-white hover:bg-white/20"
            >
              <Icon name="Settings" size={20} />
            </Button>
            
            {showQualityMenu && (
              <div className="absolute bottom-full right-0 mb-2 bg-black/90 rounded-lg py-2 min-w-32">
                <div className="px-3 py-1 text-xs text-white/60 border-b border-white/20 mb-1">
                  Quality
                </div>
                {qualityOptions?.map((option) => (
                  <button
                    key={option?.value}
                    onClick={() => {
                      onQualityChange(option?.value);
                      setShowQualityMenu(false);
                    }}
                    className={`block w-full px-3 py-1 text-left text-sm hover:bg-white/20 transition-colors ${
                      currentQuality === option?.value ? 'text-primary' : 'text-white'
                    }`}
                  >
                    {option?.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Subtitles */}
          <Button
            variant="ghost"
            size="icon"
            className="text-white hover:bg-white/20"
          >
            <Icon name="Subtitles" size={20} />
          </Button>

          {/* Fullscreen */}
          <Button
            variant="ghost"
            size="icon"
            onClick={onFullscreen}
            className="text-white hover:bg-white/20"
          >
            <Icon name={isFullscreen ? "Minimize" : "Maximize"} size={20} />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default VideoControls;