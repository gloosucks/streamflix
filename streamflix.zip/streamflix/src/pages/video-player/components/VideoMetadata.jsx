import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const VideoMetadata = ({ content, onClose, onAddToList, isInList }) => {
  if (!content) return null;

  return (
    <div className="absolute top-4 left-4 right-4 z-10">
      <div className="flex items-start justify-between">
        {/* Content Info */}
        <div className="flex-1 max-w-2xl">
          <div className="bg-black/60 backdrop-blur-sm rounded-lg p-4">
            <div className="flex items-center space-x-2 mb-2">
              <span className="text-xs text-white/80 bg-white/20 px-2 py-1 rounded">
                {content?.type}
              </span>
              <span className="text-xs text-white/80">
                {content?.year}
              </span>
              <span className="text-xs text-white/80">
                {content?.rating}
              </span>
              <div className="flex items-center space-x-1">
                <Icon name="Star" size={12} className="text-yellow-400 fill-current" />
                <span className="text-xs text-white/80">
                  {content?.imdbRating}
                </span>
              </div>
            </div>
            
            <h1 className="text-2xl font-heading font-bold text-white mb-2">
              {content?.title}
            </h1>
            
            {content?.episode && (
              <div className="text-sm text-white/80 mb-2">
                Season {content?.season} • Episode {content?.episode}: {content?.episodeTitle}
              </div>
            )}
            
            <p className="text-sm text-white/90 line-clamp-3 mb-3">
              {content?.description}
            </p>
            
            <div className="flex items-center space-x-3">
              <Button
                variant="ghost"
                size="sm"
                onClick={onAddToList}
                className="text-white hover:bg-white/20"
              >
                <Icon name={isInList ? "Check" : "Plus"} size={16} className="mr-2" />
                {isInList ? 'In My List' : 'Add to List'}
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                className="text-white hover:bg-white/20"
              >
                <Icon name="ThumbsUp" size={16} className="mr-2" />
                Like
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                className="text-white hover:bg-white/20"
              >
                <Icon name="Share" size={16} className="mr-2" />
                Share
              </Button>
            </div>
          </div>
        </div>

        {/* Close Button */}
        <Button
          variant="ghost"
          size="icon"
          onClick={onClose}
          className="text-white hover:bg-white/20 bg-black/40 backdrop-blur-sm"
        >
          <Icon name="X" size={20} />
        </Button>
      </div>
    </div>
  );
};

export default VideoMetadata;