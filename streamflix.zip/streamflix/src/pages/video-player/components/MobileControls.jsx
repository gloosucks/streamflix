import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const MobileControls = ({ 
  isPlaying, 
  onPlayPause, 
  currentTime, 
  duration, 
  onSeek, 
  volume, 
  onVolumeChange,
  brightness,
  onBrightnessChange,
  isVisible,
  onClose
}) => {
  const [showVolumeControl, setShowVolumeControl] = useState(false);
  const [showBrightnessControl, setShowBrightnessControl] = useState(false);
  const [gestureStartX, setGestureStartX] = useState(null);
  const [gestureStartY, setGestureStartY] = useState(null);

  const formatTime = (time) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds?.toString()?.padStart(2, '0')}`;
  };

  const handleTouchStart = (e) => {
    const touch = e?.touches?.[0];
    setGestureStartX(touch?.clientX);
    setGestureStartY(touch?.clientY);
  };

  const handleTouchMove = (e) => {
    if (!gestureStartX || !gestureStartY) return;
    
    const touch = e?.touches?.[0];
    const deltaX = touch?.clientX - gestureStartX;
    const deltaY = touch?.clientY - gestureStartY;
    
    // Horizontal swipe for seeking
    if (Math.abs(deltaX) > Math.abs(deltaY) && Math.abs(deltaX) > 50) {
      const seekAmount = (deltaX / window.innerWidth) * 30; // 30 seconds max
      const newTime = Math.max(0, Math.min(currentTime + seekAmount, duration));
      onSeek(newTime);
    }
    
    // Vertical swipe on left side for brightness
    if (touch?.clientX < window.innerWidth / 2 && Math.abs(deltaY) > 50) {
      const brightnessChange = -(deltaY / window.innerHeight);
      const newBrightness = Math.max(0, Math.min(brightness + brightnessChange, 1));
      onBrightnessChange(newBrightness);
      setShowBrightnessControl(true);
    }
    
    // Vertical swipe on right side for volume
    if (touch?.clientX > window.innerWidth / 2 && Math.abs(deltaY) > 50) {
      const volumeChange = -(deltaY / window.innerHeight);
      const newVolume = Math.max(0, Math.min(volume + volumeChange, 1));
      onVolumeChange(newVolume);
      setShowVolumeControl(true);
    }
  };

  const handleTouchEnd = () => {
    setGestureStartX(null);
    setGestureStartY(null);
    
    // Hide controls after gesture
    setTimeout(() => {
      setShowVolumeControl(false);
      setShowBrightnessControl(false);
    }, 2000);
  };

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div 
      className={`absolute inset-0 transition-opacity duration-300 ${
        isVisible ? 'opacity-100' : 'opacity-0 pointer-events-none'
      }`}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Top Bar */}
      <div className="absolute top-0 left-0 right-0 bg-gradient-to-b from-black/80 to-transparent p-4 flex items-center justify-between">
        <Button
          variant="ghost"
          size="icon"
          onClick={onClose}
          className="text-white hover:bg-white/20"
        >
          <Icon name="ArrowLeft" size={24} />
        </Button>
        
        <div className="text-white text-sm">
          {formatTime(currentTime)} / {formatTime(duration)}
        </div>
      </div>

      {/* Center Play/Pause */}
      <div className="absolute inset-0 flex items-center justify-center">
        <Button
          variant="ghost"
          size="icon"
          onClick={onPlayPause}
          className="text-white hover:bg-white/20 w-20 h-20 rounded-full bg-black/40 backdrop-blur-sm"
        >
          <Icon name={isPlaying ? "Pause" : "Play"} size={32} />
        </Button>
      </div>

      {/* Volume Control Overlay */}
      {showVolumeControl && (
        <div className="absolute right-8 top-1/2 transform -translate-y-1/2 bg-black/80 rounded-lg p-4">
          <div className="flex flex-col items-center space-y-2">
            <Icon name="Volume2" size={20} className="text-white" />
            <div className="h-32 w-1 bg-white/20 rounded-full relative">
              <div 
                className="absolute bottom-0 left-0 w-full bg-primary rounded-full transition-all duration-200"
                style={{ height: `${volume * 100}%` }}
              />
            </div>
            <span className="text-white text-xs">{Math.round(volume * 100)}%</span>
          </div>
        </div>
      )}

      {/* Brightness Control Overlay */}
      {showBrightnessControl && (
        <div className="absolute left-8 top-1/2 transform -translate-y-1/2 bg-black/80 rounded-lg p-4">
          <div className="flex flex-col items-center space-y-2">
            <Icon name="Sun" size={20} className="text-white" />
            <div className="h-32 w-1 bg-white/20 rounded-full relative">
              <div 
                className="absolute bottom-0 left-0 w-full bg-yellow-400 rounded-full transition-all duration-200"
                style={{ height: `${brightness * 100}%` }}
              />
            </div>
            <span className="text-white text-xs">{Math.round(brightness * 100)}%</span>
          </div>
        </div>
      )}

      {/* Bottom Progress Bar */}
      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
        <div className="h-1 bg-white/20 rounded-full relative">
          <div 
            className="absolute top-0 left-0 h-full bg-primary rounded-full transition-all duration-200"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {/* Gesture Hints */}
      <div className="absolute bottom-16 left-4 right-4 flex justify-between text-white/60 text-xs">
        <span>Swipe up/down for brightness</span>
        <span>Swipe left/right to seek</span>
        <span>Swipe up/down for volume</span>
      </div>
    </div>
  );
};

export default MobileControls;