import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Image from '../../../components/AppImage';

const NextEpisodeOverlay = ({ 
  nextEpisode, 
  onPlayNext, 
  onCancel, 
  autoPlayDelay = 10,
  isVisible 
}) => {
  const [countdown, setCountdown] = useState(autoPlayDelay);
  const [isCountingDown, setIsCountingDown] = useState(false);

  useEffect(() => {
    if (isVisible && nextEpisode) {
      setIsCountingDown(true);
      setCountdown(autoPlayDelay);
    } else {
      setIsCountingDown(false);
    }
  }, [isVisible, nextEpisode, autoPlayDelay]);

  useEffect(() => {
    if (!isCountingDown || countdown <= 0) return;

    const timer = setTimeout(() => {
      if (countdown === 1) {
        onPlayNext();
      } else {
        setCountdown(countdown - 1);
      }
    }, 1000);

    return () => clearTimeout(timer);
  }, [countdown, isCountingDown, onPlayNext]);

  if (!isVisible || !nextEpisode) return null;

  return (
    <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-card border border-border rounded-lg p-6 max-w-md w-full mx-4 animate-scale-in">
        {/* Next Episode Info */}
        <div className="flex items-start space-x-4 mb-6">
          <div className="w-24 h-16 rounded-md overflow-hidden flex-shrink-0">
            <Image
              src={nextEpisode?.thumbnail}
              alt={nextEpisode?.title}
              className="w-full h-full object-cover"
            />
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="text-sm text-muted-foreground mb-1">
              Up Next
            </div>
            <h3 className="text-lg font-heading font-semibold text-foreground mb-1 truncate">
              {nextEpisode?.title}
            </h3>
            <div className="text-sm text-muted-foreground mb-2">
              Season {nextEpisode?.season} • Episode {nextEpisode?.episode}
            </div>
            <p className="text-sm text-muted-foreground line-clamp-2">
              {nextEpisode?.description}
            </p>
          </div>
        </div>

        {/* Countdown Timer */}
        <div className="text-center mb-6">
          <div className="text-3xl font-heading font-bold text-primary mb-2">
            {countdown}
          </div>
          <div className="text-sm text-muted-foreground">
            Next episode starts automatically
          </div>
          
          {/* Progress Ring */}
          <div className="relative w-16 h-16 mx-auto mt-4">
            <svg className="w-16 h-16 transform -rotate-90" viewBox="0 0 64 64">
              <circle
                cx="32"
                cy="32"
                r="28"
                stroke="currentColor"
                strokeWidth="4"
                fill="none"
                className="text-muted"
              />
              <circle
                cx="32"
                cy="32"
                r="28"
                stroke="currentColor"
                strokeWidth="4"
                fill="none"
                strokeDasharray={`${2 * Math.PI * 28}`}
                strokeDashoffset={`${2 * Math.PI * 28 * (countdown / autoPlayDelay)}`}
                className="text-primary transition-all duration-1000 ease-linear"
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <Icon name="Play" size={16} className="text-primary" />
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center space-x-3">
          <Button
            variant="outline"
            onClick={() => {
              setIsCountingDown(false);
              onCancel();
            }}
            className="flex-1"
          >
            <Icon name="X" size={16} className="mr-2" />
            Cancel
          </Button>
          
          <Button
            variant="default"
            onClick={onPlayNext}
            className="flex-1"
          >
            <Icon name="Play" size={16} className="mr-2" />
            Play Now
          </Button>
        </div>

        {/* Skip Series Option */}
        <div className="text-center mt-4">
          <button
            onClick={() => {
              setIsCountingDown(false);
              onCancel();
            }}
            className="text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            Stop watching this series
          </button>
        </div>
      </div>
    </div>
  );
};

export default NextEpisodeOverlay;