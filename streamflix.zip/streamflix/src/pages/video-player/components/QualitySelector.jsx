import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const QualitySelector = ({ 
  currentQuality, 
  onQualityChange, 
  isVisible, 
  onClose,
  connectionSpeed = 'good'
}) => {
  const [selectedQuality, setSelectedQuality] = useState(currentQuality);

  const qualityOptions = [
    { 
      value: 'auto', 
      label: 'Auto', 
      description: 'Adjusts automatically based on connection',
      bandwidth: 'Variable',
      recommended: true
    },
    { 
      value: '2160p', 
      label: '4K Ultra HD', 
      description: '2160p • Best quality',
      bandwidth: '25+ Mbps',
      disabled: connectionSpeed === 'poor'
    },
    { 
      value: '1080p', 
      label: 'Full HD', 
      description: '1080p • High quality',
      bandwidth: '8+ Mbps',
      disabled: connectionSpeed === 'poor'
    },
    { 
      value: '720p', 
      label: 'HD', 
      description: '720p • Good quality',
      bandwidth: '3+ Mbps'
    },
    { 
      value: '480p', 
      label: 'Standard', 
      description: '480p • Data saver',
      bandwidth: '1+ Mbps'
    },
    { 
      value: '360p', 
      label: 'Low', 
      description: '360p • Minimum data usage',
      bandwidth: '0.5+ Mbps'
    }
  ];

  const handleQualitySelect = (quality) => {
    setSelectedQuality(quality);
  };

  const handleApply = () => {
    onQualityChange(selectedQuality);
    onClose();
  };

  const getConnectionIcon = () => {
    switch (connectionSpeed) {
      case 'excellent': return 'Wifi';
      case 'good': return 'Wifi';
      case 'fair': return 'Wifi';
      case 'poor': return 'WifiOff';
      default: return 'Wifi';
    }
  };

  const getConnectionColor = () => {
    switch (connectionSpeed) {
      case 'excellent': return 'text-green-400';
      case 'good': return 'text-green-400';
      case 'fair': return 'text-yellow-400';
      case 'poor': return 'text-red-400';
      default: return 'text-muted-foreground';
    }
  };

  if (!isVisible) return null;

  return (
    <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-card border border-border rounded-lg w-full max-w-md mx-4 animate-scale-in">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div className="flex items-center space-x-3">
            <Icon name="Settings" size={20} className="text-primary" />
            <h3 className="text-lg font-heading font-semibold text-foreground">
              Video Quality
            </h3>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="h-8 w-8"
          >
            <Icon name="X" size={16} />
          </Button>
        </div>

        {/* Connection Status */}
        <div className="p-4 border-b border-border">
          <div className="flex items-center space-x-2">
            <Icon 
              name={getConnectionIcon()} 
              size={16} 
              className={getConnectionColor()}
            />
            <span className="text-sm text-muted-foreground">
              Connection: 
            </span>
            <span className={`text-sm font-medium ${getConnectionColor()}`}>
              {connectionSpeed?.charAt(0)?.toUpperCase() + connectionSpeed?.slice(1)}
            </span>
          </div>
        </div>

        {/* Quality Options */}
        <div className="max-h-80 overflow-y-auto">
          {qualityOptions?.map((option) => (
            <button
              key={option?.value}
              onClick={() => !option?.disabled && handleQualitySelect(option?.value)}
              disabled={option?.disabled}
              className={`w-full p-4 text-left hover:bg-muted/50 transition-colors border-b border-border last:border-b-0 disabled:opacity-50 disabled:cursor-not-allowed ${
                selectedQuality === option?.value ? 'bg-primary/10 border-l-4 border-l-primary' : ''
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-1">
                    <span className="font-body font-medium text-foreground">
                      {option?.label}
                    </span>
                    {option?.recommended && (
                      <span className="text-xs bg-primary/20 text-primary px-2 py-0.5 rounded-full">
                        Recommended
                      </span>
                    )}
                    {option?.disabled && (
                      <span className="text-xs bg-muted text-muted-foreground px-2 py-0.5 rounded-full">
                        Unavailable
                      </span>
                    )}
                  </div>
                  <div className="text-sm text-muted-foreground mb-1">
                    {option?.description}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Requires: {option?.bandwidth}
                  </div>
                </div>
                
                <div className="ml-4">
                  {selectedQuality === option?.value ? (
                    <div className="w-5 h-5 bg-primary rounded-full flex items-center justify-center">
                      <Icon name="Check" size={12} color="white" />
                    </div>
                  ) : (
                    <div className="w-5 h-5 border-2 border-muted rounded-full"></div>
                  )}
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-border">
          <div className="flex items-center justify-between">
            <div className="text-xs text-muted-foreground">
              Higher quality uses more data
            </div>
            <div className="flex space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={onClose}
              >
                Cancel
              </Button>
              <Button
                variant="default"
                size="sm"
                onClick={handleApply}
              >
                Apply
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QualitySelector;