import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import RegistrationForm from './components/RegistrationForm';
import SubscriptionPlans from './components/SubscriptionPlans';
import ContentPreferences from './components/ContentPreferences';
import SocialRegistration from './components/SocialRegistration';
import RegistrationProgress from './components/RegistrationProgress';

const Register = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [socialLoading, setSocialLoading] = useState(null);
  const [registrationData, setRegistrationData] = useState({
    formData: null,
    selectedPlan: 'standard',
    preferences: {
      genres: [],
      ratings: ['g', 'pg', 'pg13'],
      languages: ['en']
    }
  });

  const navigate = useNavigate();

  const registrationSteps = [
    {
      id: 'account',
      title: 'Account',
      description: 'Create your account'
    },
    {
      id: 'plan',
      title: 'Plan',
      description: 'Choose subscription'
    },
    {
      id: 'preferences',
      title: 'Preferences',
      description: 'Personalize content'
    },
    {
      id: 'complete',
      title: 'Complete',
      description: 'Finish setup'
    }
  ];

  const handleFormSubmit = async (formData) => {
    setIsLoading(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      setRegistrationData(prev => ({
        ...prev,
        formData
      }));
      
      setCurrentStep(2);
    } catch (error) {
      console.error('Registration failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePlanSelect = (planId) => {
    setRegistrationData(prev => ({
      ...prev,
      selectedPlan: planId
    }));
  };

  const handlePreferencesChange = (preferences) => {
    setRegistrationData(prev => ({
      ...prev,
      preferences
    }));
  };

  const handleSocialRegister = async (provider) => {
    setSocialLoading(provider);
    
    try {
      // Simulate social login API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Mock successful social registration
      const userData = {
        id: '1',
        name: `${provider?.charAt(0)?.toUpperCase() + provider?.slice(1)} User`,
        email: `user@${provider}.com`
      };

      localStorage.setItem('authToken', 'mock-jwt-token');
      localStorage.setItem('userData', JSON.stringify(userData));

      navigate('/content-library');
      window.location?.reload();
      
    } catch (error) {
      console.error('Social registration failed:', error);
    } finally {
      setSocialLoading(null);
    }
  };

  const handleNextStep = () => {
    if (currentStep < registrationSteps?.length) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePreviousStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleCompleteRegistration = async () => {
    setIsLoading(true);
    
    try {
      // Simulate final registration API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Mock successful registration
      const userData = {
        id: '1',
        name: registrationData?.formData?.displayName || 'User',
        email: registrationData?.formData?.email || 'user@example.com',
        subscription: registrationData?.selectedPlan,
        preferences: registrationData?.preferences
      };

      localStorage.setItem('authToken', 'mock-jwt-token');
      localStorage.setItem('userData', JSON.stringify(userData));

      navigate('/content-library');
      window.location?.reload();
      
    } catch (error) {
      console.error('Registration completion failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-8">
            <RegistrationForm 
              onSubmit={handleFormSubmit}
              isLoading={isLoading}
            />
            
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-border" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-background px-2 text-muted-foreground">Or</span>
              </div>
            </div>
            
            <SocialRegistration 
              onSocialRegister={handleSocialRegister}
              isLoading={socialLoading}
            />
          </div>
        );
      
      case 2:
        return (
          <SubscriptionPlans
            selectedPlan={registrationData?.selectedPlan}
            onPlanSelect={handlePlanSelect}
          />
        );
      
      case 3:
        return (
          <ContentPreferences
            preferences={registrationData?.preferences}
            onPreferencesChange={handlePreferencesChange}
          />
        );
      
      case 4:
        return (
          <div className="text-center space-y-6">
            <div className="w-16 h-16 bg-success/20 rounded-full flex items-center justify-center mx-auto">
              <Icon name="Check" size={32} className="text-success" />
            </div>
            <div>
              <h2 className="text-2xl font-heading font-bold text-foreground mb-2">
                Welcome to StreamFlix!
              </h2>
              <p className="text-muted-foreground">
                Your account has been created successfully. Get ready to discover amazing content.
              </p>
            </div>
            <div className="bg-card border border-border rounded-lg p-6 text-left max-w-md mx-auto">
              <h3 className="font-heading font-semibold text-card-foreground mb-4">
                Account Summary
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Email:</span>
                  <span className="text-card-foreground">{registrationData?.formData?.email}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Plan:</span>
                  <span className="text-card-foreground capitalize">{registrationData?.selectedPlan}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Genres:</span>
                  <span className="text-card-foreground">{registrationData?.preferences?.genres?.length} selected</span>
                </div>
              </div>
            </div>
          </div>
        );
      
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center space-x-2">
              <div className="flex items-center justify-center w-8 h-8 bg-primary rounded">
                <Icon name="Play" size={20} color="white" />
              </div>
              <span className="text-xl font-heading font-bold text-foreground">
                StreamFlix
              </span>
            </Link>
            
            <div className="flex items-center space-x-4">
              <span className="text-sm text-muted-foreground">
                Already have an account?
              </span>
              <Link to="/login">
                <Button variant="ghost" size="sm">
                  Sign In
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>
      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Progress Indicator */}
          <RegistrationProgress
            currentStep={currentStep}
            totalSteps={registrationSteps?.length}
            steps={registrationSteps}
          />

          {/* Step Content */}
          <div className="bg-card border border-border rounded-lg p-8">
            {renderStepContent()}
          </div>

          {/* Navigation Buttons */}
          {currentStep > 1 && currentStep < 4 && (
            <div className="flex justify-between mt-8">
              <Button
                variant="outline"
                onClick={handlePreviousStep}
                iconName="ArrowLeft"
                iconPosition="left"
              >
                Previous
              </Button>
              
              {currentStep === 3 ? (
                <Button
                  variant="default"
                  onClick={handleCompleteRegistration}
                  loading={isLoading}
                  iconName="Check"
                  iconPosition="right"
                >
                  Complete Registration
                </Button>
              ) : (
                <Button
                  variant="default"
                  onClick={handleNextStep}
                  iconName="ArrowRight"
                  iconPosition="right"
                >
                  Continue
                </Button>
              )}
            </div>
          )}

          {/* Final Step Button */}
          {currentStep === 4 && (
            <div className="text-center mt-8">
              <Button
                variant="default"
                size="lg"
                onClick={() => navigate('/content-library')}
                iconName="Play"
                iconPosition="left"
              >
                Start Watching
              </Button>
            </div>
          )}
        </div>
      </main>
      {/* Footer */}
      <footer className="border-t border-border mt-16">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center text-sm text-muted-foreground">
            <p className="mb-2">
              By creating an account, you agree to our{' '}
              <a href="#" className="text-primary hover:text-primary/80">Terms of Service</a>
              {' '}and{' '}
              <a href="#" className="text-primary hover:text-primary/80">Privacy Policy</a>
            </p>
            <p>
              © {new Date()?.getFullYear()} StreamFlix. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Register;