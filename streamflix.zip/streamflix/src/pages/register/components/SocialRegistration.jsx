import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SocialRegistration = ({ onSocialRegister, isLoading }) => {
  const socialProviders = [
    {
      id: 'google',
      name: 'Google',
      icon: 'Chrome',
      color: 'hover:bg-red-50 hover:border-red-200 hover:text-red-600',
      description: 'Continue with Google account'
    },
    {
      id: 'facebook',
      name: 'Facebook',
      icon: 'Facebook',
      color: 'hover:bg-blue-50 hover:border-blue-200 hover:text-blue-600',
      description: 'Continue with Facebook account'
    },
    {
      id: 'apple',
      name: 'Apple',
      icon: 'Apple',
      color: 'hover:bg-gray-50 hover:border-gray-200 hover:text-gray-900',
      description: 'Continue with Apple ID'
    },
    {
      id: 'twitter',
      name: 'Twitter',
      icon: 'Twitter',
      color: 'hover:bg-sky-50 hover:border-sky-200 hover:text-sky-600',
      description: 'Continue with Twitter account'
    }
  ];

  const handleSocialLogin = (provider) => {
    onSocialRegister(provider);
  };

  return (
    <div className="w-full max-w-md mx-auto">
      {/* Header */}
      <div className="text-center mb-6">
        <h3 className="text-lg font-heading font-semibold text-foreground mb-2">
          Quick Registration
        </h3>
        <p className="text-sm text-muted-foreground">
          Sign up instantly with your existing account
        </p>
      </div>
      {/* Social Buttons */}
      <div className="space-y-3">
        {socialProviders?.map((provider) => (
          <Button
            key={provider?.id}
            variant="outline"
            size="lg"
            fullWidth
            onClick={() => handleSocialLogin(provider?.id)}
            loading={isLoading === provider?.id}
            className={`justify-start space-x-3 transition-all duration-200 ${provider?.color}`}
          >
            <Icon name={provider?.icon} size={20} />
            <div className="flex-1 text-left">
              <div className="font-medium">Continue with {provider?.name}</div>
              <div className="text-xs text-muted-foreground">
                {provider?.description}
              </div>
            </div>
            <Icon name="ArrowRight" size={16} className="opacity-50" />
          </Button>
        ))}
      </div>
      {/* Benefits */}
      <div className="mt-6 p-4 bg-muted/50 rounded-lg">
        <h4 className="text-sm font-medium text-foreground mb-3">
          Benefits of social registration:
        </h4>
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <Icon name="Check" size={14} className="text-success" />
            <span className="text-xs text-muted-foreground">
              Faster account setup
            </span>
          </div>
          <div className="flex items-center space-x-2">
            <Icon name="Check" size={14} className="text-success" />
            <span className="text-xs text-muted-foreground">
              Secure authentication
            </span>
          </div>
          <div className="flex items-center space-x-2">
            <Icon name="Check" size={14} className="text-success" />
            <span className="text-xs text-muted-foreground">
              No need to remember another password
            </span>
          </div>
        </div>
      </div>
      {/* Privacy Note */}
      <div className="mt-4 text-center">
        <p className="text-xs text-muted-foreground">
          We'll never post to your social media accounts without permission
        </p>
      </div>
    </div>
  );
};

export default SocialRegistration;