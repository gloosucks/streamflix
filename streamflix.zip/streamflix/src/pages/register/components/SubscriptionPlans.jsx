import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SubscriptionPlans = ({ selectedPlan, onPlanSelect }) => {
  const [billingCycle, setBillingCycle] = useState('monthly');

  const plans = [
    {
      id: 'basic',
      name: 'Basic',
      monthlyPrice: 8.99,
      yearlyPrice: 89.99,
      description: 'Perfect for casual viewing',
      features: [
        'HD streaming quality',
        'Watch on 1 device',
        'Limited content library',
        'Standard support'
      ],
      popular: false,
      color: 'border-border'
    },
    {
      id: 'standard',
      name: 'Standard',
      monthlyPrice: 13.99,
      yearlyPrice: 139.99,
      description: 'Great for families',
      features: [
        'Full HD streaming quality',
        'Watch on 2 devices simultaneously',
        'Full content library',
        'Priority support',
        'Download for offline viewing'
      ],
      popular: true,
      color: 'border-primary'
    },
    {
      id: 'premium',
      name: 'Premium',
      monthlyPrice: 17.99,
      yearlyPrice: 179.99,
      description: 'Ultimate streaming experience',
      features: [
        '4K Ultra HD streaming',
        'Watch on 4 devices simultaneously',
        'Full content library + exclusives',
        '24/7 premium support',
        'Download for offline viewing',
        'Early access to new releases'
      ],
      popular: false,
      color: 'border-accent'
    }
  ];

  const getCurrentPrice = (plan) => {
    return billingCycle === 'monthly' ? plan?.monthlyPrice : plan?.yearlyPrice;
  };

  const getYearlySavings = (plan) => {
    const monthlyTotal = plan?.monthlyPrice * 12;
    const yearlySavings = monthlyTotal - plan?.yearlyPrice;
    return Math.round(yearlySavings);
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      {/* Header */}
      <div className="text-center mb-8">
        <h2 className="text-2xl font-heading font-bold text-foreground mb-2">
          Choose Your Plan
        </h2>
        <p className="text-muted-foreground">
          Select the perfect plan for your streaming needs
        </p>
      </div>
      {/* Billing Toggle */}
      <div className="flex items-center justify-center mb-8">
        <div className="bg-muted rounded-lg p-1 flex">
          <button
            onClick={() => setBillingCycle('monthly')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-all duration-200 ${
              billingCycle === 'monthly' ?'bg-background text-foreground shadow-sm' :'text-muted-foreground hover:text-foreground'
            }`}
          >
            Monthly
          </button>
          <button
            onClick={() => setBillingCycle('yearly')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-all duration-200 relative ${
              billingCycle === 'yearly' ?'bg-background text-foreground shadow-sm' :'text-muted-foreground hover:text-foreground'
            }`}
          >
            Yearly
            <span className="absolute -top-2 -right-2 bg-success text-white text-xs px-1.5 py-0.5 rounded-full">
              Save 20%
            </span>
          </button>
        </div>
      </div>
      {/* Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {plans?.map((plan) => (
          <div
            key={plan?.id}
            className={`relative bg-card border-2 rounded-lg p-6 transition-all duration-200 hover:shadow-elevation-1 ${
              selectedPlan === plan?.id ? plan?.color : 'border-border'
            } ${plan?.popular ? 'scale-105' : ''}`}
          >
            {/* Popular Badge */}
            {plan?.popular && (
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                <div className="bg-primary text-white px-3 py-1 rounded-full text-xs font-medium">
                  Most Popular
                </div>
              </div>
            )}

            {/* Plan Header */}
            <div className="text-center mb-6">
              <h3 className="text-xl font-heading font-bold text-card-foreground mb-2">
                {plan?.name}
              </h3>
              <p className="text-sm text-muted-foreground mb-4">
                {plan?.description}
              </p>
              
              {/* Price */}
              <div className="mb-2">
                <span className="text-3xl font-heading font-bold text-card-foreground">
                  ${getCurrentPrice(plan)}
                </span>
                <span className="text-muted-foreground">
                  /{billingCycle === 'monthly' ? 'month' : 'year'}
                </span>
              </div>

              {/* Yearly Savings */}
              {billingCycle === 'yearly' && (
                <div className="text-sm text-success font-medium">
                  Save ${getYearlySavings(plan)} per year
                </div>
              )}
            </div>

            {/* Features */}
            <div className="space-y-3 mb-6">
              {plan?.features?.map((feature, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <Icon name="Check" size={16} className="text-success flex-shrink-0" />
                  <span className="text-sm text-card-foreground">{feature}</span>
                </div>
              ))}
            </div>

            {/* Select Button */}
            <Button
              variant={selectedPlan === plan?.id ? "default" : "outline"}
              size="lg"
              fullWidth
              onClick={() => onPlanSelect(plan?.id)}
              className="mt-auto"
            >
              {selectedPlan === plan?.id ? 'Selected' : 'Select Plan'}
            </Button>
          </div>
        ))}
      </div>
      {/* Additional Info */}
      <div className="text-center text-sm text-muted-foreground">
        <p className="mb-2">
          All plans include a 7-day free trial. Cancel anytime.
        </p>
        <p>
          Prices shown in USD. Taxes may apply based on your location.
        </p>
      </div>
    </div>
  );
};

export default SubscriptionPlans;