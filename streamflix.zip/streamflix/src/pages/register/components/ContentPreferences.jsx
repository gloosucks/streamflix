import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import { Checkbox } from '../../../components/ui/Checkbox';

const ContentPreferences = ({ preferences, onPreferencesChange }) => {
  const [selectedGenres, setSelectedGenres] = useState(preferences?.genres || []);
  const [selectedRatings, setSelectedRatings] = useState(preferences?.ratings || []);
  const [selectedLanguages, setSelectedLanguages] = useState(preferences?.languages || []);

  const genres = [
    { id: 'action', name: 'Action', icon: 'Zap' },
    { id: 'comedy', name: 'Comedy', icon: 'Smile' },
    { id: 'drama', name: 'Drama', icon: 'Theater' },
    { id: 'horror', name: 'Horror', icon: 'Ghost' },
    { id: 'romance', name: 'Romance', icon: 'Heart' },
    { id: 'thriller', name: 'Thriller', icon: 'Eye' },
    { id: 'sci-fi', name: 'Sci-Fi', icon: 'Rocket' },
    { id: 'documentary', name: 'Documentary', icon: 'FileText' },
    { id: 'animation', name: 'Animation', icon: 'Palette' },
    { id: 'crime', name: 'Crime', icon: 'Shield' },
    { id: 'fantasy', name: 'Fantasy', icon: 'Wand2' },
    { id: 'adventure', name: 'Adventure', icon: 'Map' }
  ];

  const contentRatings = [
    { id: 'g', name: 'G - General Audiences', description: 'All ages admitted' },
    { id: 'pg', name: 'PG - Parental Guidance', description: 'Some material may not be suitable for children' },
    { id: 'pg13', name: 'PG-13', description: 'Parents strongly cautioned for children under 13' },
    { id: 'r', name: 'R - Restricted', description: 'Under 17 requires parent or guardian' },
    { id: 'nc17', name: 'NC-17', description: 'No one 17 and under admitted' }
  ];

  const languages = [
    { id: 'en', name: 'English' },
    { id: 'es', name: 'Spanish' },
    { id: 'fr', name: 'French' },
    { id: 'de', name: 'German' },
    { id: 'it', name: 'Italian' },
    { id: 'pt', name: 'Portuguese' },
    { id: 'ja', name: 'Japanese' },
    { id: 'ko', name: 'Korean' },
    { id: 'zh', name: 'Chinese' },
    { id: 'hi', name: 'Hindi' }
  ];

  const handleGenreToggle = (genreId) => {
    const updatedGenres = selectedGenres?.includes(genreId)
      ? selectedGenres?.filter(id => id !== genreId)
      : [...selectedGenres, genreId];
    
    setSelectedGenres(updatedGenres);
    onPreferencesChange({
      ...preferences,
      genres: updatedGenres
    });
  };

  const handleRatingChange = (e) => {
    const { value, checked } = e?.target;
    const updatedRatings = checked
      ? [...selectedRatings, value]
      : selectedRatings?.filter(rating => rating !== value);
    
    setSelectedRatings(updatedRatings);
    onPreferencesChange({
      ...preferences,
      ratings: updatedRatings
    });
  };

  const handleLanguageChange = (e) => {
    const { value, checked } = e?.target;
    const updatedLanguages = checked
      ? [...selectedLanguages, value]
      : selectedLanguages?.filter(lang => lang !== value);
    
    setSelectedLanguages(updatedLanguages);
    onPreferencesChange({
      ...preferences,
      languages: updatedLanguages
    });
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-2xl font-heading font-bold text-foreground mb-2">
          Personalize Your Experience
        </h2>
        <p className="text-muted-foreground">
          Help us recommend content you'll love by sharing your preferences
        </p>
      </div>
      {/* Favorite Genres */}
      <div className="space-y-4">
        <h3 className="text-lg font-heading font-semibold text-foreground">
          Favorite Genres
        </h3>
        <p className="text-sm text-muted-foreground">
          Select all genres you enjoy watching (choose at least 3)
        </p>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {genres?.map((genre) => (
            <button
              key={genre?.id}
              onClick={() => handleGenreToggle(genre?.id)}
              className={`flex items-center space-x-3 p-3 rounded-lg border-2 transition-all duration-200 hover:shadow-sm ${
                selectedGenres?.includes(genre?.id)
                  ? 'border-primary bg-primary/10 text-primary' :'border-border bg-card text-card-foreground hover:border-muted-foreground'
              }`}
            >
              <Icon name={genre?.icon} size={20} />
              <span className="text-sm font-medium">{genre?.name}</span>
            </button>
          ))}
        </div>
      </div>
      {/* Content Ratings */}
      <div className="space-y-4">
        <h3 className="text-lg font-heading font-semibold text-foreground">
          Content Ratings
        </h3>
        <p className="text-sm text-muted-foreground">
          Select the content ratings you're comfortable with
        </p>
        
        <div className="space-y-3">
          {contentRatings?.map((rating) => (
            <Checkbox
              key={rating?.id}
              label={rating?.name}
              description={rating?.description}
              value={rating?.id}
              checked={selectedRatings?.includes(rating?.id)}
              onChange={handleRatingChange}
            />
          ))}
        </div>
      </div>
      {/* Preferred Languages */}
      <div className="space-y-4">
        <h3 className="text-lg font-heading font-semibold text-foreground">
          Preferred Languages
        </h3>
        <p className="text-sm text-muted-foreground">
          Select languages for content and subtitles
        </p>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
          {languages?.map((language) => (
            <Checkbox
              key={language?.id}
              label={language?.name}
              value={language?.id}
              checked={selectedLanguages?.includes(language?.id)}
              onChange={handleLanguageChange}
            />
          ))}
        </div>
      </div>
      {/* Skip Option */}
      <div className="text-center pt-4 border-t border-border">
        <p className="text-sm text-muted-foreground">
          You can always update these preferences later in your account settings
        </p>
      </div>
    </div>
  );
};

export default ContentPreferences;