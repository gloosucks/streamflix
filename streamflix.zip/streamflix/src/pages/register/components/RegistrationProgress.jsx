import React from 'react';
import Icon from '../../../components/AppIcon';

const RegistrationProgress = ({ currentStep, totalSteps, steps }) => {
  const progressPercentage = (currentStep / totalSteps) * 100;

  return (
    <div className="w-full max-w-4xl mx-auto mb-8">
      {/* Progress Bar */}
      <div className="relative mb-6">
        <div className="w-full bg-muted rounded-full h-2">
          <div 
            className="bg-primary h-2 rounded-full transition-all duration-500 ease-out"
            style={{ width: `${progressPercentage}%` }}
          />
        </div>
        
        {/* Step Indicators */}
        <div className="flex justify-between mt-4">
          {steps?.map((step, index) => {
            const stepNumber = index + 1;
            const isCompleted = stepNumber < currentStep;
            const isCurrent = stepNumber === currentStep;
            
            return (
              <div key={step?.id} className="flex flex-col items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-all duration-300 ${
                  isCompleted 
                    ? 'bg-primary text-white' 
                    : isCurrent 
                      ? 'bg-primary/20 text-primary border-2 border-primary' :'bg-muted text-muted-foreground'
                }`}>
                  {isCompleted ? (
                    <Icon name="Check" size={16} />
                  ) : (
                    stepNumber
                  )}
                </div>
                <div className="mt-2 text-center">
                  <div className={`text-xs font-medium ${
                    isCurrent ? 'text-primary' : 'text-muted-foreground'
                  }`}>
                    {step?.title}
                  </div>
                  <div className="text-xs text-muted-foreground mt-1 max-w-20">
                    {step?.description}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
      {/* Current Step Info */}
      <div className="text-center">
        <h2 className="text-xl font-heading font-bold text-foreground mb-2">
          {steps?.[currentStep - 1]?.title}
        </h2>
        <p className="text-muted-foreground text-sm">
          Step {currentStep} of {totalSteps}: {steps?.[currentStep - 1]?.description}
        </p>
      </div>
    </div>
  );
};

export default RegistrationProgress;