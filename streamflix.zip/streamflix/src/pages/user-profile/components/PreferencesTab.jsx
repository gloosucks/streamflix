import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const PreferencesTab = () => {
  const [preferences, setPreferences] = useState({
    contentRating: 'PG-13',
    autoplay: true,
    autoplayPreviews: false,
    subtitleLanguage: 'English',
    subtitleSize: 'Medium',
    videoQuality: 'Auto',
    downloadQuality: 'Standard',
    dataUsage: 'Medium',
    notifications: {
      newReleases: true,
      recommendations: true,
      watchlistUpdates: false,
      promotional: false
    },
    privacy: {
      shareWatchHistory: false,
      personalizedAds: true,
      dataCollection: true
    }
  });

  const contentRatingOptions = [
    { value: 'G', label: 'G - General Audiences' },
    { value: 'PG', label: 'PG - Parental Guidance' },
    { value: 'PG-13', label: 'PG-13 - Parents Strongly Cautioned' },
    { value: 'R', label: 'R - Restricted' },
    { value: 'NC-17', label: 'NC-17 - Adults Only' }
  ];

  const languageOptions = [
    { value: 'English', label: 'English' },
    { value: 'Spanish', label: 'Spanish' },
    { value: 'French', label: 'French' },
    { value: 'German', label: 'German' },
    { value: 'Italian', label: 'Italian' },
    { value: 'Portuguese', label: 'Portuguese' },
    { value: 'Japanese', label: 'Japanese' },
    { value: 'Korean', label: 'Korean' }
  ];

  const subtitleSizeOptions = [
    { value: 'Small', label: 'Small' },
    { value: 'Medium', label: 'Medium' },
    { value: 'Large', label: 'Large' },
    { value: 'Extra Large', label: 'Extra Large' }
  ];

  const videoQualityOptions = [
    { value: 'Auto', label: 'Auto (Recommended)' },
    { value: 'Low', label: 'Low (Data Saver)' },
    { value: 'Medium', label: 'Medium (Standard)' },
    { value: 'High', label: 'High (HD)' },
    { value: 'Ultra', label: 'Ultra (4K)' }
  ];

  const downloadQualityOptions = [
    { value: 'Standard', label: 'Standard' },
    { value: 'High', label: 'High' },
    { value: 'Ultra', label: 'Ultra' }
  ];

  const dataUsageOptions = [
    { value: 'Low', label: 'Low (1GB per hour)' },
    { value: 'Medium', label: 'Medium (2GB per hour)' },
    { value: 'High', label: 'High (3GB per hour)' },
    { value: 'Unlimited', label: 'Unlimited' }
  ];

  const handleSelectChange = (field, value) => {
    setPreferences(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleCheckboxChange = (category, field, checked) => {
    if (category) {
      setPreferences(prev => ({
        ...prev,
        [category]: {
          ...prev?.[category],
          [field]: checked
        }
      }));
    } else {
      setPreferences(prev => ({
        ...prev,
        [field]: checked
      }));
    }
  };

  const handleSavePreferences = () => {
    // Handle save preferences logic here
    console.log('Saving preferences:', preferences);
  };

  const handleResetPreferences = () => {
    // Reset to default preferences
    setPreferences({
      contentRating: 'PG-13',
      autoplay: true,
      autoplayPreviews: false,
      subtitleLanguage: 'English',
      subtitleSize: 'Medium',
      videoQuality: 'Auto',
      downloadQuality: 'Standard',
      dataUsage: 'Medium',
      notifications: {
        newReleases: true,
        recommendations: true,
        watchlistUpdates: false,
        promotional: false
      },
      privacy: {
        shareWatchHistory: false,
        personalizedAds: true,
        dataCollection: true
      }
    });
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-heading font-semibold text-foreground">
            Preferences
          </h2>
          <p className="text-sm text-muted-foreground">
            Customize your streaming experience
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <Button variant="outline" size="sm" onClick={handleResetPreferences}>
            <Icon name="RotateCcw" size={16} className="mr-2" />
            Reset
          </Button>
          <Button variant="default" size="sm" onClick={handleSavePreferences}>
            <Icon name="Save" size={16} className="mr-2" />
            Save Changes
          </Button>
        </div>
      </div>
      {/* Content & Parental Controls */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
            <Icon name="Shield" size={20} className="text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-heading font-semibold text-foreground">
              Content & Parental Controls
            </h3>
            <p className="text-sm text-muted-foreground">
              Manage content ratings and restrictions
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <Select
              label="Maximum Content Rating"
              description="Content above this rating will be hidden"
              options={contentRatingOptions}
              value={preferences?.contentRating}
              onChange={(value) => handleSelectChange('contentRating', value)}
            />
          </div>
        </div>
      </div>
      {/* Playback Settings */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
            <Icon name="Play" size={20} className="text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-heading font-semibold text-foreground">
              Playback Settings
            </h3>
            <p className="text-sm text-muted-foreground">
              Control how content plays automatically
            </p>
          </div>
        </div>

        <div className="space-y-6">
          <div className="space-y-4">
            <Checkbox
              label="Autoplay next episode"
              description="Automatically play the next episode in a series"
              checked={preferences?.autoplay}
              onChange={(e) => handleCheckboxChange(null, 'autoplay', e?.target?.checked)}
            />
            
            <Checkbox
              label="Autoplay previews"
              description="Play video previews while browsing"
              checked={preferences?.autoplayPreviews}
              onChange={(e) => handleCheckboxChange(null, 'autoplayPreviews', e?.target?.checked)}
            />
          </div>
        </div>
      </div>
      {/* Subtitle & Audio */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
            <Icon name="Subtitles" size={20} className="text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-heading font-semibold text-foreground">
              Subtitle & Audio
            </h3>
            <p className="text-sm text-muted-foreground">
              Configure subtitle and audio preferences
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Select
            label="Subtitle Language"
            options={languageOptions}
            value={preferences?.subtitleLanguage}
            onChange={(value) => handleSelectChange('subtitleLanguage', value)}
          />
          
          <Select
            label="Subtitle Size"
            options={subtitleSizeOptions}
            value={preferences?.subtitleSize}
            onChange={(value) => handleSelectChange('subtitleSize', value)}
          />
        </div>
      </div>
      {/* Video Quality */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
            <Icon name="Monitor" size={20} className="text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-heading font-semibold text-foreground">
              Video Quality & Data Usage
            </h3>
            <p className="text-sm text-muted-foreground">
              Manage streaming quality and data consumption
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Select
            label="Streaming Quality"
            description="Higher quality uses more data"
            options={videoQualityOptions}
            value={preferences?.videoQuality}
            onChange={(value) => handleSelectChange('videoQuality', value)}
          />
          
          <Select
            label="Download Quality"
            description="Quality for offline downloads"
            options={downloadQualityOptions}
            value={preferences?.downloadQuality}
            onChange={(value) => handleSelectChange('downloadQuality', value)}
          />
          
          <div className="md:col-span-2">
            <Select
              label="Data Usage per Screen"
              description="Estimated data usage per hour of streaming"
              options={dataUsageOptions}
              value={preferences?.dataUsage}
              onChange={(value) => handleSelectChange('dataUsage', value)}
            />
          </div>
        </div>
      </div>
      {/* Notifications */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
            <Icon name="Bell" size={20} className="text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-heading font-semibold text-foreground">
              Notifications
            </h3>
            <p className="text-sm text-muted-foreground">
              Choose what notifications you want to receive
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <Checkbox
            label="New releases"
            description="Get notified about new movies and shows"
            checked={preferences?.notifications?.newReleases}
            onChange={(e) => handleCheckboxChange('notifications', 'newReleases', e?.target?.checked)}
          />
          
          <Checkbox
            label="Recommendations"
            description="Receive personalized content recommendations"
            checked={preferences?.notifications?.recommendations}
            onChange={(e) => handleCheckboxChange('notifications', 'recommendations', e?.target?.checked)}
          />
          
          <Checkbox
            label="Watchlist updates"
            description="Get notified when watchlist items become available"
            checked={preferences?.notifications?.watchlistUpdates}
            onChange={(e) => handleCheckboxChange('notifications', 'watchlistUpdates', e?.target?.checked)}
          />
          
          <Checkbox
            label="Promotional offers"
            description="Receive special offers and promotions"
            checked={preferences?.notifications?.promotional}
            onChange={(e) => handleCheckboxChange('notifications', 'promotional', e?.target?.checked)}
          />
        </div>
      </div>
      {/* Privacy Settings */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
            <Icon name="Lock" size={20} className="text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-heading font-semibold text-foreground">
              Privacy Settings
            </h3>
            <p className="text-sm text-muted-foreground">
              Control your privacy and data sharing preferences
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <Checkbox
            label="Share watch history"
            description="Allow sharing of viewing activity for better recommendations"
            checked={preferences?.privacy?.shareWatchHistory}
            onChange={(e) => handleCheckboxChange('privacy', 'shareWatchHistory', e?.target?.checked)}
          />
          
          <Checkbox
            label="Personalized advertisements"
            description="Show ads based on your viewing preferences"
            checked={preferences?.privacy?.personalizedAds}
            onChange={(e) => handleCheckboxChange('privacy', 'personalizedAds', e?.target?.checked)}
          />
          
          <Checkbox
            label="Data collection for improvements"
            description="Help improve the service by sharing usage data"
            checked={preferences?.privacy?.dataCollection}
            onChange={(e) => handleCheckboxChange('privacy', 'dataCollection', e?.target?.checked)}
          />
        </div>
      </div>
    </div>
  );
};

export default PreferencesTab;