import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const WatchlistTab = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('dateAdded');
  const [filterBy, setFilterBy] = useState('all');
  const [selectedItems, setSelectedItems] = useState([]);

  const watchlistItems = [
    {
      id: 1,
      title: "The Witcher",
      type: "TV Series",
      genre: "Fantasy",
      year: 2019,
      rating: 8.2,
      addedAt: "2025-01-03T10:00:00Z",
      thumbnail: "https://images.unsplash.com/photo-1518676590629-3dcbd9c5a5c9?w=300&h=200&fit=crop",
      description: "Geralt of Rivia, a mutated monster-hunter for hire, journeys toward his destiny in a turbulent world."
    },
    {
      id: 2,
      title: "Dune",
      type: "Movie",
      genre: "Sci-Fi",
      year: 2021,
      rating: 8.0,
      addedAt: "2025-01-02T15:30:00Z",
      thumbnail: "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=300&h=200&fit=crop",
      description: "Paul Atreides leads nomadic tribes in a revolt against the galactic emperor."
    },
    {
      id: 3,
      title: "House of the Dragon",
      type: "TV Series",
      genre: "Fantasy",
      year: 2022,
      rating: 8.5,
      addedAt: "2025-01-01T20:15:00Z",
      thumbnail: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=200&fit=crop",
      description: "The Targaryen civil war, known as the Dance of the Dragons, comes to the Seven Kingdoms."
    },
    {
      id: 4,
      title: "Top Gun: Maverick",
      type: "Movie",
      genre: "Action",
      year: 2022,
      rating: 8.3,
      addedAt: "2024-12-30T14:20:00Z",
      thumbnail: "https://images.unsplash.com/photo-1489599162163-3f4b8e1b1e1e?w=300&h=200&fit=crop",
      description: "After thirty years, Maverick is still pushing the envelope as a top naval aviator."
    },
    {
      id: 5,
      title: "Ozark",
      type: "TV Series",
      genre: "Crime",
      year: 2017,
      rating: 8.4,
      addedAt: "2024-12-28T11:45:00Z",
      thumbnail: "https://images.unsplash.com/photo-1509347528160-9329d33b2588?w=300&h=200&fit=crop",
      description: "A financial advisor drags his family from Chicago to the Missouri Ozarks."
    }
  ];

  const sortOptions = [
    { value: 'dateAdded', label: 'Date Added' },
    { value: 'title', label: 'Title' },
    { value: 'rating', label: 'Rating' },
    { value: 'year', label: 'Release Year' }
  ];

  const filterOptions = [
    { value: 'all', label: 'All Content' },
    { value: 'Movie', label: 'Movies' },
    { value: 'TV Series', label: 'TV Series' }
  ];

  const filteredAndSortedItems = watchlistItems?.filter(item => {
      const matchesSearch = item?.title?.toLowerCase()?.includes(searchQuery?.toLowerCase());
      const matchesFilter = filterBy === 'all' || item?.type === filterBy;
      return matchesSearch && matchesFilter;
    })?.sort((a, b) => {
      switch (sortBy) {
        case 'title':
          return a?.title?.localeCompare(b?.title);
        case 'rating':
          return b?.rating - a?.rating;
        case 'year':
          return b?.year - a?.year;
        case 'dateAdded':
        default:
          return new Date(b.addedAt) - new Date(a.addedAt);
      }
    });

  const handleSelectItem = (itemId) => {
    setSelectedItems(prev => 
      prev?.includes(itemId) 
        ? prev?.filter(id => id !== itemId)
        : [...prev, itemId]
    );
  };

  const handleSelectAll = () => {
    if (selectedItems?.length === filteredAndSortedItems?.length) {
      setSelectedItems([]);
    } else {
      setSelectedItems(filteredAndSortedItems?.map(item => item?.id));
    }
  };

  const handleRemoveSelected = () => {
    setSelectedItems([]);
    // Handle removal logic here
  };

  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-heading font-semibold text-foreground">
            My Watchlist
          </h2>
          <p className="text-sm text-muted-foreground">
            {filteredAndSortedItems?.length} items saved for later
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <Button variant="outline" size="sm">
            <Icon name="Share2" size={16} className="mr-2" />
            Share List
          </Button>
          <Button variant="outline" size="sm">
            <Icon name="Plus" size={16} className="mr-2" />
            Create List
          </Button>
        </div>
      </div>
      {/* Search and Filters */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="md:col-span-1">
          <Input
            type="search"
            placeholder="Search watchlist..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e?.target?.value)}
          />
        </div>
        
        <div>
          <Select
            placeholder="Sort by"
            options={sortOptions}
            value={sortBy}
            onChange={setSortBy}
          />
        </div>

        <div>
          <Select
            placeholder="Filter by type"
            options={filterOptions}
            value={filterBy}
            onChange={setFilterBy}
          />
        </div>
      </div>
      {/* Bulk Actions */}
      {selectedItems?.length > 0 && (
        <div className="flex items-center justify-between p-4 bg-primary/10 border border-primary/20 rounded-lg">
          <span className="text-sm text-foreground">
            {selectedItems?.length} item{selectedItems?.length > 1 ? 's' : ''} selected
          </span>
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleRemoveSelected}
              className="text-error hover:text-error"
            >
              <Icon name="Trash2" size={16} className="mr-2" />
              Remove
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setSelectedItems([])}
            >
              Cancel
            </Button>
          </div>
        </div>
      )}
      {/* Select All */}
      {filteredAndSortedItems?.length > 0 && (
        <div className="flex items-center space-x-2">
          <input
            type="checkbox"
            id="selectAllWatchlist"
            checked={selectedItems?.length === filteredAndSortedItems?.length}
            onChange={handleSelectAll}
            className="w-4 h-4 text-primary bg-input border-border rounded focus:ring-primary/20"
          />
          <label htmlFor="selectAllWatchlist" className="text-sm text-foreground cursor-pointer">
            Select all items
          </label>
        </div>
      )}
      {/* Watchlist Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredAndSortedItems?.length > 0 ? (
          filteredAndSortedItems?.map((item) => (
            <div
              key={item?.id}
              className="bg-card border border-border rounded-lg overflow-hidden hover:shadow-elevation-1 transition-all duration-200 group"
            >
              {/* Thumbnail */}
              <div className="relative">
                <div className="aspect-video bg-muted overflow-hidden">
                  <Image
                    src={item?.thumbnail}
                    alt={item?.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                
                {/* Overlay Actions */}
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center">
                  <div className="flex items-center space-x-2">
                    <Button variant="default" size="sm">
                      <Icon name="Play" size={16} className="mr-2" />
                      Play
                    </Button>
                    <Button variant="outline" size="icon" className="bg-background/80">
                      <Icon name="Info" size={16} />
                    </Button>
                  </div>
                </div>

                {/* Selection Checkbox */}
                <div className="absolute top-3 left-3">
                  <input
                    type="checkbox"
                    checked={selectedItems?.includes(item?.id)}
                    onChange={() => handleSelectItem(item?.id)}
                    className="w-4 h-4 text-primary bg-background/80 border-border rounded focus:ring-primary/20"
                  />
                </div>

                {/* Remove Button */}
                <div className="absolute top-3 right-3">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 bg-background/80 hover:bg-background/90"
                  >
                    <Icon name="X" size={16} />
                  </Button>
                </div>
              </div>

              {/* Content Info */}
              <div className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="text-base font-body font-semibold text-foreground line-clamp-1">
                    {item?.title}
                  </h3>
                  <div className="flex items-center space-x-1 text-accent">
                    <Icon name="Star" size={14} />
                    <span className="text-sm font-medium">{item?.rating}</span>
                  </div>
                </div>

                <div className="flex items-center space-x-2 text-sm text-muted-foreground mb-3">
                  <span>{item?.type}</span>
                  <span>•</span>
                  <span>{item?.year}</span>
                  <span>•</span>
                  <span>{item?.genre}</span>
                </div>

                <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
                  {item?.description}
                </p>

                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>Added {formatDate(item?.addedAt)}</span>
                  <Button variant="ghost" size="sm" className="h-6 px-2">
                    <Icon name="MoreHorizontal" size={14} />
                  </Button>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="col-span-full text-center py-12">
            <Icon name="Bookmark" size={48} className="text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-heading font-medium text-foreground mb-2">
              {searchQuery || filterBy !== 'all' ? 'No matching items found' : 'Your watchlist is empty'}
            </h3>
            <p className="text-muted-foreground mb-4">
              {searchQuery || filterBy !== 'all' ?'Try adjusting your search or filter settings' :'Add movies and shows to your watchlist to watch them later'
              }
            </p>
            {!searchQuery && filterBy === 'all' && (
              <Button variant="default">
                <Icon name="Plus" size={16} className="mr-2" />
                Browse Content
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default WatchlistTab;