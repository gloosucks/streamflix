import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const ViewingHistoryTab = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedItems, setSelectedItems] = useState([]);

  const viewingHistory = [
    {
      id: 1,
      title: "Stranger Things",
      type: "TV Series",
      season: 4,
      episode: 9,
      watchedAt: "2025-01-05T20:30:00Z",
      duration: "1h 15m",
      progress: 100,
      thumbnail: "https://images.unsplash.com/photo-1489599162163-3f4b8e1b1e1e?w=300&h=200&fit=crop"
    },
    {
      id: 2,
      title: "The Crown",
      type: "TV Series",
      season: 6,
      episode: 3,
      watchedAt: "2025-01-04T19:45:00Z",
      duration: "58m",
      progress: 75,
      thumbnail: "https://images.unsplash.com/photo-1518676590629-3dcbd9c5a5c9?w=300&h=200&fit=crop"
    },
    {
      id: 3,
      title: "Inception",
      type: "Movie",
      watchedAt: "2025-01-03T21:00:00Z",
      duration: "2h 28m",
      progress: 100,
      thumbnail: "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=300&h=200&fit=crop"
    },
    {
      id: 4,
      title: "Wednesday",
      type: "TV Series",
      season: 1,
      episode: 8,
      watchedAt: "2025-01-02T18:20:00Z",
      duration: "45m",
      progress: 100,
      thumbnail: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=200&fit=crop"
    },
    {
      id: 5,
      title: "The Dark Knight",
      type: "Movie",
      watchedAt: "2025-01-01T20:15:00Z",
      duration: "2h 32m",
      progress: 100,
      thumbnail: "https://images.unsplash.com/photo-1509347528160-9329d33b2588?w=300&h=200&fit=crop"
    }
  ];

  const filteredHistory = viewingHistory?.filter(item =>
    item?.title?.toLowerCase()?.includes(searchQuery?.toLowerCase())
  );

  const handleSelectItem = (itemId) => {
    setSelectedItems(prev => 
      prev?.includes(itemId) 
        ? prev?.filter(id => id !== itemId)
        : [...prev, itemId]
    );
  };

  const handleSelectAll = () => {
    if (selectedItems?.length === filteredHistory?.length) {
      setSelectedItems([]);
    } else {
      setSelectedItems(filteredHistory?.map(item => item?.id));
    }
  };

  const handleRemoveSelected = () => {
    setSelectedItems([]);
    // Handle removal logic here
  };

  const handleClearHistory = () => {
    // Handle clear all history logic here
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 7) return `${diffDays} days ago`;
    return date?.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-heading font-semibold text-foreground">
            Viewing History
          </h2>
          <p className="text-sm text-muted-foreground">
            {filteredHistory?.length} items in your viewing history
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <Button
            variant="outline"
            size="sm"
            onClick={handleClearHistory}
            className="text-error hover:text-error"
          >
            <Icon name="Trash2" size={16} className="mr-2" />
            Clear All
          </Button>
        </div>
      </div>
      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1">
          <Input
            type="search"
            placeholder="Search your viewing history..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e?.target?.value)}
            className="w-full"
          />
        </div>

        {selectedItems?.length > 0 && (
          <div className="flex items-center space-x-2">
            <span className="text-sm text-muted-foreground">
              {selectedItems?.length} selected
            </span>
            <Button
              variant="outline"
              size="sm"
              onClick={handleRemoveSelected}
              className="text-error hover:text-error"
            >
              <Icon name="Trash2" size={16} className="mr-2" />
              Remove
            </Button>
          </div>
        )}
      </div>
      {/* Select All */}
      {filteredHistory?.length > 0 && (
        <div className="flex items-center space-x-2">
          <input
            type="checkbox"
            id="selectAll"
            checked={selectedItems?.length === filteredHistory?.length}
            onChange={handleSelectAll}
            className="w-4 h-4 text-primary bg-input border-border rounded focus:ring-primary/20"
          />
          <label htmlFor="selectAll" className="text-sm text-foreground cursor-pointer">
            Select all items
          </label>
        </div>
      )}
      {/* History List */}
      <div className="space-y-3">
        {filteredHistory?.length > 0 ? (
          filteredHistory?.map((item) => (
            <div
              key={item?.id}
              className="bg-card border border-border rounded-lg p-4 hover:bg-muted/20 transition-colors"
            >
              <div className="flex items-start space-x-4">
                {/* Checkbox */}
                <input
                  type="checkbox"
                  checked={selectedItems?.includes(item?.id)}
                  onChange={() => handleSelectItem(item?.id)}
                  className="w-4 h-4 text-primary bg-input border-border rounded focus:ring-primary/20 mt-1"
                />

                {/* Thumbnail */}
                <div className="w-20 h-12 bg-muted rounded overflow-hidden flex-shrink-0">
                  <Image
                    src={item?.thumbnail}
                    alt={item?.title}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Content Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <h3 className="text-base font-body font-medium text-foreground truncate">
                        {item?.title}
                      </h3>
                      <div className="flex items-center space-x-2 mt-1">
                        <span className="text-sm text-muted-foreground">
                          {item?.type}
                        </span>
                        {item?.season && item?.episode && (
                          <>
                            <span className="text-muted-foreground">•</span>
                            <span className="text-sm text-muted-foreground">
                              S{item?.season} E{item?.episode}
                            </span>
                          </>
                        )}
                        <span className="text-muted-foreground">•</span>
                        <span className="text-sm text-muted-foreground">
                          {item?.duration}
                        </span>
                      </div>
                    </div>

                    <div className="text-right flex-shrink-0 ml-4">
                      <div className="text-sm text-muted-foreground">
                        {formatDate(item?.watchedAt)}
                      </div>
                      {item?.progress < 100 && (
                        <div className="text-xs text-primary mt-1">
                          {item?.progress}% watched
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Progress Bar */}
                  {item?.progress < 100 && (
                    <div className="mt-3">
                      <div className="w-full bg-muted rounded-full h-1">
                        <div
                          className="bg-primary h-1 rounded-full transition-all duration-300"
                          style={{ width: `${item?.progress}%` }}
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div className="flex items-center space-x-2 flex-shrink-0">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                  >
                    <Icon name="Play" size={16} />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                  >
                    <Icon name="MoreVertical" size={16} />
                  </Button>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-12">
            <Icon name="History" size={48} className="text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-heading font-medium text-foreground mb-2">
              {searchQuery ? 'No matching history found' : 'No viewing history yet'}
            </h3>
            <p className="text-muted-foreground">
              {searchQuery 
                ? 'Try adjusting your search terms' :'Start watching content to see your history here'
              }
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ViewingHistoryTab;