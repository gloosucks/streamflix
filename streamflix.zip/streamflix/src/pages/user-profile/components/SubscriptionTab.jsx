import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SubscriptionTab = () => {
  const [currentPlan] = useState('premium');
  const [billingCycle, setBillingCycle] = useState('monthly');

  const currentSubscription = {
    plan: 'Premium',
    price: billingCycle === 'monthly' ? 15.99 : 159.99,
    cycle: billingCycle === 'monthly' ? 'month' : 'year',
    nextBilling: '2025-02-06',
    status: 'active',
    features: [
      'Watch on 4 devices at once',
      'Ultra HD (4K) streaming',
      'Download content for offline viewing',
      'No ads',
      'Access to exclusive content',
      'Dolby Atmos audio'
    ]
  };

  const plans = [
    {
      id: 'basic',
      name: 'Basic',
      monthlyPrice: 8.99,
      yearlyPrice: 89.99,
      features: [
        'Watch on 1 device at once',
        'HD streaming',
        'Limited downloads',
        'Some ads'
      ],
      popular: false
    },
    {
      id: 'standard',
      name: 'Standard',
      monthlyPrice: 12.99,
      yearlyPrice: 129.99,
      features: [
        'Watch on 2 devices at once',
        'Full HD streaming',
        'Download content',
        'No ads'
      ],
      popular: false
    },
    {
      id: 'premium',
      name: 'Premium',
      monthlyPrice: 15.99,
      yearlyPrice: 159.99,
      features: [
        'Watch on 4 devices at once',
        'Ultra HD (4K) streaming',
        'Download content',
        'No ads',
        'Exclusive content',
        'Dolby Atmos audio'
      ],
      popular: true
    }
  ];

  const paymentMethods = [
    {
      id: 1,
      type: 'card',
      last4: '4242',
      brand: 'Visa',
      expiryMonth: 12,
      expiryYear: 2027,
      isDefault: true
    },
    {
      id: 2,
      type: 'paypal',
      email: 'user@example.com',
      isDefault: false
    }
  ];

  const billingHistory = [
    {
      id: 1,
      date: '2025-01-06',
      amount: billingCycle === 'monthly' ? 15.99 : 159.99,
      status: 'paid',
      invoice: 'INV-2025-001'
    },
    {
      id: 2,
      date: '2024-12-06',
      amount: billingCycle === 'monthly' ? 15.99 : 159.99,
      status: 'paid',
      invoice: 'INV-2024-012'
    },
    {
      id: 3,
      date: '2024-11-06',
      amount: billingCycle === 'monthly' ? 15.99 : 159.99,
      status: 'paid',
      invoice: 'INV-2024-011'
    }
  ];

  const handlePlanChange = (planId) => {
    // Handle plan change logic
    console.log('Changing to plan:', planId);
  };

  const handleCancelSubscription = () => {
    // Handle subscription cancellation
    console.log('Cancelling subscription');
  };

  const handleAddPaymentMethod = () => {
    // Handle adding new payment method
    console.log('Adding payment method');
  };

  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleDateString('en-US', {
      month: 'long',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const getPrice = (plan) => {
    return billingCycle === 'monthly' ? plan?.monthlyPrice : plan?.yearlyPrice;
  };

  const getSavings = (plan) => {
    const monthlyTotal = plan?.monthlyPrice * 12;
    const yearlySavings = monthlyTotal - plan?.yearlyPrice;
    return Math.round(yearlySavings);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h2 className="text-xl font-heading font-semibold text-foreground">
          Subscription & Billing
        </h2>
        <p className="text-sm text-muted-foreground">
          Manage your subscription plan and billing information
        </p>
      </div>
      {/* Current Subscription */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
              <Icon name="Crown" size={20} className="text-primary" />
            </div>
            <div>
              <h3 className="text-lg font-heading font-semibold text-foreground">
                Current Plan: {currentSubscription?.plan}
              </h3>
              <p className="text-sm text-muted-foreground">
                ${currentSubscription?.price}/{currentSubscription?.cycle}
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-success rounded-full"></div>
            <span className="text-sm text-success capitalize">{currentSubscription?.status}</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <h4 className="text-sm font-body font-medium text-foreground mb-3">
              Plan Features
            </h4>
            <ul className="space-y-2">
              {currentSubscription?.features?.map((feature, index) => (
                <li key={index} className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <Icon name="Check" size={16} className="text-success" />
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-4">
            <div className="p-4 bg-muted/20 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">Next billing date</span>
                <span className="text-sm font-body font-medium text-foreground">
                  {formatDate(currentSubscription?.nextBilling)}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Amount</span>
                <span className="text-sm font-body font-medium text-foreground">
                  ${currentSubscription?.price}
                </span>
              </div>
            </div>

            <div className="flex space-x-2">
              <Button variant="outline" size="sm" className="flex-1">
                <Icon name="CreditCard" size={16} className="mr-2" />
                Update Payment
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                className="flex-1 text-error hover:text-error"
                onClick={handleCancelSubscription}
              >
                <Icon name="X" size={16} className="mr-2" />
                Cancel Plan
              </Button>
            </div>
          </div>
        </div>
      </div>
      {/* Plan Options */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-heading font-semibold text-foreground">
            Change Plan
          </h3>
          
          {/* Billing Cycle Toggle */}
          <div className="flex items-center space-x-2 bg-muted/20 rounded-lg p-1">
            <button
              onClick={() => setBillingCycle('monthly')}
              className={`px-3 py-1 text-sm rounded-md transition-colors ${
                billingCycle === 'monthly' ?'bg-primary text-primary-foreground' :'text-muted-foreground hover:text-foreground'
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setBillingCycle('yearly')}
              className={`px-3 py-1 text-sm rounded-md transition-colors ${
                billingCycle === 'yearly' ?'bg-primary text-primary-foreground' :'text-muted-foreground hover:text-foreground'
              }`}
            >
              Yearly
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {plans?.map((plan) => (
            <div
              key={plan?.id}
              className={`relative border rounded-lg p-6 transition-all duration-200 ${
                plan?.id === currentPlan
                  ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50'
              } ${plan?.popular ? 'ring-2 ring-primary/20' : ''}`}
            >
              {plan?.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <span className="bg-primary text-primary-foreground text-xs font-medium px-3 py-1 rounded-full">
                    Most Popular
                  </span>
                </div>
              )}

              <div className="text-center mb-6">
                <h4 className="text-lg font-heading font-semibold text-foreground mb-2">
                  {plan?.name}
                </h4>
                <div className="mb-2">
                  <span className="text-3xl font-heading font-bold text-foreground">
                    ${getPrice(plan)}
                  </span>
                  <span className="text-muted-foreground">
                    /{billingCycle === 'monthly' ? 'month' : 'year'}
                  </span>
                </div>
                {billingCycle === 'yearly' && (
                  <div className="text-sm text-success">
                    Save ${getSavings(plan)} per year
                  </div>
                )}
              </div>

              <ul className="space-y-3 mb-6">
                {plan?.features?.map((feature, index) => (
                  <li key={index} className="flex items-center space-x-2 text-sm">
                    <Icon name="Check" size={16} className="text-success" />
                    <span className="text-muted-foreground">{feature}</span>
                  </li>
                ))}
              </ul>

              <Button
                variant={plan?.id === currentPlan ? "outline" : "default"}
                fullWidth
                disabled={plan?.id === currentPlan}
                onClick={() => handlePlanChange(plan?.id)}
              >
                {plan?.id === currentPlan ? 'Current Plan' : 'Select Plan'}
              </Button>
            </div>
          ))}
        </div>
      </div>
      {/* Payment Methods */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-heading font-semibold text-foreground">
            Payment Methods
          </h3>
          <Button variant="outline" size="sm" onClick={handleAddPaymentMethod}>
            <Icon name="Plus" size={16} className="mr-2" />
            Add Method
          </Button>
        </div>

        <div className="space-y-4">
          {paymentMethods?.map((method) => (
            <div
              key={method?.id}
              className="flex items-center justify-between p-4 border border-border rounded-lg"
            >
              <div className="flex items-center space-x-4">
                <div className="w-10 h-10 bg-muted/20 rounded-lg flex items-center justify-center">
                  <Icon 
                    name={method?.type === 'card' ? 'CreditCard' : 'Wallet'} 
                    size={20} 
                    className="text-muted-foreground" 
                  />
                </div>
                <div>
                  {method?.type === 'card' ? (
                    <div>
                      <div className="text-sm font-body font-medium text-foreground">
                        {method?.brand} •••• {method?.last4}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Expires {method?.expiryMonth}/{method?.expiryYear}
                      </div>
                    </div>
                  ) : (
                    <div>
                      <div className="text-sm font-body font-medium text-foreground">
                        PayPal
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {method?.email}
                      </div>
                    </div>
                  )}
                </div>
                {method?.isDefault && (
                  <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full">
                    Default
                  </span>
                )}
              </div>

              <div className="flex items-center space-x-2">
                {!method?.isDefault && (
                  <Button variant="ghost" size="sm">
                    Set Default
                  </Button>
                )}
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <Icon name="MoreVertical" size={16} />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Billing History */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-heading font-semibold text-foreground">
            Billing History
          </h3>
          <Button variant="outline" size="sm">
            <Icon name="Download" size={16} className="mr-2" />
            Download All
          </Button>
        </div>

        <div className="space-y-4">
          {billingHistory?.map((bill) => (
            <div
              key={bill?.id}
              className="flex items-center justify-between p-4 border border-border rounded-lg"
            >
              <div className="flex items-center space-x-4">
                <div className="w-10 h-10 bg-success/10 rounded-lg flex items-center justify-center">
                  <Icon name="Receipt" size={20} className="text-success" />
                </div>
                <div>
                  <div className="text-sm font-body font-medium text-foreground">
                    ${bill?.amount} - Premium Plan
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {formatDate(bill?.date)} • {bill?.invoice}
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <span className="text-xs bg-success/10 text-success px-2 py-1 rounded-full capitalize">
                  {bill?.status}
                </span>
                <Button variant="ghost" size="sm">
                  <Icon name="Download" size={16} className="mr-2" />
                  Invoice
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SubscriptionTab;