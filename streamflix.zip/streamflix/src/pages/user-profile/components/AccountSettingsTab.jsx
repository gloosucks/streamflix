import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const AccountSettingsTab = () => {
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [language, setLanguage] = useState('English');
  const [timezone, setTimezone] = useState('America/New_York');

  const languageOptions = [
    { value: 'English', label: 'English' },
    { value: 'Spanish', label: 'Español' },
    { value: 'French', label: 'Français' },
    { value: 'German', label: 'Deutsch' },
    { value: 'Italian', label: 'Italiano' },
    { value: 'Portuguese', label: 'Português' },
    { value: 'Japanese', label: '日本語' },
    { value: 'Korean', label: '한국어' }
  ];

  const timezoneOptions = [
    { value: 'America/New_York', label: 'Eastern Time (ET)' },
    { value: 'America/Chicago', label: 'Central Time (CT)' },
    { value: 'America/Denver', label: 'Mountain Time (MT)' },
    { value: 'America/Los_Angeles', label: 'Pacific Time (PT)' },
    { value: 'Europe/London', label: 'Greenwich Mean Time (GMT)' },
    { value: 'Europe/Paris', label: 'Central European Time (CET)' },
    { value: 'Asia/Tokyo', label: 'Japan Standard Time (JST)' },
    { value: 'Asia/Seoul', label: 'Korea Standard Time (KST)' }
  ];

  const connectedAccounts = [
    {
      id: 1,
      provider: 'Google',
      email: 'user@gmail.com',
      connected: true,
      icon: 'Chrome'
    },
    {
      id: 2,
      provider: 'Facebook',
      email: 'user@facebook.com',
      connected: false,
      icon: 'Facebook'
    },
    {
      id: 3,
      provider: 'Apple',
      email: 'user@icloud.com',
      connected: true,
      icon: 'Apple'
    }
  ];

  const handlePasswordChange = (e) => {
    const { name, value } = e?.target;
    setPasswordData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handlePasswordSubmit = (e) => {
    e?.preventDefault();
    // Handle password change logic
    console.log('Changing password');
    setIsChangingPassword(false);
    setPasswordData({
      currentPassword: '',
      newPassword: '',
      confirmPassword: ''
    });
  };

  const handleToggleAccount = (accountId) => {
    // Handle account connection toggle
    console.log('Toggling account:', accountId);
  };

  const handleDeleteAccount = () => {
    // Handle account deletion
    console.log('Deleting account');
  };

  const handleExportData = () => {
    // Handle data export
    console.log('Exporting data');
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h2 className="text-xl font-heading font-semibold text-foreground">
          Account Settings
        </h2>
        <p className="text-sm text-muted-foreground">
          Manage your account security and preferences
        </p>
      </div>
      {/* Security Settings */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
            <Icon name="Shield" size={20} className="text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-heading font-semibold text-foreground">
              Security
            </h3>
            <p className="text-sm text-muted-foreground">
              Manage your password and security settings
            </p>
          </div>
        </div>

        <div className="space-y-6">
          {/* Password Change */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h4 className="text-sm font-body font-medium text-foreground">
                  Password
                </h4>
                <p className="text-xs text-muted-foreground">
                  Last changed 3 months ago
                </p>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsChangingPassword(!isChangingPassword)}
              >
                <Icon name="Key" size={16} className="mr-2" />
                Change Password
              </Button>
            </div>

            {isChangingPassword && (
              <form onSubmit={handlePasswordSubmit} className="space-y-4 p-4 bg-muted/20 rounded-lg">
                <Input
                  label="Current Password"
                  type="password"
                  name="currentPassword"
                  value={passwordData?.currentPassword}
                  onChange={handlePasswordChange}
                  required
                />
                
                <Input
                  label="New Password"
                  type="password"
                  name="newPassword"
                  value={passwordData?.newPassword}
                  onChange={handlePasswordChange}
                  description="Must be at least 8 characters long"
                  required
                />
                
                <Input
                  label="Confirm New Password"
                  type="password"
                  name="confirmPassword"
                  value={passwordData?.confirmPassword}
                  onChange={handlePasswordChange}
                  required
                />

                <div className="flex space-x-3">
                  <Button type="submit" variant="default" size="sm">
                    <Icon name="Check" size={16} className="mr-2" />
                    Update Password
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => setIsChangingPassword(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            )}
          </div>

          {/* Two-Factor Authentication */}
          <div className="flex items-center justify-between p-4 border border-border rounded-lg">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-muted/20 rounded-lg flex items-center justify-center">
                <Icon name="Smartphone" size={16} className="text-muted-foreground" />
              </div>
              <div>
                <h4 className="text-sm font-body font-medium text-foreground">
                  Two-Factor Authentication
                </h4>
                <p className="text-xs text-muted-foreground">
                  Add an extra layer of security to your account
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              {twoFactorEnabled && (
                <span className="text-xs bg-success/10 text-success px-2 py-1 rounded-full">
                  Enabled
                </span>
              )}
              <Button
                variant={twoFactorEnabled ? "outline" : "default"}
                size="sm"
                onClick={() => setTwoFactorEnabled(!twoFactorEnabled)}
              >
                {twoFactorEnabled ? 'Disable' : 'Enable'}
              </Button>
            </div>
          </div>
        </div>
      </div>
      {/* Connected Accounts */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
            <Icon name="Link" size={20} className="text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-heading font-semibold text-foreground">
              Connected Accounts
            </h3>
            <p className="text-sm text-muted-foreground">
              Manage your social media and third-party connections
            </p>
          </div>
        </div>

        <div className="space-y-4">
          {connectedAccounts?.map((account) => (
            <div
              key={account?.id}
              className="flex items-center justify-between p-4 border border-border rounded-lg"
            >
              <div className="flex items-center space-x-4">
                <div className="w-10 h-10 bg-muted/20 rounded-lg flex items-center justify-center">
                  <Icon name={account?.icon} size={20} className="text-muted-foreground" />
                </div>
                <div>
                  <div className="text-sm font-body font-medium text-foreground">
                    {account?.provider}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {account?.connected ? account?.email : 'Not connected'}
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                {account?.connected && (
                  <span className="text-xs bg-success/10 text-success px-2 py-1 rounded-full">
                    Connected
                  </span>
                )}
                <Button
                  variant={account?.connected ? "outline" : "default"}
                  size="sm"
                  onClick={() => handleToggleAccount(account?.id)}
                >
                  {account?.connected ? 'Disconnect' : 'Connect'}
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Preferences */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
            <Icon name="Settings" size={20} className="text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-heading font-semibold text-foreground">
              General Preferences
            </h3>
            <p className="text-sm text-muted-foreground">
              Configure your account preferences
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Select
            label="Language"
            description="Choose your preferred language"
            options={languageOptions}
            value={language}
            onChange={setLanguage}
          />
          
          <Select
            label="Timezone"
            description="Set your local timezone"
            options={timezoneOptions}
            value={timezone}
            onChange={setTimezone}
          />
        </div>

        <div className="mt-6">
          <Checkbox
            label="Email notifications"
            description="Receive account-related emails and updates"
            checked={emailNotifications}
            onChange={(e) => setEmailNotifications(e?.target?.checked)}
          />
        </div>
      </div>
      {/* Data & Privacy */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
            <Icon name="Database" size={20} className="text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-heading font-semibold text-foreground">
              Data & Privacy
            </h3>
            <p className="text-sm text-muted-foreground">
              Manage your data and privacy settings
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 border border-border rounded-lg">
            <div>
              <h4 className="text-sm font-body font-medium text-foreground">
                Export Account Data
              </h4>
              <p className="text-xs text-muted-foreground">
                Download a copy of your account data and activity
              </p>
            </div>
            <Button variant="outline" size="sm" onClick={handleExportData}>
              <Icon name="Download" size={16} className="mr-2" />
              Export Data
            </Button>
          </div>

          <div className="flex items-center justify-between p-4 border border-border rounded-lg">
            <div>
              <h4 className="text-sm font-body font-medium text-foreground">
                Clear Watch History
              </h4>
              <p className="text-xs text-muted-foreground">
                Remove all viewing history from your account
              </p>
            </div>
            <Button variant="outline" size="sm" className="text-warning hover:text-warning">
              <Icon name="Trash2" size={16} className="mr-2" />
              Clear History
            </Button>
          </div>
        </div>
      </div>
      {/* Danger Zone */}
      <div className="bg-card border border-error/20 rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-error/10 rounded-lg flex items-center justify-center">
            <Icon name="AlertTriangle" size={20} className="text-error" />
          </div>
          <div>
            <h3 className="text-lg font-heading font-semibold text-error">
              Danger Zone
            </h3>
            <p className="text-sm text-muted-foreground">
              Irreversible and destructive actions
            </p>
          </div>
        </div>

        <div className="p-4 border border-error/20 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-sm font-body font-medium text-foreground">
                Delete Account
              </h4>
              <p className="text-xs text-muted-foreground">
                Permanently delete your account and all associated data
              </p>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="text-error hover:text-error border-error/20 hover:border-error"
              onClick={handleDeleteAccount}
            >
              <Icon name="Trash2" size={16} className="mr-2" />
              Delete Account
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AccountSettingsTab;