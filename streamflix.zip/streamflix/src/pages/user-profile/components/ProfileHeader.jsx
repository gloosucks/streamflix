import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const ProfileHeader = ({ user, onUpdateProfile }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    bio: user?.bio || ''
  });

  const handleSave = () => {
    onUpdateProfile(editData);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditData({
      name: user?.name || '',
      email: user?.email || '',
      bio: user?.bio || ''
    });
    setIsEditing(false);
  };

  const handleInputChange = (e) => {
    const { name, value } = e?.target;
    setEditData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex flex-col lg:flex-row lg:items-start gap-6">
        {/* Avatar Section */}
        <div className="flex flex-col items-center lg:items-start">
          <div className="relative">
            <div className="w-24 h-24 lg:w-32 lg:h-32 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center ring-4 ring-primary/20">
              {user?.avatar ? (
                <Image 
                  src={user?.avatar} 
                  alt={user?.name}
                  className="w-full h-full rounded-full object-cover"
                />
              ) : (
                <span className="text-2xl lg:text-3xl font-heading font-bold text-white">
                  {user?.name?.charAt(0)?.toUpperCase() || 'U'}
                </span>
              )}
            </div>
            <Button
              variant="outline"
              size="icon"
              className="absolute -bottom-2 -right-2 w-8 h-8 bg-background border-2 border-border"
            >
              <Icon name="Camera" size={16} />
            </Button>
          </div>
          
          <div className="mt-4 text-center lg:text-left">
            <div className="flex items-center justify-center lg:justify-start space-x-2">
              <div className="w-2 h-2 bg-success rounded-full"></div>
              <span className="text-sm text-muted-foreground">
                {user?.subscription || 'Premium'} Member
              </span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Member since {new Date(user?.joinDate || '2023-01-15')?.toLocaleDateString('en-US', { 
                month: 'long', 
                year: 'numeric' 
              })}
            </p>
          </div>
        </div>

        {/* Profile Info */}
        <div className="flex-1">
          {isEditing ? (
            <div className="space-y-4">
              <Input
                label="Display Name"
                type="text"
                name="name"
                value={editData?.name}
                onChange={handleInputChange}
                placeholder="Enter your display name"
              />
              
              <Input
                label="Email Address"
                type="email"
                name="email"
                value={editData?.email}
                onChange={handleInputChange}
                placeholder="Enter your email"
              />
              
              <div>
                <label className="block text-sm font-body font-medium text-foreground mb-2">
                  Bio
                </label>
                <textarea
                  name="bio"
                  value={editData?.bio}
                  onChange={handleInputChange}
                  placeholder="Tell us about yourself..."
                  rows={3}
                  className="w-full px-3 py-2 bg-input border border-border rounded-md text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary resize-none"
                />
              </div>

              <div className="flex space-x-3">
                <Button variant="default" onClick={handleSave}>
                  <Icon name="Check" size={16} className="mr-2" />
                  Save Changes
                </Button>
                <Button variant="outline" onClick={handleCancel}>
                  <Icon name="X" size={16} className="mr-2" />
                  Cancel
                </Button>
              </div>
            </div>
          ) : (
            <div>
              <div className="flex items-center justify-between mb-4">
                <h1 className="text-2xl lg:text-3xl font-heading font-bold text-foreground">
                  {user?.name || 'User'}
                </h1>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsEditing(true)}
                >
                  <Icon name="Edit2" size={16} className="mr-2" />
                  Edit Profile
                </Button>
              </div>

              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <Icon name="Mail" size={16} className="text-muted-foreground" />
                  <span className="text-foreground">{user?.email || 'user@example.com'}</span>
                </div>
                
                <div className="flex items-center space-x-3">
                  <Icon name="Calendar" size={16} className="text-muted-foreground" />
                  <span className="text-foreground">
                    Joined {new Date(user?.joinDate || '2023-01-15')?.toLocaleDateString('en-US', { 
                      month: 'long', 
                      day: 'numeric',
                      year: 'numeric' 
                    })}
                  </span>
                </div>

                {user?.bio && (
                  <div className="flex items-start space-x-3">
                    <Icon name="FileText" size={16} className="text-muted-foreground mt-0.5" />
                    <p className="text-foreground">{user?.bio}</p>
                  </div>
                )}
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-4 mt-6 pt-6 border-t border-border">
                <div className="text-center">
                  <div className="text-2xl font-heading font-bold text-foreground">
                    {user?.stats?.watchedHours || 127}
                  </div>
                  <div className="text-sm text-muted-foreground">Hours Watched</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-heading font-bold text-foreground">
                    {user?.stats?.watchlistItems || 23}
                  </div>
                  <div className="text-sm text-muted-foreground">In Watchlist</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-heading font-bold text-foreground">
                    {user?.stats?.completedShows || 8}
                  </div>
                  <div className="text-sm text-muted-foreground">Shows Completed</div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProfileHeader;