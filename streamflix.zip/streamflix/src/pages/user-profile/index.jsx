import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Header from '../../components/ui/Header';
import ProfileHeader from './components/ProfileHeader';
import ViewingHistoryTab from './components/ViewingHistoryTab';
import WatchlistTab from './components/WatchlistTab';
import PreferencesTab from './components/PreferencesTab';
import SubscriptionTab from './components/SubscriptionTab';
import AccountSettingsTab from './components/AccountSettingsTab';

const UserProfile = () => {
  const [activeTab, setActiveTab] = useState('profile');
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  
  const location = useLocation();
  const navigate = useNavigate();

  // Mock user data
  const mockUser = {
    id: '1',
    name: 'Sarah Johnson',
    email: 'sarah.johnson@example.com',
    avatar: null,
    bio: 'Movie enthusiast and binge-watcher. Love sci-fi, thrillers, and documentaries.',
    subscription: 'Premium',
    joinDate: '2023-03-15T10:00:00Z',
    stats: {
      watchedHours: 247,
      watchlistItems: 34,
      completedShows: 12
    }
  };

  const tabs = [
    {
      id: 'profile',
      label: 'Profile',
      icon: 'User',
      component: ProfileHeader
    },
    {
      id: 'history',
      label: 'Watch History',
      icon: 'History',
      component: ViewingHistoryTab
    },
    {
      id: 'watchlist',
      label: 'My Watchlist',
      icon: 'Bookmark',
      component: WatchlistTab
    },
    {
      id: 'preferences',
      label: 'Preferences',
      icon: 'Settings',
      component: PreferencesTab
    },
    {
      id: 'subscription',
      label: 'Subscription',
      icon: 'Crown',
      component: SubscriptionTab
    },
    {
      id: 'settings',
      label: 'Account Settings',
      icon: 'Shield',
      component: AccountSettingsTab
    }
  ];

  // Check authentication and load user data
  useEffect(() => {
    const checkAuth = () => {
      const token = localStorage.getItem('authToken');
      const userData = localStorage.getItem('userData');
      
      if (!token || !userData) {
        navigate('/login');
        return;
      }

      try {
        const parsedUser = JSON.parse(userData);
        setUser({ ...mockUser, ...parsedUser });
      } catch (error) {
        console.error('Error parsing user data:', error);
        setUser(mockUser);
      }
      
      setIsLoading(false);
    };

    checkAuth();
  }, [navigate]);

  // Handle URL tab parameter
  useEffect(() => {
    const urlParams = new URLSearchParams(location.search);
    const tabParam = urlParams?.get('tab');
    
    if (tabParam && tabs?.find(tab => tab?.id === tabParam)) {
      setActiveTab(tabParam);
    }
  }, [location?.search]);

  // Update URL when tab changes
  const handleTabChange = (tabId) => {
    setActiveTab(tabId);
    const newUrl = tabId === 'profile' ? '/user-profile' : `/user-profile?tab=${tabId}`;
    navigate(newUrl, { replace: true });
  };

  const handleUpdateProfile = (updatedData) => {
    const updatedUser = { ...user, ...updatedData };
    setUser(updatedUser);
    
    // Update localStorage
    localStorage.setItem('userData', JSON.stringify(updatedUser));
  };

  const renderTabContent = () => {
    const activeTabData = tabs?.find(tab => tab?.id === activeTab);
    if (!activeTabData) return null;

    const Component = activeTabData?.component;
    
    if (activeTab === 'profile') {
      return <Component user={user} onUpdateProfile={handleUpdateProfile} />;
    }
    
    return <Component />;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="pt-16 flex items-center justify-center min-h-screen">
          <div className="flex items-center space-x-3">
            <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
            <span className="text-muted-foreground">Loading profile...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="pt-16">
        <div className="max-w-7xl mx-auto px-4 lg:px-6 py-8">
          {/* Mobile Tab Navigation */}
          <div className="lg:hidden mb-6">
            <div className="flex items-center justify-between mb-4">
              <h1 className="text-2xl font-heading font-bold text-foreground">
                My Profile
              </h1>
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigate('/content-library')}
              >
                <Icon name="ArrowLeft" size={16} className="mr-2" />
                Back to Library
              </Button>
            </div>
            
            <div className="overflow-x-auto">
              <div className="flex space-x-2 pb-2">
                {tabs?.map((tab) => (
                  <button
                    key={tab?.id}
                    onClick={() => handleTabChange(tab?.id)}
                    className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-body font-medium whitespace-nowrap transition-all duration-200 ${
                      activeTab === tab?.id
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted/20 text-muted-foreground hover:text-foreground hover:bg-muted/40'
                    }`}
                  >
                    <Icon name={tab?.icon} size={16} />
                    <span>{tab?.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Desktop Layout */}
          <div className="hidden lg:flex lg:space-x-8">
            {/* Sidebar Navigation */}
            <div className="w-64 flex-shrink-0">
              <div className="sticky top-24">
                <div className="flex items-center justify-between mb-6">
                  <h1 className="text-2xl font-heading font-bold text-foreground">
                    My Profile
                  </h1>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => navigate('/content-library')}
                    className="h-8 w-8"
                  >
                    <Icon name="X" size={16} />
                  </Button>
                </div>

                <nav className="space-y-2">
                  {tabs?.map((tab) => (
                    <button
                      key={tab?.id}
                      onClick={() => handleTabChange(tab?.id)}
                      className={`flex items-center space-x-3 w-full px-4 py-3 rounded-lg text-left transition-all duration-200 ${
                        activeTab === tab?.id
                          ? 'bg-primary text-primary-foreground'
                          : 'text-muted-foreground hover:text-foreground hover:bg-muted/20'
                      }`}
                    >
                      <Icon name={tab?.icon} size={20} />
                      <span className="text-sm font-body font-medium">
                        {tab?.label}
                      </span>
                    </button>
                  ))}
                </nav>

                {/* Quick Stats */}
                <div className="mt-8 p-4 bg-card border border-border rounded-lg">
                  <h3 className="text-sm font-body font-semibold text-foreground mb-3">
                    Quick Stats
                  </h3>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Hours Watched</span>
                      <span className="font-medium text-foreground">
                        {user?.stats?.watchedHours || 0}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Watchlist Items</span>
                      <span className="font-medium text-foreground">
                        {user?.stats?.watchlistItems || 0}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Shows Completed</span>
                      <span className="font-medium text-foreground">
                        {user?.stats?.completedShows || 0}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Main Content */}
            <div className="flex-1 min-w-0">
              {renderTabContent()}
            </div>
          </div>

          {/* Mobile Content */}
          <div className="lg:hidden">
            {renderTabContent()}
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserProfile;