import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { Checkbox } from '../../../components/ui/Checkbox';
import Select from '../../../components/ui/Select';

const FilterSidebar = ({ 
  isOpen, 
  onClose, 
  filters, 
  onFiltersChange, 
  contentCounts 
}) => {
  const [localFilters, setLocalFilters] = useState(filters);

  const genreOptions = [
    { value: 'action', label: 'Action', count: 245 },
    { value: 'comedy', label: 'Comedy', count: 189 },
    { value: 'drama', label: 'Drama', count: 312 },
    { value: 'thriller', label: 'Thriller', count: 156 },
    { value: 'horror', label: 'Horror', count: 98 },
    { value: 'romance', label: 'Romance', count: 134 },
    { value: 'sci-fi', label: 'Sci-Fi', count: 87 },
    { value: 'documentary', label: 'Documentary', count: 76 },
    { value: 'animation', label: 'Animation', count: 65 },
    { value: 'crime', label: 'Crime', count: 123 }
  ];

  const ratingOptions = [
    { value: 'g', label: 'G - General Audiences', count: 45 },
    { value: 'pg', label: 'PG - Parental Guidance', count: 234 },
    { value: 'pg13', label: 'PG-13 - Parents Cautioned', count: 456 },
    { value: 'r', label: 'R - Restricted', count: 289 },
    { value: 'nc17', label: 'NC-17 - Adults Only', count: 23 }
  ];

  const yearRanges = [
    { value: '2024', label: '2024', count: 89 },
    { value: '2023', label: '2023', count: 156 },
    { value: '2022', label: '2022', count: 234 },
    { value: '2021', label: '2021', count: 198 },
    { value: '2020', label: '2020', count: 167 },
    { value: '2019', label: '2019', count: 145 },
    { value: '2018', label: '2018', count: 134 },
    { value: '2015-2017', label: '2015-2017', count: 298 },
    { value: '2010-2014', label: '2010-2014', count: 456 },
    { value: '2000-2009', label: '2000s', count: 234 },
    { value: 'before-2000', label: 'Before 2000', count: 123 }
  ];

  const sortOptions = [
    { value: 'popularity', label: 'Most Popular' },
    { value: 'newest', label: 'Newest First' },
    { value: 'oldest', label: 'Oldest First' },
    { value: 'rating', label: 'Highest Rated' },
    { value: 'alphabetical', label: 'A-Z' },
    { value: 'duration', label: 'Duration' }
  ];

  const contentTypeOptions = [
    { value: 'all', label: 'All Content', count: 1245 },
    { value: 'movies', label: 'Movies', count: 789 },
    { value: 'tv-shows', label: 'TV Shows', count: 456 }
  ];

  const handleGenreChange = (genre, checked) => {
    const updatedGenres = checked 
      ? [...localFilters?.genres, genre]
      : localFilters?.genres?.filter(g => g !== genre);
    
    const newFilters = { ...localFilters, genres: updatedGenres };
    setLocalFilters(newFilters);
    onFiltersChange(newFilters);
  };

  const handleRatingChange = (rating, checked) => {
    const updatedRatings = checked 
      ? [...localFilters?.ratings, rating]
      : localFilters?.ratings?.filter(r => r !== rating);
    
    const newFilters = { ...localFilters, ratings: updatedRatings };
    setLocalFilters(newFilters);
    onFiltersChange(newFilters);
  };

  const handleYearChange = (year, checked) => {
    const updatedYears = checked 
      ? [...localFilters?.years, year]
      : localFilters?.years?.filter(y => y !== year);
    
    const newFilters = { ...localFilters, years: updatedYears };
    setLocalFilters(newFilters);
    onFiltersChange(newFilters);
  };

  const handleContentTypeChange = (type, checked) => {
    const updatedTypes = checked 
      ? [...localFilters?.contentTypes, type]
      : localFilters?.contentTypes?.filter(t => t !== type);
    
    const newFilters = { ...localFilters, contentTypes: updatedTypes };
    setLocalFilters(newFilters);
    onFiltersChange(newFilters);
  };

  const handleSortChange = (sortValue) => {
    const newFilters = { ...localFilters, sortBy: sortValue };
    setLocalFilters(newFilters);
    onFiltersChange(newFilters);
  };

  const clearAllFilters = () => {
    const clearedFilters = {
      genres: [],
      ratings: [],
      years: [],
      contentTypes: ['all'],
      sortBy: 'popularity'
    };
    setLocalFilters(clearedFilters);
    onFiltersChange(clearedFilters);
  };

  const getActiveFilterCount = () => {
    return localFilters?.genres?.length + 
           localFilters?.ratings?.length + 
           localFilters?.years?.length + 
           (localFilters?.contentTypes?.includes('all') ? 0 : localFilters?.contentTypes?.length);
  };

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-1400 lg:hidden"
          onClick={onClose}
        />
      )}
      {/* Sidebar */}
      <div className={`
        fixed lg:sticky top-16 left-0 h-[calc(100vh-4rem)] w-80 bg-card border-r border-border 
        transform transition-transform duration-300 z-1500 lg:z-auto lg:transform-none
        ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        overflow-y-auto scrollbar-thin scrollbar-thumb-muted scrollbar-track-transparent
      `}>
        {/* Header */}
        <div className="sticky top-0 bg-card border-b border-border p-4 z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Icon name="Filter" size={20} className="text-primary" />
              <h2 className="text-lg font-heading font-semibold text-card-foreground">
                Filters
              </h2>
              {getActiveFilterCount() > 0 && (
                <div className="bg-primary text-primary-foreground text-xs px-2 py-1 rounded-full">
                  {getActiveFilterCount()}
                </div>
              )}
            </div>
            <div className="flex items-center space-x-2">
              {getActiveFilterCount() > 0 && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearAllFilters}
                  className="text-xs"
                >
                  Clear All
                </Button>
              )}
              <Button
                variant="ghost"
                size="icon"
                onClick={onClose}
                className="lg:hidden h-8 w-8"
              >
                <Icon name="X" size={16} />
              </Button>
            </div>
          </div>
        </div>

        <div className="p-4 space-y-6">
          {/* Sort By */}
          <div className="space-y-3">
            <h3 className="text-sm font-body font-semibold text-card-foreground flex items-center">
              <Icon name="ArrowUpDown" size={16} className="mr-2 text-muted-foreground" />
              Sort By
            </h3>
            <Select
              options={sortOptions}
              value={localFilters?.sortBy}
              onChange={handleSortChange}
              placeholder="Select sorting option"
            />
          </div>

          {/* Content Type */}
          <div className="space-y-3">
            <h3 className="text-sm font-body font-semibold text-card-foreground flex items-center">
              <Icon name="Grid3X3" size={16} className="mr-2 text-muted-foreground" />
              Content Type
            </h3>
            <div className="space-y-2">
              {contentTypeOptions?.map((type) => (
                <Checkbox
                  key={type?.value}
                  label={
                    <div className="flex items-center justify-between w-full">
                      <span>{type?.label}</span>
                      <span className="text-xs text-muted-foreground">
                        {type?.count}
                      </span>
                    </div>
                  }
                  checked={localFilters?.contentTypes?.includes(type?.value)}
                  onChange={(e) => handleContentTypeChange(type?.value, e?.target?.checked)}
                />
              ))}
            </div>
          </div>

          {/* Genres */}
          <div className="space-y-3">
            <h3 className="text-sm font-body font-semibold text-card-foreground flex items-center">
              <Icon name="Tag" size={16} className="mr-2 text-muted-foreground" />
              Genres
            </h3>
            <div className="space-y-2 max-h-48 overflow-y-auto scrollbar-thin scrollbar-thumb-muted">
              {genreOptions?.map((genre) => (
                <Checkbox
                  key={genre?.value}
                  label={
                    <div className="flex items-center justify-between w-full">
                      <span>{genre?.label}</span>
                      <span className="text-xs text-muted-foreground">
                        {genre?.count}
                      </span>
                    </div>
                  }
                  checked={localFilters?.genres?.includes(genre?.value)}
                  onChange={(e) => handleGenreChange(genre?.value, e?.target?.checked)}
                />
              ))}
            </div>
          </div>

          {/* Release Year */}
          <div className="space-y-3">
            <h3 className="text-sm font-body font-semibold text-card-foreground flex items-center">
              <Icon name="Calendar" size={16} className="mr-2 text-muted-foreground" />
              Release Year
            </h3>
            <div className="space-y-2 max-h-48 overflow-y-auto scrollbar-thin scrollbar-thumb-muted">
              {yearRanges?.map((year) => (
                <Checkbox
                  key={year?.value}
                  label={
                    <div className="flex items-center justify-between w-full">
                      <span>{year?.label}</span>
                      <span className="text-xs text-muted-foreground">
                        {year?.count}
                      </span>
                    </div>
                  }
                  checked={localFilters?.years?.includes(year?.value)}
                  onChange={(e) => handleYearChange(year?.value, e?.target?.checked)}
                />
              ))}
            </div>
          </div>

          {/* Content Rating */}
          <div className="space-y-3">
            <h3 className="text-sm font-body font-semibold text-card-foreground flex items-center">
              <Icon name="Shield" size={16} className="mr-2 text-muted-foreground" />
              Content Rating
            </h3>
            <div className="space-y-2">
              {ratingOptions?.map((rating) => (
                <Checkbox
                  key={rating?.value}
                  label={
                    <div className="flex items-center justify-between w-full">
                      <span className="text-sm">{rating?.label}</span>
                      <span className="text-xs text-muted-foreground">
                        {rating?.count}
                      </span>
                    </div>
                  }
                  checked={localFilters?.ratings?.includes(rating?.value)}
                  onChange={(e) => handleRatingChange(rating?.value, e?.target?.checked)}
                />
              ))}
            </div>
          </div>

          {/* Results Summary */}
          <div className="pt-4 border-t border-border">
            <div className="bg-muted/30 rounded-lg p-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">
                  Total Results
                </span>
                <span className="text-sm font-body font-semibold text-card-foreground">
                  {contentCounts?.total || 1245} items
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default FilterSidebar;