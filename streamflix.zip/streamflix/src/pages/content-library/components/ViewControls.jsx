import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const ViewControls = ({ 
  viewMode, 
  onViewModeChange, 
  sortBy, 
  onSortChange, 
  totalResults,
  currentPage,
  totalPages,
  onPageChange
}) => {
  const viewModeOptions = [
    { value: 'grid', label: 'Grid View', icon: 'Grid3X3' },
    { value: 'list', label: 'List View', icon: 'List' },
    { value: 'compact', label: 'Compact View', icon: 'LayoutGrid' }
  ];

  const sortOptions = [
    { value: 'popularity', label: 'Most Popular' },
    { value: 'newest', label: 'Newest First' },
    { value: 'oldest', label: 'Oldest First' },
    { value: 'rating', label: 'Highest Rated' },
    { value: 'alphabetical', label: 'A-Z' },
    { value: 'duration', label: 'Duration' }
  ];

  const getViewModeIcon = (mode) => {
    const option = viewModeOptions?.find(opt => opt?.value === mode);
    return option ? option?.icon : 'Grid3X3';
  };

  return (
    <div className="bg-card border border-border rounded-lg p-4">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
        {/* Results Info */}
        <div className="flex items-center space-x-4">
          <div className="text-sm text-muted-foreground">
            Showing <span className="font-body font-semibold text-foreground">{totalResults}</span> results
          </div>
          {totalPages > 1 && (
            <div className="text-sm text-muted-foreground">
              Page <span className="font-body font-semibold text-foreground">{currentPage}</span> of {totalPages}
            </div>
          )}
        </div>

        {/* Controls */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
          {/* Sort Dropdown */}
          <div className="flex items-center space-x-2">
            <Icon name="ArrowUpDown" size={16} className="text-muted-foreground" />
            <Select
              options={sortOptions}
              value={sortBy}
              onChange={onSortChange}
              placeholder="Sort by"
              className="min-w-40"
            />
          </div>

          {/* View Mode Buttons */}
          <div className="flex items-center space-x-1 bg-muted/30 rounded-lg p-1">
            {viewModeOptions?.map((option) => (
              <Button
                key={option?.value}
                variant={viewMode === option?.value ? "default" : "ghost"}
                size="sm"
                onClick={() => onViewModeChange(option?.value)}
                className={`px-3 ${
                  viewMode === option?.value 
                    ? 'bg-primary text-primary-foreground' 
                    : 'hover:bg-muted/50'
                }`}
              >
                <Icon name={option?.icon} size={16} className="mr-2" />
                <span className="hidden sm:inline">{option?.label}</span>
              </Button>
            ))}
          </div>
        </div>
      </div>
      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between pt-4 mt-4 border-t border-border">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onPageChange(currentPage - 1)}
            disabled={currentPage === 1}
          >
            <Icon name="ChevronLeft" size={16} className="mr-2" />
            Previous
          </Button>

          {/* Page Numbers */}
          <div className="flex items-center space-x-1">
            {/* First Page */}
            {currentPage > 3 && (
              <>
                <Button
                  variant={currentPage === 1 ? "default" : "ghost"}
                  size="sm"
                  onClick={() => onPageChange(1)}
                  className="w-8 h-8 p-0"
                >
                  1
                </Button>
                {currentPage > 4 && (
                  <span className="text-muted-foreground px-2">...</span>
                )}
              </>
            )}

            {/* Current Page Range */}
            {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
              const pageNum = Math.max(1, Math.min(totalPages - 4, currentPage - 2)) + i;
              if (pageNum > totalPages) return null;
              
              return (
                <Button
                  key={pageNum}
                  variant={currentPage === pageNum ? "default" : "ghost"}
                  size="sm"
                  onClick={() => onPageChange(pageNum)}
                  className="w-8 h-8 p-0"
                >
                  {pageNum}
                </Button>
              );
            })}

            {/* Last Page */}
            {currentPage < totalPages - 2 && (
              <>
                {currentPage < totalPages - 3 && (
                  <span className="text-muted-foreground px-2">...</span>
                )}
                <Button
                  variant={currentPage === totalPages ? "default" : "ghost"}
                  size="sm"
                  onClick={() => onPageChange(totalPages)}
                  className="w-8 h-8 p-0"
                >
                  {totalPages}
                </Button>
              </>
            )}
          </div>

          <Button
            variant="outline"
            size="sm"
            onClick={() => onPageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
          >
            Next
            <Icon name="ChevronRight" size={16} className="ml-2" />
          </Button>
        </div>
      )}
    </div>
  );
};

export default ViewControls;