import React, { useState, useEffect } from 'react';
import ContentCard from './ContentCard';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const ContentGrid = ({ 
  content, 
  loading, 
  hasMore, 
  onLoadMore, 
  onAddToWatchlist, 
  onRemoveFromWatchlist,
  viewMode = 'grid'
}) => {
  const [selectedItems, setSelectedItems] = useState([]);
  const [bulkMode, setBulkMode] = useState(false);

  // Reset selection when content changes
  useEffect(() => {
    setSelectedItems([]);
    setBulkMode(false);
  }, [content]);

  const handleSelectItem = (contentId) => {
    setSelectedItems(prev => 
      prev?.includes(contentId) 
        ? prev?.filter(id => id !== contentId)
        : [...prev, contentId]
    );
  };

  const handleSelectAll = () => {
    if (selectedItems?.length === content?.length) {
      setSelectedItems([]);
    } else {
      setSelectedItems(content?.map(item => item?.id));
    }
  };

  const handleBulkAddToWatchlist = () => {
    const selectedContent = content?.filter(item => selectedItems?.includes(item?.id));
    selectedContent?.forEach(item => onAddToWatchlist?.(item));
    setSelectedItems([]);
    setBulkMode(false);
  };

  const handleBulkRemoveFromWatchlist = () => {
    selectedItems?.forEach(id => onRemoveFromWatchlist?.(id));
    setSelectedItems([]);
    setBulkMode(false);
  };

  const getGridClasses = () => {
    switch (viewMode) {
      case 'list':
        return 'grid grid-cols-1 gap-4';
      case 'compact':
        return 'grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3';
      default:
        return 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6';
    }
  };

  if (loading && content?.length === 0) {
    return (
      <div className="space-y-6">
        {/* Loading Skeleton */}
        <div className={getGridClasses()}>
          {Array.from({ length: 12 })?.map((_, index) => (
            <div key={index} className="bg-card border border-border rounded-lg overflow-hidden animate-pulse">
              <div className="aspect-[16/9] bg-muted" />
              <div className="p-4 space-y-2">
                <div className="h-4 bg-muted rounded w-3/4" />
                <div className="h-3 bg-muted rounded w-1/2" />
                <div className="flex space-x-1">
                  <div className="h-5 bg-muted rounded-full w-12" />
                  <div className="h-5 bg-muted rounded-full w-16" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (!content || content?.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center">
        <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mb-4">
          <Icon name="Search" size={32} className="text-muted-foreground" />
        </div>
        <h3 className="text-lg font-heading font-semibold text-foreground mb-2">
          No Content Found
        </h3>
        <p className="text-muted-foreground max-w-md">
          We couldn't find any content matching your current filters. Try adjusting your search criteria or clearing some filters.
        </p>
        <Button
          variant="outline"
          className="mt-4"
          onClick={() => window.location?.reload()}
        >
          <Icon name="RotateCcw" size={16} className="mr-2" />
          Reset Filters
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Bulk Actions Bar */}
      {bulkMode && (
        <div className="bg-card border border-border rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setBulkMode(false)}
              >
                <Icon name="X" size={16} className="mr-2" />
                Cancel
              </Button>
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleSelectAll}
                >
                  {selectedItems?.length === content?.length ? 'Deselect All' : 'Select All'}
                </Button>
                <span className="text-sm text-muted-foreground">
                  {selectedItems?.length} of {content?.length} selected
                </span>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant="default"
                size="sm"
                onClick={handleBulkAddToWatchlist}
                disabled={selectedItems?.length === 0}
              >
                <Icon name="Plus" size={16} className="mr-2" />
                Add to Watchlist
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleBulkRemoveFromWatchlist}
                disabled={selectedItems?.length === 0}
              >
                <Icon name="Minus" size={16} className="mr-2" />
                Remove from Watchlist
              </Button>
            </div>
          </div>
        </div>
      )}
      {/* Content Grid */}
      <div className={getGridClasses()}>
        {content?.map((item) => (
          <div key={item?.id} className="relative">
            {/* Selection Checkbox (Bulk Mode) */}
            {bulkMode && (
              <div className="absolute top-2 left-2 z-10">
                <input
                  type="checkbox"
                  checked={selectedItems?.includes(item?.id)}
                  onChange={() => handleSelectItem(item?.id)}
                  className="w-4 h-4 text-primary bg-background border-border rounded focus:ring-primary focus:ring-2"
                />
              </div>
            )}
            
            <ContentCard
              content={item}
              onAddToWatchlist={onAddToWatchlist}
              onRemoveFromWatchlist={onRemoveFromWatchlist}
            />
          </div>
        ))}
      </div>
      {/* Load More / Pagination */}
      {hasMore && (
        <div className="flex justify-center pt-8">
          <Button
            variant="outline"
            size="lg"
            onClick={onLoadMore}
            loading={loading}
            className="min-w-32"
          >
            {loading ? (
              <>
                <Icon name="Loader2" size={16} className="mr-2 animate-spin" />
                Loading...
              </>
            ) : (
              <>
                <Icon name="ChevronDown" size={16} className="mr-2" />
                Load More
              </>
            )}
          </Button>
        </div>
      )}
      {/* Bulk Mode Toggle */}
      {!bulkMode && content?.length > 0 && (
        <div className="fixed bottom-6 right-6 z-1000">
          <Button
            variant="secondary"
            size="icon"
            onClick={() => setBulkMode(true)}
            className="w-12 h-12 rounded-full shadow-elevation-2"
          >
            <Icon name="CheckSquare" size={20} />
          </Button>
        </div>
      )}
    </div>
  );
};

export default ContentGrid;