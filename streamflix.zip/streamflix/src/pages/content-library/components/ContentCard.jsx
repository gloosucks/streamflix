import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const ContentCard = ({ content, onAddToWatchlist, onRemoveFromWatchlist }) => {
  const [isHovered, setIsHovered] = useState(false);
  const [isInWatchlist, setIsInWatchlist] = useState(content?.isInWatchlist || false);
  const [imageLoaded, setImageLoaded] = useState(false);
  const navigate = useNavigate();

  const handlePlayClick = (e) => {
    e?.stopPropagation();
    navigate(`/video-player?id=${content?.id}&title=${encodeURIComponent(content?.title)}`);
  };

  const handleWatchlistClick = (e) => {
    e?.stopPropagation();
    if (isInWatchlist) {
      onRemoveFromWatchlist?.(content?.id);
      setIsInWatchlist(false);
    } else {
      onAddToWatchlist?.(content);
      setIsInWatchlist(true);
    }
  };

  const handleCardClick = () => {
    navigate(`/video-player?id=${content?.id}&title=${encodeURIComponent(content?.title)}`);
  };

  const formatDuration = (minutes) => {
    if (!minutes) return '';
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;
  };

  const getRatingColor = (rating) => {
    if (rating >= 8) return 'text-success';
    if (rating >= 6) return 'text-warning';
    return 'text-error';
  };

  const getContentTypeIcon = (type) => {
    switch (type) {
      case 'movie': return 'Film';
      case 'tv-show': return 'Tv';
      case 'documentary': return 'FileText';
      default: return 'Play';
    }
  };

  return (
    <div
      className="group relative bg-card border border-border rounded-lg overflow-hidden hover:border-primary/50 transition-all duration-300 cursor-pointer hover:shadow-elevation-2"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={handleCardClick}
    >
      {/* Thumbnail Container */}
      <div className="relative aspect-[16/9] overflow-hidden bg-muted">
        <Image
          src={content?.thumbnail}
          alt={content?.title}
          className={`w-full h-full object-cover transition-all duration-500 group-hover:scale-105 ${
            imageLoaded ? 'opacity-100' : 'opacity-0'
          }`}
          onLoad={() => setImageLoaded(true)}
        />
        
        {/* Loading Skeleton */}
        {!imageLoaded && (
          <div className="absolute inset-0 bg-muted animate-pulse flex items-center justify-center">
            <Icon name="Image" size={32} className="text-muted-foreground" />
          </div>
        )}

        {/* Overlay Gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

        {/* Content Type Badge */}
        <div className="absolute top-2 left-2">
          <div className="bg-black/70 backdrop-blur-sm rounded-md px-2 py-1 flex items-center space-x-1">
            <Icon 
              name={getContentTypeIcon(content?.type)} 
              size={12} 
              className="text-white" 
            />
            <span className="text-xs text-white font-body font-medium capitalize">
              {content?.type === 'tv-show' ? 'TV Show' : content?.type}
            </span>
          </div>
        </div>

        {/* Quality Badge */}
        {content?.quality && (
          <div className="absolute top-2 right-2">
            <div className="bg-primary text-primary-foreground text-xs px-2 py-1 rounded-md font-body font-semibold">
              {content?.quality}
            </div>
          </div>
        )}

        {/* Hover Actions */}
        <div className={`absolute inset-0 flex items-center justify-center transition-all duration-300 ${
          isHovered ? 'opacity-100' : 'opacity-0'
        }`}>
          <div className="flex items-center space-x-2">
            <Button
              variant="default"
              size="sm"
              onClick={handlePlayClick}
              className="bg-primary/90 hover:bg-primary text-white shadow-lg"
            >
              <Icon name="Play" size={16} className="mr-1" />
              Play
            </Button>
            <Button
              variant="secondary"
              size="icon"
              onClick={handleWatchlistClick}
              className="bg-black/70 hover:bg-black/80 text-white shadow-lg"
            >
              <Icon 
                name={isInWatchlist ? "Check" : "Plus"} 
                size={16} 
              />
            </Button>
          </div>
        </div>

        {/* Duration */}
        {content?.duration && (
          <div className="absolute bottom-2 right-2">
            <div className="bg-black/70 backdrop-blur-sm text-white text-xs px-2 py-1 rounded-md">
              {formatDuration(content?.duration)}
            </div>
          </div>
        )}
      </div>
      {/* Content Info */}
      <div className="p-4 space-y-2">
        {/* Title and Year */}
        <div className="space-y-1">
          <h3 className="text-base font-body font-semibold text-card-foreground line-clamp-1 group-hover:text-primary transition-colors">
            {content?.title}
          </h3>
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <span>{content?.year}</span>
            {content?.rating && (
              <>
                <span>•</span>
                <div className="flex items-center space-x-1">
                  <Icon name="Star" size={12} className="text-warning fill-current" />
                  <span className={`font-body font-medium ${getRatingColor(content?.rating)}`}>
                    {content?.rating?.toFixed(1)}
                  </span>
                </div>
              </>
            )}
            {content?.contentRating && (
              <>
                <span>•</span>
                <span className="bg-muted px-1.5 py-0.5 rounded text-xs font-body font-medium">
                  {content?.contentRating?.toUpperCase()}
                </span>
              </>
            )}
          </div>
        </div>

        {/* Genres */}
        {content?.genres && content?.genres?.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {content?.genres?.slice(0, 3)?.map((genre, index) => (
              <span
                key={index}
                className="text-xs bg-muted/50 text-muted-foreground px-2 py-1 rounded-full"
              >
                {genre}
              </span>
            ))}
            {content?.genres?.length > 3 && (
              <span className="text-xs text-muted-foreground px-2 py-1">
                +{content?.genres?.length - 3}
              </span>
            )}
          </div>
        )}

        {/* Description */}
        {content?.description && (
          <p className="text-sm text-muted-foreground line-clamp-2 leading-relaxed">
            {content?.description}
          </p>
        )}

        {/* Additional Info for TV Shows */}
        {content?.type === 'tv-show' && (content?.seasons || content?.episodes) && (
          <div className="flex items-center space-x-3 text-xs text-muted-foreground pt-1">
            {content?.seasons && (
              <div className="flex items-center space-x-1">
                <Icon name="Layers" size={12} />
                <span>{content?.seasons} Season{content?.seasons !== 1 ? 's' : ''}</span>
              </div>
            )}
            {content?.episodes && (
              <div className="flex items-center space-x-1">
                <Icon name="List" size={12} />
                <span>{content?.episodes} Episodes</span>
              </div>
            )}
          </div>
        )}
      </div>
      {/* New/Trending Badge */}
      {(content?.isNew || content?.isTrending) && (
        <div className="absolute top-4 left-4">
          <div className={`px-2 py-1 rounded-md text-xs font-body font-bold text-white ${
            content?.isNew ? 'bg-success' : 'bg-warning text-black'
          }`}>
            {content?.isNew ? 'NEW' : 'TRENDING'}
          </div>
        </div>
      )}
    </div>
  );
};

export default ContentCard;