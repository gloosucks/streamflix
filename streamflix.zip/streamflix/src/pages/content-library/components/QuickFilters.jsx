import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const QuickFilters = ({ activeFilters, onFilterChange, onClearAll }) => {
  const quickFilterOptions = [
    {
      id: 'trending',
      label: 'Trending Now',
      icon: 'TrendingUp',
      count: 45,
      color: 'bg-warning/10 text-warning border-warning/20'
    },
    {
      id: 'new-releases',
      label: 'New Releases',
      icon: 'Sparkles',
      count: 23,
      color: 'bg-success/10 text-success border-success/20'
    },
    {
      id: 'top-rated',
      label: 'Top Rated',
      icon: 'Star',
      count: 156,
      color: 'bg-accent/10 text-accent border-accent/20'
    },
    {
      id: 'recently-added',
      label: 'Recently Added',
      icon: 'Clock',
      count: 78,
      color: 'bg-primary/10 text-primary border-primary/20'
    },
    {
      id: 'award-winners',
      label: 'Award Winners',
      icon: 'Award',
      count: 89,
      color: 'bg-secondary/10 text-secondary border-secondary/20'
    },
    {
      id: 'critically-acclaimed',
      label: 'Critics Choice',
      icon: 'ThumbsUp',
      count: 67,
      color: 'bg-muted/50 text-foreground border-border'
    }
  ];

  const genreFilters = [
    { id: 'action', label: 'Action', count: 245 },
    { id: 'comedy', label: 'Comedy', count: 189 },
    { id: 'drama', label: 'Drama', count: 312 },
    { id: 'thriller', label: 'Thriller', count: 156 },
    { id: 'horror', label: 'Horror', count: 98 },
    { id: 'romance', label: 'Romance', count: 134 },
    { id: 'sci-fi', label: 'Sci-Fi', count: 87 },
    { id: 'documentary', label: 'Documentary', count: 76 }
  ];

  const handleQuickFilterClick = (filterId) => {
    const isActive = activeFilters?.quickFilters?.includes(filterId);
    const updatedQuickFilters = isActive
      ? activeFilters?.quickFilters?.filter(f => f !== filterId)
      : [...(activeFilters?.quickFilters || []), filterId];
    
    onFilterChange({
      ...activeFilters,
      quickFilters: updatedQuickFilters
    });
  };

  const handleGenreClick = (genreId) => {
    const isActive = activeFilters?.genres?.includes(genreId);
    const updatedGenres = isActive
      ? activeFilters?.genres?.filter(g => g !== genreId)
      : [...(activeFilters?.genres || []), genreId];
    
    onFilterChange({
      ...activeFilters,
      genres: updatedGenres
    });
  };

  const getActiveFilterCount = () => {
    return (activeFilters?.quickFilters?.length || 0) + 
           (activeFilters?.genres?.length || 0);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Icon name="Zap" size={20} className="text-primary" />
          <h2 className="text-lg font-heading font-semibold text-foreground">
            Quick Filters
          </h2>
          {getActiveFilterCount() > 0 && (
            <div className="bg-primary text-primary-foreground text-xs px-2 py-1 rounded-full">
              {getActiveFilterCount()}
            </div>
          )}
        </div>
        {getActiveFilterCount() > 0 && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onClearAll}
            className="text-muted-foreground hover:text-foreground"
          >
            <Icon name="X" size={16} className="mr-2" />
            Clear All
          </Button>
        )}
      </div>
      {/* Special Collections */}
      <div className="space-y-3">
        <h3 className="text-sm font-body font-semibold text-foreground flex items-center">
          <Icon name="Collection" size={16} className="mr-2 text-muted-foreground" />
          Special Collections
        </h3>
        <div className="flex flex-wrap gap-2">
          {quickFilterOptions?.map((filter) => {
            const isActive = activeFilters?.quickFilters?.includes(filter?.id);
            return (
              <Button
                key={filter?.id}
                variant={isActive ? "default" : "outline"}
                size="sm"
                onClick={() => handleQuickFilterClick(filter?.id)}
                className={`${
                  isActive 
                    ? 'bg-primary text-primary-foreground border-primary' 
                    : `${filter?.color} hover:bg-opacity-20`
                } transition-all duration-200`}
              >
                <Icon name={filter?.icon} size={14} className="mr-2" />
                {filter?.label}
                <span className={`ml-2 text-xs px-1.5 py-0.5 rounded-full ${
                  isActive 
                    ? 'bg-primary-foreground/20 text-primary-foreground' 
                    : 'bg-current/20'
                }`}>
                  {filter?.count}
                </span>
              </Button>
            );
          })}
        </div>
      </div>
      {/* Popular Genres */}
      <div className="space-y-3">
        <h3 className="text-sm font-body font-semibold text-foreground flex items-center">
          <Icon name="Tag" size={16} className="mr-2 text-muted-foreground" />
          Popular Genres
        </h3>
        <div className="flex flex-wrap gap-2">
          {genreFilters?.map((genre) => {
            const isActive = activeFilters?.genres?.includes(genre?.id);
            return (
              <Button
                key={genre?.id}
                variant={isActive ? "default" : "outline"}
                size="sm"
                onClick={() => handleGenreClick(genre?.id)}
                className={`${
                  isActive 
                    ? 'bg-primary text-primary-foreground border-primary' 
                    : 'hover:bg-muted/50'
                } transition-all duration-200`}
              >
                {genre?.label}
                <span className={`ml-2 text-xs px-1.5 py-0.5 rounded-full ${
                  isActive 
                    ? 'bg-primary-foreground/20 text-primary-foreground' 
                    : 'bg-muted text-muted-foreground'
                }`}>
                  {genre?.count}
                </span>
              </Button>
            );
          })}
        </div>
      </div>
      {/* Active Filters Summary */}
      {getActiveFilterCount() > 0 && (
        <div className="bg-muted/30 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Icon name="Filter" size={16} className="text-muted-foreground" />
              <span className="text-sm font-body font-medium text-foreground">
                {getActiveFilterCount()} filter{getActiveFilterCount() !== 1 ? 's' : ''} applied
              </span>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClearAll}
              className="text-primary hover:text-primary/80"
            >
              Reset
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default QuickFilters;