import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import Header from '../../components/ui/Header';
import FilterSidebar from './components/FilterSidebar';
import ContentGrid from './components/ContentGrid';
import ViewControls from './components/ViewControls';
import QuickFilters from './components/QuickFilters';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';

const ContentLibrary = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();

  // State management
  const [isFilterSidebarOpen, setIsFilterSidebarOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState(searchParams?.get('q') || '');
  const [isLoading, setIsLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [viewMode, setViewMode] = useState('grid');
  
  // Filter state
  const [filters, setFilters] = useState({
    genres: [],
    ratings: [],
    years: [],
    contentTypes: ['all'],
    sortBy: 'popularity',
    quickFilters: []
  });

  // Mock content data
  const [allContent] = useState([
    {
      id: 1,
      title: "Stranger Things",
      type: "tv-show",
      year: 2016,
      rating: 8.7,
      contentRating: "tv-14",
      duration: 51,
      seasons: 4,
      episodes: 42,
      genres: ["Drama", "Fantasy", "Horror"],
      thumbnail: "https://images.unsplash.com/photo-1489599511986-c2c5c8b8e0b5?w=800&h=450&fit=crop",
      description: "When a young boy vanishes, a small town uncovers a mystery involving secret experiments, terrifying supernatural forces, and one strange little girl.",
      quality: "4K",
      isNew: false,
      isTrending: true,
      isInWatchlist: false
    },
    {
      id: 2,
      title: "The Dark Knight",
      type: "movie",
      year: 2008,
      rating: 9.0,
      contentRating: "pg-13",
      duration: 152,
      genres: ["Action", "Crime", "Drama"],
      thumbnail: "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=800&h=450&fit=crop",
      description: "When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests.",
      quality: "HD",
      isNew: false,
      isTrending: false,
      isInWatchlist: true
    },
    {
      id: 3,
      title: "Wednesday",
      type: "tv-show",
      year: 2022,
      rating: 8.1,
      contentRating: "tv-14",
      duration: 45,
      seasons: 1,
      episodes: 8,
      genres: ["Comedy", "Crime", "Family"],
      thumbnail: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=800&h=450&fit=crop",
      description: "Follows Wednesday Addams' years as a student at Nevermore Academy, where she attempts to master her emerging psychic ability.",
      quality: "4K",
      isNew: true,
      isTrending: true,
      isInWatchlist: false
    },
    {
      id: 4,
      title: "Avatar: The Way of Water",
      type: "movie",
      year: 2022,
      rating: 7.6,
      contentRating: "pg-13",
      duration: 192,
      genres: ["Action", "Adventure", "Drama"],
      thumbnail: "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=800&h=450&fit=crop",
      description: "Jake Sully lives with his newfound family formed on the extrasolar moon Pandora. Once a familiar threat returns to finish what was previously started.",
      quality: "4K",
      isNew: true,
      isTrending: false,
      isInWatchlist: false
    },
    {
      id: 5,
      title: "The Crown",
      type: "tv-show",
      year: 2016,
      rating: 8.6,
      contentRating: "tv-ma",
      duration: 58,
      seasons: 6,
      episodes: 60,
      genres: ["Biography", "Drama", "History"],
      thumbnail: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=450&fit=crop",
      description: "Follows the political rivalries and romance of Queen Elizabeth II's reign and the events that shaped the second half of the twentieth century.",
      quality: "HD",
      isNew: false,
      isTrending: false,
      isInWatchlist: true
    },
    {
      id: 6,
      title: "Top Gun: Maverick",
      type: "movie",
      year: 2022,
      rating: 8.3,
      contentRating: "pg-13",
      duration: 130,
      genres: ["Action", "Drama"],
      thumbnail: "https://images.unsplash.com/photo-1583884962692-e70c57e9b28a?w=800&h=450&fit=crop",
      description: "After thirty years, Maverick is still pushing the envelope as a top naval aviator, but must confront ghosts of his past when he leads TOP GUN's elite graduates.",
      quality: "4K",
      isNew: false,
      isTrending: true,
      isInWatchlist: false
    },
    {
      id: 7,
      title: "Ozark",
      type: "tv-show",
      year: 2017,
      rating: 8.4,
      contentRating: "tv-ma",
      duration: 60,
      seasons: 4,
      episodes: 44,
      genres: ["Crime", "Drama", "Thriller"],
      thumbnail: "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=800&h=450&fit=crop",
      description: "A financial advisor drags his family from Chicago to the Missouri Ozarks, where he must launder money to appease a drug boss.",
      quality: "HD",
      isNew: false,
      isTrending: false,
      isInWatchlist: true
    },
    {
      id: 8,
      title: "Dune",
      type: "movie",
      year: 2021,
      rating: 8.0,
      contentRating: "pg-13",
      duration: 155,
      genres: ["Action", "Adventure", "Drama"],
      thumbnail: "https://images.unsplash.com/photo-1446776877081-d282a0f896e2?w=800&h=450&fit=crop",
      description: "Feature adaptation of Frank Herbert's science fiction novel about the son of a noble family entrusted with the protection of the most valuable asset.",
      quality: "4K",
      isNew: false,
      isTrending: false,
      isInWatchlist: false
    },
    {
      id: 9,
      title: "The Witcher",
      type: "tv-show",
      year: 2019,
      rating: 8.2,
      contentRating: "tv-ma",
      duration: 60,
      seasons: 3,
      episodes: 24,
      genres: ["Action", "Adventure", "Drama"],
      thumbnail: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=800&h=450&fit=crop",
      description: "Geralt of Rivia, a solitary monster hunter, struggles to find his place in a world where people often prove more wicked than beasts.",
      quality: "4K",
      isNew: false,
      isTrending: true,
      isInWatchlist: false
    },
    {
      id: 10,
      title: "Everything Everywhere All at Once",
      type: "movie",
      year: 2022,
      rating: 7.8,
      contentRating: "r",
      duration: 139,
      genres: ["Action", "Adventure", "Comedy"],
      thumbnail: "https://images.unsplash.com/photo-1489599511986-c2c5c8b8e0b5?w=800&h=450&fit=crop",
      description: "An aging Chinese immigrant is swept up in an insane adventure, where she alone can save what's important to her by connecting with the lives she could have led.",
      quality: "HD",
      isNew: true,
      isTrending: false,
      isInWatchlist: false
    },
    {
      id: 11,
      title: "House of the Dragon",
      type: "tv-show",
      year: 2022,
      rating: 8.5,
      contentRating: "tv-ma",
      duration: 68,
      seasons: 1,
      episodes: 10,
      genres: ["Action", "Adventure", "Drama"],
      thumbnail: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=450&fit=crop",
      description: "An internal succession war within House Targaryen at the height of its power, 172 years before the birth of Daenerys Targaryen.",
      quality: "4K",
      isNew: true,
      isTrending: true,
      isInWatchlist: true
    },
    {
      id: 12,
      title: "Black Panther: Wakanda Forever",
      type: "movie",
      year: 2022,
      rating: 6.7,
      contentRating: "pg-13",
      duration: 161,
      genres: ["Action", "Adventure", "Drama"],
      thumbnail: "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=800&h=450&fit=crop",
      description: "The people of Wakanda fight to protect their home from intervening world powers as they mourn the death of King T'Challa.",
      quality: "4K",
      isNew: false,
      isTrending: false,
      isInWatchlist: false
    }
  ]);

  const [filteredContent, setFilteredContent] = useState(allContent);
  const [displayedContent, setDisplayedContent] = useState([]);

  // Filter and search content
  useEffect(() => {
    let filtered = [...allContent];

    // Apply search query
    if (searchQuery?.trim()) {
      filtered = filtered?.filter(item =>
        item?.title?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
        item?.description?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
        item?.genres?.some(genre => genre?.toLowerCase()?.includes(searchQuery?.toLowerCase()))
      );
    }

    // Apply genre filters
    if (filters?.genres?.length > 0) {
      filtered = filtered?.filter(item =>
        filters?.genres?.some(genre =>
          item?.genres?.some(itemGenre => itemGenre?.toLowerCase() === genre)
        )
      );
    }

    // Apply content type filters
    if (!filters?.contentTypes?.includes('all')) {
      filtered = filtered?.filter(item =>
        filters?.contentTypes?.includes(item?.type)
      );
    }

    // Apply rating filters
    if (filters?.ratings?.length > 0) {
      filtered = filtered?.filter(item =>
        filters?.ratings?.includes(item?.contentRating)
      );
    }

    // Apply year filters
    if (filters?.years?.length > 0) {
      filtered = filtered?.filter(item => {
        return filters?.years?.some(yearRange => {
          if (yearRange === 'before-2000') return item?.year < 2000;
          if (yearRange === '2000-2009') return item?.year >= 2000 && item?.year <= 2009;
          if (yearRange === '2010-2014') return item?.year >= 2010 && item?.year <= 2014;
          if (yearRange === '2015-2017') return item?.year >= 2015 && item?.year <= 2017;
          return item?.year?.toString() === yearRange;
        });
      });
    }

    // Apply quick filters
    if (filters?.quickFilters?.length > 0) {
      filtered = filtered?.filter(item => {
        return filters?.quickFilters?.some(quickFilter => {
          switch (quickFilter) {
            case 'trending': return item?.isTrending;
            case 'new-releases': return item?.isNew;
            case 'top-rated': return item?.rating >= 8.0;
            case 'recently-added': return item?.year >= 2022;
            case 'award-winners': return item?.rating >= 8.5;
            case 'critically-acclaimed': return item?.rating >= 8.0;
            default: return false;
          }
        });
      });
    }

    // Apply sorting
    filtered?.sort((a, b) => {
      switch (filters?.sortBy) {
        case 'newest':
          return b?.year - a?.year;
        case 'oldest':
          return a?.year - b?.year;
        case 'rating':
          return b?.rating - a?.rating;
        case 'alphabetical':
          return a?.title?.localeCompare(b?.title);
        case 'duration':
          return (b?.duration || 0) - (a?.duration || 0);
        case 'popularity':
        default:
          return (b?.isTrending ? 1 : 0) - (a?.isTrending ? 1 : 0);
      }
    });

    setFilteredContent(filtered);
    setCurrentPage(1);
  }, [searchQuery, filters, allContent]);

  // Paginate content
  useEffect(() => {
    const itemsPerPage = 12;
    const startIndex = 0;
    const endIndex = currentPage * itemsPerPage;
    const paginatedContent = filteredContent?.slice(startIndex, endIndex);
    
    setDisplayedContent(paginatedContent);
    setHasMore(endIndex < filteredContent?.length);
  }, [filteredContent, currentPage]);

  // Handle search
  const handleSearch = (e) => {
    e?.preventDefault();
    if (searchQuery?.trim()) {
      setSearchParams({ q: searchQuery?.trim() });
    } else {
      setSearchParams({});
    }
  };

  const handleSearchInputChange = (e) => {
    setSearchQuery(e?.target?.value);
  };

  // Handle filters
  const handleFiltersChange = (newFilters) => {
    setFilters(newFilters);
  };

  const handleQuickFiltersChange = (newFilters) => {
    setFilters(prev => ({
      ...prev,
      ...newFilters
    }));
  };

  const clearAllFilters = () => {
    setFilters({
      genres: [],
      ratings: [],
      years: [],
      contentTypes: ['all'],
      sortBy: 'popularity',
      quickFilters: []
    });
    setSearchQuery('');
    setSearchParams({});
  };

  // Handle watchlist
  const handleAddToWatchlist = (content) => {
    // Mock implementation - in real app, this would call an API
    console.log('Added to watchlist:', content?.title);
  };

  const handleRemoveFromWatchlist = (contentId) => {
    // Mock implementation - in real app, this would call an API
    console.log('Removed from watchlist:', contentId);
  };

  // Handle pagination
  const handleLoadMore = () => {
    setIsLoading(true);
    setTimeout(() => {
      setCurrentPage(prev => prev + 1);
      setIsLoading(false);
    }, 1000);
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Handle view mode
  const handleViewModeChange = (mode) => {
    setViewMode(mode);
  };

  const handleSortChange = (sortBy) => {
    setFilters(prev => ({ ...prev, sortBy }));
  };

  const totalPages = Math.ceil(filteredContent?.length / 12);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="flex pt-16">
        {/* Filter Sidebar */}
        <FilterSidebar
          isOpen={isFilterSidebarOpen}
          onClose={() => setIsFilterSidebarOpen(false)}
          filters={filters}
          onFiltersChange={handleFiltersChange}
          contentCounts={{ total: filteredContent?.length }}
        />

        {/* Main Content */}
        <div className="flex-1 lg:ml-0">
          <div className="max-w-7xl mx-auto px-4 lg:px-6 py-6 space-y-6">
            {/* Page Header */}
            <div className="space-y-4">
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
                <div>
                  <h1 className="text-2xl lg:text-3xl font-heading font-bold text-foreground">
                    Content Library
                  </h1>
                  <p className="text-muted-foreground mt-1">
                    Discover and explore our complete collection of movies and TV shows
                  </p>
                </div>
                
                {/* Mobile Filter Toggle */}
                <div className="flex items-center space-x-3 lg:hidden">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setIsFilterSidebarOpen(true)}
                  >
                    <Icon name="Filter" size={16} className="mr-2" />
                    Filters
                    {(filters?.genres?.length + filters?.ratings?.length + filters?.years?.length + (filters?.quickFilters?.length || 0)) > 0 && (
                      <span className="ml-2 bg-primary text-primary-foreground text-xs px-1.5 py-0.5 rounded-full">
                        {filters?.genres?.length + filters?.ratings?.length + filters?.years?.length + (filters?.quickFilters?.length || 0)}
                      </span>
                    )}
                  </Button>
                </div>
              </div>

              {/* Search Bar */}
              <form onSubmit={handleSearch} className="relative max-w-2xl">
                <Input
                  type="search"
                  placeholder="Search movies, TV shows, documentaries..."
                  value={searchQuery}
                  onChange={handleSearchInputChange}
                  className="pl-12 pr-4 py-3 text-base"
                />
                <div className="absolute left-4 top-1/2 transform -translate-y-1/2">
                  <Icon name="Search" size={20} className="text-muted-foreground" />
                </div>
                <Button
                  type="submit"
                  variant="ghost"
                  size="icon"
                  className="absolute right-2 top-1/2 transform -translate-y-1/2 h-8 w-8"
                >
                  <Icon name="ArrowRight" size={16} />
                </Button>
              </form>
            </div>

            {/* Quick Filters */}
            <QuickFilters
              activeFilters={filters}
              onFilterChange={handleQuickFiltersChange}
              onClearAll={clearAllFilters}
            />

            {/* View Controls */}
            <ViewControls
              viewMode={viewMode}
              onViewModeChange={handleViewModeChange}
              sortBy={filters?.sortBy}
              onSortChange={handleSortChange}
              totalResults={filteredContent?.length}
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={handlePageChange}
            />

            {/* Desktop Filter Toggle */}
            <div className="hidden lg:block">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsFilterSidebarOpen(!isFilterSidebarOpen)}
                className="mb-4"
              >
                <Icon name="Filter" size={16} className="mr-2" />
                {isFilterSidebarOpen ? 'Hide' : 'Show'} Advanced Filters
                {(filters?.genres?.length + filters?.ratings?.length + filters?.years?.length + (filters?.quickFilters?.length || 0)) > 0 && (
                  <span className="ml-2 bg-primary text-primary-foreground text-xs px-1.5 py-0.5 rounded-full">
                    {filters?.genres?.length + filters?.ratings?.length + filters?.years?.length + (filters?.quickFilters?.length || 0)}
                  </span>
                )}
              </Button>
            </div>

            {/* Content Grid */}
            <ContentGrid
              content={displayedContent}
              loading={isLoading}
              hasMore={hasMore}
              onLoadMore={handleLoadMore}
              onAddToWatchlist={handleAddToWatchlist}
              onRemoveFromWatchlist={handleRemoveFromWatchlist}
              viewMode={viewMode}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContentLibrary;