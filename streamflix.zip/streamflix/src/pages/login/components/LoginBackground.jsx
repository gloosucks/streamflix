import React from 'react';
import Image from '../../../components/AppImage';

const LoginBackground = () => {
  const backgroundImages = [
    {
      id: 1,
      src: 'https://images.unsplash.com/photo-1489599904472-af35ff2ea150?w=800&h=600&fit=crop',
      alt: 'Streaming content background'
    },
    {
      id: 2,
      src: 'https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?w=800&h=600&fit=crop',
      alt: 'Entertainment background'
    },
    {
      id: 3,
      src: 'https://images.pixabay.com/photo/2019/04/26/07/14/store-4156934_1280.jpg?w=800&h=600&fit=crop',
      alt: 'Movie theater background'
    }
  ];

  return (
    <div className="absolute inset-0 overflow-hidden">
      {/* Background Grid */}
      <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2 h-full opacity-20">
        {Array.from({ length: 24 }, (_, index) => {
          const image = backgroundImages?.[index % backgroundImages?.length];
          return (
            <div key={index} className="relative overflow-hidden rounded-md">
              <Image
                src={image?.src}
                alt={image?.alt}
                className="w-full h-full object-cover transform scale-110 hover:scale-100 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />
            </div>
          );
        })}
      </div>
      {/* Overlay Gradients */}
      <div className="absolute inset-0 bg-gradient-to-br from-background/95 via-background/90 to-background/95" />
      <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-background/50" />
      {/* Animated Elements */}
      <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-primary/10 rounded-full blur-3xl animate-pulse" />
      <div className="absolute bottom-1/3 right-1/4 w-48 h-48 bg-accent/10 rounded-full blur-3xl animate-pulse delay-1000" />
      {/* Brand Elements */}
      <div className="absolute top-8 left-8 opacity-30">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-primary/50 rounded blur-sm" />
          <div className="w-24 h-4 bg-foreground/20 rounded blur-sm" />
        </div>
      </div>
      <div className="absolute bottom-8 right-8 opacity-20">
        <div className="grid grid-cols-2 gap-2">
          {[1, 2, 3, 4]?.map((item) => (
            <div key={item} className="w-12 h-8 bg-foreground/10 rounded blur-sm" />
          ))}
        </div>
      </div>
    </div>
  );
};

export default LoginBackground;