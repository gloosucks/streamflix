import React from 'react';
import Icon from '../../../components/AppIcon';

const TrustSignals = () => {
  const trustFeatures = [
    {
      icon: 'Shield',
      title: 'Secure Login',
      description: 'SSL encrypted authentication'
    },
    {
      icon: 'Lock',
      title: 'Privacy Protected',
      description: 'Your data is safe with us'
    },
    {
      icon: 'Zap',
      title: 'Instant Access',
      description: 'Start streaming immediately'
    }
  ];

  const securityBadges = [
    {
      icon: 'ShieldCheck',
      label: 'SSL Secured'
    },
    {
      icon: 'Award',
      label: 'Trusted Platform'
    },
    {
      icon: 'Users',
      label: '10M+ Users'
    }
  ];

  return (
    <div className="w-full">
      {/* Trust Features */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {trustFeatures?.map((feature, index) => (
          <div key={index} className="text-center">
            <div className="flex items-center justify-center w-12 h-12 bg-primary/10 rounded-full mx-auto mb-3">
              <Icon name={feature?.icon} size={20} className="text-primary" />
            </div>
            <h3 className="text-sm font-body font-semibold text-foreground mb-1">
              {feature?.title}
            </h3>
            <p className="text-xs text-muted-foreground">
              {feature?.description}
            </p>
          </div>
        ))}
      </div>
      {/* Security Badges */}
      <div className="flex items-center justify-center space-x-6 py-4 border-t border-border">
        {securityBadges?.map((badge, index) => (
          <div key={index} className="flex items-center space-x-2 text-muted-foreground">
            <Icon name={badge?.icon} size={16} />
            <span className="text-xs font-body">{badge?.label}</span>
          </div>
        ))}
      </div>
      {/* Legal Links */}
      <div className="text-center mt-6">
        <div className="flex items-center justify-center space-x-4 text-xs text-muted-foreground">
          <a href="#" className="hover:text-foreground transition-colors">
            Privacy Policy
          </a>
          <span>•</span>
          <a href="#" className="hover:text-foreground transition-colors">
            Terms of Service
          </a>
          <span>•</span>
          <a href="#" className="hover:text-foreground transition-colors">
            Help Center
          </a>
        </div>
        <p className="text-xs text-muted-foreground mt-2">
          © {new Date()?.getFullYear()} StreamFlix. All rights reserved.
        </p>
      </div>
    </div>
  );
};

export default TrustSignals;