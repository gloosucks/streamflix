import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import LoginForm from './components/LoginForm';
import LoginBackground from './components/LoginBackground';
import TrustSignals from './components/TrustSignals';

const LoginPage = () => {
  const navigate = useNavigate();

  // Check if user is already authenticated
  useEffect(() => {
    const token = localStorage.getItem('authToken');
    if (token) {
      navigate('/content-library');
    }
  }, [navigate]);

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Background */}
      <LoginBackground />
      {/* Main Content */}
      <div className="relative z-10 min-h-screen flex flex-col">
        {/* Header Spacer */}
        <div className="h-16" />
        
        {/* Login Content */}
        <div className="flex-1 flex items-center justify-center px-4 py-8">
          <div className="w-full max-w-6xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              {/* Left Column - Branding & Info */}
              <div className="hidden lg:block">
                <div className="max-w-lg">
                  <h1 className="text-4xl font-heading font-bold text-foreground mb-6">
                    Stream Your Favorite Shows
                  </h1>
                  <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                    Access thousands of movies, TV shows, and documentaries. 
                    Watch anywhere, anytime, on any device.
                  </p>
                  
                  {/* Features List */}
                  <div className="space-y-4 mb-8">
                    {[
                      'Unlimited streaming on all devices',
                      'No ads, no interruptions',
                      'Download for offline viewing',
                      'Cancel anytime'
                    ]?.map((feature, index) => (
                      <div key={index} className="flex items-center space-x-3">
                        <div className="w-5 h-5 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                          <div className="w-2 h-2 bg-white rounded-full" />
                        </div>
                        <span className="text-foreground">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Right Column - Login Form */}
              <div className="w-full">
                <LoginForm />
              </div>
            </div>
          </div>
        </div>

        {/* Trust Signals Footer */}
        <div className="relative z-10 px-4 py-8">
          <div className="max-w-4xl mx-auto">
            <TrustSignals />
          </div>
        </div>
      </div>
      {/* Mobile Branding */}
      <div className="lg:hidden absolute top-20 left-0 right-0 z-20 text-center px-4">
        <h1 className="text-2xl font-heading font-bold text-foreground mb-2">
          StreamFlix
        </h1>
        <p className="text-muted-foreground text-sm">
          Your entertainment destination
        </p>
      </div>
    </div>
  );
};

export default LoginPage;