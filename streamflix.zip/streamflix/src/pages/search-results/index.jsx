import React, { useState, useEffect, useRef } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import Icon from '../../components/AppIcon';
import Input from '../../components/ui/Input';
import Button from '../../components/ui/Button';
import SearchFilters from './components/SearchFilters';
import SearchSuggestions from './components/SearchSuggestions';
import SearchResultCard from './components/SearchResultCard';
import SearchSortOptions from './components/SearchSortOptions';
import SearchResultsList from './components/SearchResultsList';
import EmptySearchState from './components/EmptySearchState';

const SearchResults = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const [query, setQuery] = useState(searchParams?.get('q') || '');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [results, setResults] = useState([]);
  const [sortBy, setSortBy] = useState('relevance');
  const [sortOrder, setSortOrder] = useState('desc');
  const [viewMode, setViewMode] = useState('grid');
  const [filters, setFilters] = useState({
    contentType: 'all',
    genre: 'all',
    year: 'all',
    rating: 'all',
    hdQuality: false,
    recentlyAdded: false,
    freeToWatch: false,
    awardWinners: false
  });

  const searchRef = useRef(null);
  const containerRef = useRef(null);

  // Mock search results data
  const mockResults = [
    {
      id: 1,
      title: "Stranger Things",
      description: "When a young boy vanishes, a small town uncovers a mystery involving secret experiments, terrifying supernatural forces, and one strange little girl.",
      thumbnail: "https://images.unsplash.com/photo-1489599511986-c2c5c6e2c2c2?w=400&h=600&fit=crop",
      type: "tv-show",
      genre: "Sci-Fi",
      year: 2016,
      rating: 8.7,
      duration: "51m",
      tags: ["supernatural", "80s", "friendship", "mystery"],
      inWatchlist: false
    },
    {
      id: 2,
      title: "The Crown",
      description: "Follows the political rivalries and romance of Queen Elizabeth II\'s reign and the events that shaped the second half of the twentieth century.",
      thumbnail: "https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?w=400&h=600&fit=crop",
      type: "tv-show",
      genre: "Drama",
      year: 2016,
      rating: 8.6,
      duration: "58m",
      tags: ["historical", "royal family", "politics", "biography"],
      inWatchlist: true
    },
    {
      id: 3,
      title: "Squid Game",
      description: "Hundreds of cash-strapped players accept a strange invitation to compete in children's games for a tempting prize, but the stakes are deadly.",
      thumbnail: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=400&h=600&fit=crop",
      type: "tv-show",
      genre: "Thriller",
      year: 2021,
      rating: 8.0,
      duration: "56m",
      tags: ["survival", "korean", "psychological", "competition"],
      inWatchlist: false
    },
    {
      id: 4,
      title: "Wednesday",
      description: "Smart, sarcastic and a little dead inside, Wednesday Addams investigates a murder spree while navigating her years at Nevermore Academy.",
      thumbnail: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=600&fit=crop",
      type: "tv-show",
      genre: "Comedy",
      year: 2022,
      rating: 8.1,
      duration: "45m",
      tags: ["supernatural", "teen", "mystery", "dark comedy"],
      inWatchlist: false
    },
    {
      id: 5,
      title: "The Witcher",
      description: "Geralt of Rivia, a solitary monster hunter, struggles to find his place in a world where people often prove more wicked than beasts.",
      thumbnail: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=600&fit=crop",
      type: "tv-show",
      genre: "Fantasy",
      year: 2019,
      rating: 8.2,
      duration: "60m",
      tags: ["fantasy", "magic", "adventure", "medieval"],
      inWatchlist: true
    },
    {
      id: 6,
      title: "Ozark",
      description: "A financial advisor drags his family from Chicago to the Missouri Ozarks, where he must launder money to appease a drug boss.",
      thumbnail: "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=400&h=600&fit=crop",
      type: "tv-show",
      genre: "Crime",
      year: 2017,
      rating: 8.4,
      duration: "60m",
      tags: ["crime", "family", "money laundering", "thriller"],
      inWatchlist: false
    },
    {
      id: 7,
      title: "Dark",
      description: "A family saga with a supernatural twist, set in a German town where the disappearance of two young children exposes the relationships among four families.",
      thumbnail: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=600&fit=crop",
      type: "tv-show",
      genre: "Sci-Fi",
      year: 2017,
      rating: 8.8,
      duration: "60m",
      tags: ["time travel", "german", "mystery", "complex"],
      inWatchlist: false
    },
    {
      id: 8,
      title: "Money Heist",
      description: "An unusual group of robbers attempt to carry out the most perfect robbery in Spanish history - stealing 2.4 billion euros from the Royal Mint of Spain.",
      thumbnail: "https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?w=400&h=600&fit=crop",
      type: "tv-show",
      genre: "Crime",
      year: 2017,
      rating: 8.3,
      duration: "70m",
      tags: ["heist", "spanish", "strategy", "resistance"],
      inWatchlist: true
    }
  ];

  // Filter and sort results based on current settings
  const getFilteredResults = () => {
    let filtered = mockResults;

    // Apply search query filter
    if (query?.trim()) {
      filtered = filtered?.filter(item =>
        item?.title?.toLowerCase()?.includes(query?.toLowerCase()) ||
        item?.description?.toLowerCase()?.includes(query?.toLowerCase()) ||
        item?.genre?.toLowerCase()?.includes(query?.toLowerCase()) ||
        item?.tags?.some(tag => tag?.toLowerCase()?.includes(query?.toLowerCase()))
      );
    }

    // Apply filters
    if (filters?.contentType !== 'all') {
      filtered = filtered?.filter(item => item?.type === filters?.contentType);
    }

    if (filters?.genre !== 'all') {
      filtered = filtered?.filter(item => 
        item?.genre?.toLowerCase() === filters?.genre?.toLowerCase()
      );
    }

    if (filters?.year !== 'all') {
      if (filters?.year?.includes('s')) {
        const decade = parseInt(filters?.year);
        filtered = filtered?.filter(item => 
          item?.year >= decade && item?.year < decade + 10
        );
      } else {
        filtered = filtered?.filter(item => item?.year?.toString() === filters?.year);
      }
    }

    if (filters?.rating !== 'all') {
      const minRating = parseFloat(filters?.rating?.replace('+', ''));
      filtered = filtered?.filter(item => item?.rating >= minRating);
    }

    if (filters?.recentlyAdded) {
      filtered = filtered?.filter(item => item?.year >= 2022);
    }

    if (filters?.awardWinners) {
      filtered = filtered?.filter(item => item?.rating >= 8.5);
    }

    // Apply sorting
    filtered?.sort((a, b) => {
      let comparison = 0;
      
      switch (sortBy) {
        case 'title':
          comparison = a?.title?.localeCompare(b?.title);
          break;
        case 'rating':
          comparison = a?.rating - b?.rating;
          break;
        case 'release-date':
          comparison = a?.year - b?.year;
          break;
        case 'popularity':
          comparison = a?.rating - b?.rating; // Using rating as popularity proxy
          break;
        case 'duration':
          const aDuration = parseInt(a?.duration);
          const bDuration = parseInt(b?.duration);
          comparison = aDuration - bDuration;
          break;
        case 'recently-added':
          comparison = a?.year - b?.year;
          break;
        default: // relevance
          if (query?.trim()) {
            const aRelevance = a?.title?.toLowerCase()?.includes(query?.toLowerCase()) ? 2 : 1;
            const bRelevance = b?.title?.toLowerCase()?.includes(query?.toLowerCase()) ? 2 : 1;
            comparison = bRelevance - aRelevance;
          } else {
            comparison = b?.rating - a?.rating;
          }
      }

      return sortOrder === 'asc' ? comparison : -comparison;
    });

    return filtered;
  };

  const filteredResults = getFilteredResults();

  // Handle search
  useEffect(() => {
    const queryParam = searchParams?.get('q');
    if (queryParam) {
      setQuery(queryParam);
      performSearch(queryParam);
    }
  }, [searchParams]);

  const performSearch = async (searchQuery) => {
    setIsLoading(true);
    setShowSuggestions(false);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));
    
    setResults(getFilteredResults());
    setIsLoading(false);
  };

  const handleSearchSubmit = (e) => {
    e?.preventDefault();
    if (query?.trim()) {
      setSearchParams({ q: query?.trim() });
      performSearch(query?.trim());
    }
  };

  const handleSearchChange = (e) => {
    const value = e?.target?.value;
    setQuery(value);
    
    if (value?.trim()) {
      setShowSuggestions(true);
    } else {
      setShowSuggestions(false);
    }
  };

  const handleSuggestionClick = (suggestion) => {
    setQuery(suggestion);
    setSearchParams({ q: suggestion });
    setShowSuggestions(false);
    performSearch(suggestion);
  };

  const handleVoiceSearch = () => {
    if ('webkitSpeechRecognition' in window) {
      const recognition = new window.webkitSpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onresult = (event) => {
        const transcript = event?.results?.[0]?.[0]?.transcript;
        setQuery(transcript);
        setSearchParams({ q: transcript });
        performSearch(transcript);
      };

      recognition?.start();
    } else {
      alert('Voice search is not supported in your browser');
    }
  };

  const handleClearSearch = () => {
    setQuery('');
    setSearchParams({});
    setResults([]);
    setShowSuggestions(false);
  };

  const handleFiltersChange = (newFilters) => {
    setFilters(newFilters);
  };

  const handleClearFilters = () => {
    setFilters({
      contentType: 'all',
      genre: 'all',
      year: 'all',
      rating: 'all',
      hdQuality: false,
      recentlyAdded: false,
      freeToWatch: false,
      awardWinners: false
    });
  };

  const handleSortChange = (newSortBy, newSortOrder) => {
    setSortBy(newSortBy);
    setSortOrder(newSortOrder);
  };

  const handleViewModeChange = (mode) => {
    setViewMode(mode);
  };

  // Close suggestions when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (searchRef?.current && !searchRef?.current?.contains(event?.target)) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>{query ? `Search Results for "${query}" - StreamFlix` : 'Search - StreamFlix'}</title>
        <meta name="description" content={`Search for movies, TV shows, and documentaries on StreamFlix. ${query ? `Results for "${query}"` : 'Discover your next favorite content.'}`} />
      </Helmet>
      <Header />
      <main className="pt-16">
        <div className="container mx-auto px-4 py-8">
          {/* Search Header */}
          <div className="mb-8">
            <div className="max-w-4xl mx-auto">
              <h1 className="text-3xl font-heading font-bold text-foreground mb-6 text-center">
                {query ? `Search Results` : 'Search Content'}
              </h1>

              {/* Search Bar */}
              <div ref={searchRef} className="relative mb-6">
                <form onSubmit={handleSearchSubmit}>
                  <div className="relative">
                    <Input
                      type="search"
                      placeholder="Search movies, TV shows, documentaries..."
                      value={query}
                      onChange={handleSearchChange}
                      onFocus={() => query && setShowSuggestions(true)}
                      className="w-full pl-12 pr-20 py-4 text-lg bg-input border-border focus:border-primary focus:ring-primary/20"
                    />
                    
                    {/* Search Icon */}
                    <div className="absolute left-4 top-1/2 transform -translate-y-1/2">
                      <Icon name="Search" size={20} className="text-muted-foreground" />
                    </div>

                    {/* Action Buttons */}
                    <div className="absolute right-2 top-1/2 transform -translate-y-1/2 flex items-center space-x-1">
                      {query && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          onClick={handleClearSearch}
                          className="h-8 w-8"
                        >
                          <Icon name="X" size={16} />
                        </Button>
                      )}
                      
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={handleVoiceSearch}
                        className="h-8 w-8"
                        title="Voice Search"
                      >
                        <Icon name="Mic" size={16} />
                      </Button>
                      
                      <Button
                        type="submit"
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-primary hover:text-primary/80"
                      >
                        <Icon name="ArrowRight" size={16} />
                      </Button>
                    </div>
                  </div>
                </form>

                {/* Search Suggestions */}
                {showSuggestions && (
                  <SearchSuggestions
                    query={query}
                    onSuggestionClick={handleSuggestionClick}
                    onVoiceSearch={handleVoiceSearch}
                  />
                )}
              </div>

              {/* Query Display */}
              {query && (
                <div className="text-center mb-6">
                  <p className="text-muted-foreground">
                    Showing results for{' '}
                    <span className="text-foreground font-medium">"{query}"</span>
                    {filteredResults?.length > 0 && (
                      <span> • {filteredResults?.length?.toLocaleString()} results found</span>
                    )}
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Filters */}
          {query && (
            <SearchFilters
              filters={filters}
              onFiltersChange={handleFiltersChange}
              resultCount={filteredResults?.length}
              onClearFilters={handleClearFilters}
            />
          )}

          {/* Loading State */}
          {isLoading && (
            <div className="text-center py-12">
              <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
              <p className="text-muted-foreground">Searching...</p>
            </div>
          )}

          {/* Results */}
          {!isLoading && query && (
            <>
              {filteredResults?.length > 0 ? (
                <>
                  {/* Sort Options */}
                  <SearchSortOptions
                    sortBy={sortBy}
                    sortOrder={sortOrder}
                    onSortChange={handleSortChange}
                    viewMode={viewMode}
                    onViewModeChange={handleViewModeChange}
                  />

                  {/* Results Grid/List */}
                  {viewMode === 'grid' ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                      {filteredResults?.map((content) => (
                        <SearchResultCard key={content?.id} content={content} />
                      ))}
                    </div>
                  ) : (
                    <SearchResultsList results={filteredResults} />
                  )}
                </>
              ) : (
                <EmptySearchState
                  query={query}
                  onClearSearch={handleClearSearch}
                  onSuggestionClick={handleSuggestionClick}
                />
              )}
            </>
          )}

          {/* Initial State */}
          {!query && !isLoading && (
            <EmptySearchState
              query=""
              onClearSearch={handleClearSearch}
              onSuggestionClick={handleSuggestionClick}
            />
          )}
        </div>
      </main>
    </div>
  );
};

export default SearchResults;