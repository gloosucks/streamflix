import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const SearchFilters = ({ filters, onFiltersChange, resultCount, onClearFilters }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const contentTypeOptions = [
    { value: 'all', label: 'All Content' },
    { value: 'movies', label: 'Movies' },
    { value: 'tv-shows', label: 'TV Shows' },
    { value: 'documentaries', label: 'Documentaries' },
    { value: 'anime', label: 'Anime' }
  ];

  const genreOptions = [
    { value: 'all', label: 'All Genres' },
    { value: 'action', label: 'Action' },
    { value: 'comedy', label: 'Comedy' },
    { value: 'drama', label: 'Drama' },
    { value: 'horror', label: 'Horror' },
    { value: 'thriller', label: 'Thriller' },
    { value: 'romance', label: 'Romance' },
    { value: 'sci-fi', label: 'Sci-Fi' },
    { value: 'fantasy', label: 'Fantasy' },
    { value: 'crime', label: 'Crime' },
    { value: 'documentary', label: 'Documentary' }
  ];

  const yearOptions = [
    { value: 'all', label: 'All Years' },
    { value: '2024', label: '2024' },
    { value: '2023', label: '2023' },
    { value: '2022', label: '2022' },
    { value: '2021', label: '2021' },
    { value: '2020', label: '2020' },
    { value: '2010s', label: '2010-2019' },
    { value: '2000s', label: '2000-2009' },
    { value: '1990s', label: '1990-1999' }
  ];

  const ratingOptions = [
    { value: 'all', label: 'All Ratings' },
    { value: '9+', label: '9.0+ Stars' },
    { value: '8+', label: '8.0+ Stars' },
    { value: '7+', label: '7.0+ Stars' },
    { value: '6+', label: '6.0+ Stars' }
  ];

  const handleFilterChange = (key, value) => {
    onFiltersChange({
      ...filters,
      [key]: value
    });
  };

  const hasActiveFilters = Object.values(filters)?.some(value => 
    value !== 'all' && value !== false && value !== ''
  );

  return (
    <div className="bg-card border border-border rounded-lg p-4 mb-6">
      {/* Filter Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <Icon name="Filter" size={20} className="text-muted-foreground" />
          <h3 className="text-lg font-heading font-semibold text-card-foreground">
            Filters
          </h3>
          {resultCount > 0 && (
            <span className="px-2 py-1 bg-primary/10 text-primary text-sm rounded-full">
              {resultCount?.toLocaleString()} results
            </span>
          )}
        </div>
        
        <div className="flex items-center space-x-2">
          {hasActiveFilters && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onClearFilters}
              className="text-muted-foreground hover:text-foreground"
            >
              <Icon name="X" size={16} className="mr-1" />
              Clear All
            </Button>
          )}
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsExpanded(!isExpanded)}
            className="lg:hidden"
          >
            <Icon 
              name={isExpanded ? "ChevronUp" : "ChevronDown"} 
              size={16} 
            />
          </Button>
        </div>
      </div>
      {/* Filter Controls */}
      <div className={`space-y-4 ${isExpanded ? 'block' : 'hidden lg:block'}`}>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Content Type */}
          <Select
            label="Content Type"
            options={contentTypeOptions}
            value={filters?.contentType}
            onChange={(value) => handleFilterChange('contentType', value)}
            className="w-full"
          />

          {/* Genre */}
          <Select
            label="Genre"
            options={genreOptions}
            value={filters?.genre}
            onChange={(value) => handleFilterChange('genre', value)}
            className="w-full"
          />

          {/* Release Year */}
          <Select
            label="Release Year"
            options={yearOptions}
            value={filters?.year}
            onChange={(value) => handleFilterChange('year', value)}
            className="w-full"
          />

          {/* Rating */}
          <Select
            label="Minimum Rating"
            options={ratingOptions}
            value={filters?.rating}
            onChange={(value) => handleFilterChange('rating', value)}
            className="w-full"
          />
        </div>

        {/* Additional Filters */}
        <div className="flex flex-wrap gap-4 pt-2 border-t border-border">
          <Checkbox
            label="HD Quality"
            checked={filters?.hdQuality}
            onChange={(e) => handleFilterChange('hdQuality', e?.target?.checked)}
          />
          
          <Checkbox
            label="Recently Added"
            checked={filters?.recentlyAdded}
            onChange={(e) => handleFilterChange('recentlyAdded', e?.target?.checked)}
          />
          
          <Checkbox
            label="Free to Watch"
            checked={filters?.freeToWatch}
            onChange={(e) => handleFilterChange('freeToWatch', e?.target?.checked)}
          />
          
          <Checkbox
            label="Award Winners"
            checked={filters?.awardWinners}
            onChange={(e) => handleFilterChange('awardWinners', e?.target?.checked)}
          />
        </div>
      </div>
    </div>
  );
};

export default SearchFilters;