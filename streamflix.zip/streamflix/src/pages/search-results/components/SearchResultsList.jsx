import React from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const SearchResultsList = ({ results }) => {
  const navigate = useNavigate();

  const handlePlayClick = (content) => {
    navigate(`/video-player?id=${content?.id}&title=${encodeURIComponent(content?.title)}`);
  };

  const getRatingColor = (rating) => {
    if (rating >= 8.0) return 'text-success';
    if (rating >= 7.0) return 'text-warning';
    if (rating >= 6.0) return 'text-accent';
    return 'text-muted-foreground';
  };

  const getContentTypeIcon = (type) => {
    switch (type) {
      case 'movie': return 'Film';
      case 'tv-show': return 'Tv';
      case 'documentary': return 'FileText';
      case 'anime': return 'Sparkles';
      default: return 'Play';
    }
  };

  return (
    <div className="space-y-4">
      {results?.map((content) => (
        <div
          key={content?.id}
          className="group bg-card border border-border rounded-lg p-4 hover:border-primary/50 transition-all duration-300 cursor-pointer"
          onClick={() => handlePlayClick(content)}
        >
          <div className="flex space-x-4">
            {/* Thumbnail */}
            <div className="relative w-32 h-20 flex-shrink-0 overflow-hidden rounded-md">
              <Image
                src={content?.thumbnail}
                alt={content?.title}
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
              
              {/* Play Overlay */}
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-all duration-300 flex items-center justify-center">
                <div className="transform transition-all duration-300 scale-75 opacity-0 group-hover:scale-100 group-hover:opacity-100">
                  <Button
                    variant="default"
                    size="icon"
                    onClick={(e) => {
                      e?.stopPropagation();
                      handlePlayClick(content);
                    }}
                    className="w-8 h-8 rounded-full bg-primary/90 hover:bg-primary"
                  >
                    <Icon name="Play" size={14} color="white" />
                  </Button>
                </div>
              </div>

              {/* Duration */}
              {content?.duration && (
                <div className="absolute bottom-1 right-1">
                  <div className="px-1 py-0.5 bg-black/70 rounded text-xs text-white font-body">
                    {content?.duration}
                  </div>
                </div>
              )}
            </div>

            {/* Content Info */}
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center space-x-2 mb-1">
                  <Icon 
                    name={getContentTypeIcon(content?.type)} 
                    size={14} 
                    className="text-muted-foreground flex-shrink-0" 
                  />
                  <h3 className="text-lg font-heading font-semibold text-card-foreground line-clamp-1 group-hover:text-primary transition-colors">
                    {content?.title}
                  </h3>
                </div>
                
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={(e) => {
                    e?.stopPropagation();
                    // Handle watchlist toggle
                  }}
                  className="h-8 w-8 flex-shrink-0"
                >
                  <Icon name="Bookmark" size={16} className="text-muted-foreground hover:text-primary" />
                </Button>
              </div>

              {/* Metadata */}
              <div className="flex items-center space-x-3 mb-2 text-sm text-muted-foreground">
                <span>{content?.year}</span>
                {content?.genre && (
                  <>
                    <span>•</span>
                    <span>{content?.genre}</span>
                  </>
                )}
                {content?.rating && (
                  <>
                    <span>•</span>
                    <div className="flex items-center space-x-1">
                      <Icon name="Star" size={12} className="text-warning fill-current" />
                      <span className={getRatingColor(content?.rating)}>
                        {content?.rating?.toFixed(1)}
                      </span>
                    </div>
                  </>
                )}
                <span className="capitalize">{content?.type?.replace('-', ' ')}</span>
              </div>

              {/* Description */}
              <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
                {content?.description}
              </p>

              {/* Tags */}
              {content?.tags && content?.tags?.length > 0 && (
                <div className="flex flex-wrap gap-1 mb-3">
                  {content?.tags?.slice(0, 4)?.map((tag, index) => (
                    <span
                      key={index}
                      className="px-2 py-1 bg-muted/50 text-xs text-muted-foreground rounded-full"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex items-center space-x-2">
                <Button
                  variant="default"
                  size="sm"
                  onClick={(e) => {
                    e?.stopPropagation();
                    handlePlayClick(content);
                  }}
                >
                  <Icon name="Play" size={14} className="mr-1" />
                  Play
                </Button>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={(e) => {
                    e?.stopPropagation();
                    // Handle more info action
                  }}
                >
                  <Icon name="Info" size={14} className="mr-1" />
                  More Info
                </Button>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default SearchResultsList;