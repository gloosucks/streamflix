import React from 'react';
import Icon from '../../../components/AppIcon';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';

const SearchSortOptions = ({ sortBy, sortOrder, onSortChange, viewMode, onViewModeChange }) => {
  const sortOptions = [
    { value: 'relevance', label: 'Relevance' },
    { value: 'popularity', label: 'Popularity' },
    { value: 'rating', label: 'Rating' },
    { value: 'release-date', label: 'Release Date' },
    { value: 'title', label: 'Title (A-Z)' },
    { value: 'duration', label: 'Duration' },
    { value: 'recently-added', label: 'Recently Added' }
  ];

  const handleSortChange = (value) => {
    onSortChange(value, sortOrder);
  };

  const handleOrderToggle = () => {
    const newOrder = sortOrder === 'asc' ? 'desc' : 'asc';
    onSortChange(sortBy, newOrder);
  };

  const getSortIcon = () => {
    return sortOrder === 'asc' ? 'ArrowUp' : 'ArrowDown';
  };

  const getSortLabel = () => {
    const option = sortOptions?.find(opt => opt?.value === sortBy);
    return option ? option?.label : 'Relevance';
  };

  return (
    <div className="flex items-center justify-between mb-6 p-4 bg-card border border-border rounded-lg">
      {/* Sort Controls */}
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-2">
          <Icon name="ArrowUpDown" size={16} className="text-muted-foreground" />
          <span className="text-sm font-body font-medium text-card-foreground">
            Sort by:
          </span>
        </div>
        
        <div className="flex items-center space-x-2">
          <Select
            options={sortOptions}
            value={sortBy}
            onChange={handleSortChange}
            className="min-w-[140px]"
          />
          
          <Button
            variant="outline"
            size="icon"
            onClick={handleOrderToggle}
            className="h-9 w-9"
            title={`Sort ${sortOrder === 'asc' ? 'Descending' : 'Ascending'}`}
          >
            <Icon name={getSortIcon()} size={16} />
          </Button>
        </div>
      </div>

      {/* View Mode Toggle */}
      <div className="flex items-center space-x-2">
        <span className="text-sm font-body font-medium text-card-foreground hidden sm:block">
          View:
        </span>
        
        <div className="flex items-center bg-muted rounded-lg p-1">
          <Button
            variant={viewMode === 'grid' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => onViewModeChange('grid')}
            className="h-8 px-3"
          >
            <Icon name="Grid3X3" size={14} />
            <span className="ml-1 hidden sm:inline">Grid</span>
          </Button>
          
          <Button
            variant={viewMode === 'list' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => onViewModeChange('list')}
            className="h-8 px-3"
          >
            <Icon name="List" size={14} />
            <span className="ml-1 hidden sm:inline">List</span>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default SearchSortOptions;