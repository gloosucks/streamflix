import React from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Image from '../../../components/AppImage';

const EmptySearchState = ({ query, onClearSearch, onSuggestionClick }) => {
  const navigate = useNavigate();

  const trendingContent = [
    {
      id: 1,
      title: "Stranger Things",
      thumbnail: "https://images.unsplash.com/photo-1489599511986-c2c5c6e2c2c2?w=300&h=200&fit=crop",
      type: "TV Series",
      rating: 8.7
    },
    {
      id: 2,
      title: "The Crown",
      thumbnail: "https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?w=300&h=200&fit=crop",
      type: "TV Series", 
      rating: 8.6
    },
    {
      id: 3,
      title: "Squid Game",
      thumbnail: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=300&h=200&fit=crop",
      type: "TV Series",
      rating: 8.0
    },
    {
      id: 4,
      title: "Wednesday",
      thumbnail: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=300&h=200&fit=crop",
      type: "TV Series",
      rating: 8.1
    }
  ];

  const searchSuggestions = [
    "action movies",
    "comedy series",
    "sci-fi thrillers",
    "romantic comedies",
    "crime documentaries",
    "animated movies"
  ];

  const handleTrendingClick = (content) => {
    navigate(`/video-player?id=${content?.id}&title=${encodeURIComponent(content?.title)}`);
  };

  const handleBrowseAll = () => {
    navigate('/content-library');
  };

  return (
    <div className="text-center py-12">
      {/* Empty State Icon */}
      <div className="mb-6">
        <div className="w-24 h-24 mx-auto bg-muted/50 rounded-full flex items-center justify-center">
          <Icon name="Search" size={32} className="text-muted-foreground" />
        </div>
      </div>
      {/* Main Message */}
      <div className="mb-8">
        <h2 className="text-2xl font-heading font-bold text-foreground mb-2">
          {query ? `No results found for "${query}"` : 'Start your search'}
        </h2>
        <p className="text-muted-foreground max-w-md mx-auto">
          {query 
            ? "We couldn't find any movies or shows matching your search. Try different keywords or browse our trending content below."
            : "Search for movies, TV shows, documentaries, and more to discover your next favorite watch."
          }
        </p>
      </div>
      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mb-12">
        {query && (
          <Button
            variant="outline"
            onClick={onClearSearch}
            className="w-full sm:w-auto"
          >
            <Icon name="X" size={16} className="mr-2" />
            Clear Search
          </Button>
        )}
        
        <Button
          variant="default"
          onClick={handleBrowseAll}
          className="w-full sm:w-auto"
        >
          <Icon name="Grid3X3" size={16} className="mr-2" />
          Browse All Content
        </Button>
      </div>
      {/* Search Suggestions */}
      {query && (
        <div className="mb-12">
          <h3 className="text-lg font-heading font-semibold text-foreground mb-4">
            Try searching for:
          </h3>
          <div className="flex flex-wrap justify-center gap-2">
            {searchSuggestions?.map((suggestion, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                onClick={() => onSuggestionClick(suggestion)}
                className="hover:bg-primary hover:text-primary-foreground hover:border-primary"
              >
                {suggestion}
              </Button>
            ))}
          </div>
        </div>
      )}
      {/* Trending Content */}
      <div>
        <h3 className="text-lg font-heading font-semibold text-foreground mb-6">
          Trending Now
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
          {trendingContent?.map((content) => (
            <div
              key={content?.id}
              className="group bg-card border border-border rounded-lg overflow-hidden hover:border-primary/50 transition-all duration-300 cursor-pointer hover-scale"
              onClick={() => handleTrendingClick(content)}
            >
              {/* Thumbnail */}
              <div className="relative aspect-video overflow-hidden">
                <Image
                  src={content?.thumbnail}
                  alt={content?.title}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
                
                {/* Play Overlay */}
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-all duration-300 flex items-center justify-center">
                  <div className="transform transition-all duration-300 scale-75 opacity-0 group-hover:scale-100 group-hover:opacity-100">
                    <Button
                      variant="default"
                      size="icon"
                      className="w-10 h-10 rounded-full bg-primary/90 hover:bg-primary"
                    >
                      <Icon name="Play" size={16} color="white" />
                    </Button>
                  </div>
                </div>

                {/* Rating Badge */}
                <div className="absolute top-2 right-2">
                  <div className="flex items-center space-x-1 px-2 py-1 bg-black/70 rounded-full">
                    <Icon name="Star" size={10} className="text-warning fill-current" />
                    <span className="text-xs text-white font-body font-medium">
                      {content?.rating}
                    </span>
                  </div>
                </div>
              </div>

              {/* Content Info */}
              <div className="p-3">
                <h4 className="text-sm font-heading font-semibold text-card-foreground line-clamp-1 group-hover:text-primary transition-colors">
                  {content?.title}
                </h4>
                <p className="text-xs text-muted-foreground mt-1">
                  {content?.type}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default EmptySearchState;