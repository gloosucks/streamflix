import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SearchSuggestions = ({ query, onSuggestionClick, onVoiceSearch }) => {
  const suggestions = [
    "stranger things",
    "the crown",
    "squid game", 
    "wednesday",
    "the witcher",
    "ozark",
    "dark",
    "money heist"
  ];

  const trendingSearches = [
    "action movies 2024",
    "netflix originals",
    "sci-fi series",
    "comedy specials",
    "true crime documentaries"
  ];

  const recentSearches = [
    "breaking bad",
    "game of thrones",
    "the office",
    "friends"
  ];

  const filteredSuggestions = suggestions?.filter(suggestion =>
    suggestion?.toLowerCase()?.includes(query?.toLowerCase())
  )?.slice(0, 5);

  if (!query && filteredSuggestions?.length === 0) {
    return (
      <div className="absolute top-full left-0 right-0 mt-2 bg-popover border border-border rounded-lg shadow-elevation-2 z-1500 animate-slide-down">
        <div className="p-4">
          {/* Voice Search */}
          <div className="mb-4">
            <Button
              variant="outline"
              size="sm"
              onClick={onVoiceSearch}
              className="w-full justify-start"
            >
              <Icon name="Mic" size={16} className="mr-2" />
              Search with voice
            </Button>
          </div>

          {/* Recent Searches */}
          {recentSearches?.length > 0 && (
            <div className="mb-4">
              <h4 className="text-sm font-body font-medium text-muted-foreground mb-2">
                Recent Searches
              </h4>
              <div className="space-y-1">
                {recentSearches?.map((search, index) => (
                  <button
                    key={index}
                    onClick={() => onSuggestionClick(search)}
                    className="flex items-center w-full px-2 py-2 text-left hover:bg-muted/50 rounded-md transition-colors group"
                  >
                    <Icon name="Clock" size={14} className="mr-3 text-muted-foreground" />
                    <span className="text-sm text-popover-foreground">{search}</span>
                    <Icon 
                      name="ArrowUpRight" 
                      size={12} 
                      className="ml-auto text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" 
                    />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Trending Searches */}
          <div>
            <h4 className="text-sm font-body font-medium text-muted-foreground mb-2">
              Trending Now
            </h4>
            <div className="space-y-1">
              {trendingSearches?.map((search, index) => (
                <button
                  key={index}
                  onClick={() => onSuggestionClick(search)}
                  className="flex items-center w-full px-2 py-2 text-left hover:bg-muted/50 rounded-md transition-colors group"
                >
                  <Icon name="TrendingUp" size={14} className="mr-3 text-primary" />
                  <span className="text-sm text-popover-foreground">{search}</span>
                  <Icon 
                    name="ArrowUpRight" 
                    size={12} 
                    className="ml-auto text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" 
                  />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (filteredSuggestions?.length === 0) return null;

  return (
    <div className="absolute top-full left-0 right-0 mt-2 bg-popover border border-border rounded-lg shadow-elevation-2 z-1500 animate-slide-down">
      <div className="py-2">
        {filteredSuggestions?.map((suggestion, index) => (
          <button
            key={index}
            onClick={() => onSuggestionClick(suggestion)}
            className="flex items-center w-full px-4 py-2 text-left hover:bg-muted/50 transition-colors group"
          >
            <Icon name="Search" size={14} className="mr-3 text-muted-foreground" />
            <span className="text-sm text-popover-foreground">{suggestion}</span>
            <Icon 
              name="ArrowUpRight" 
              size={12} 
              className="ml-auto text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" 
            />
          </button>
        ))}
        
        <div className="border-t border-border mt-2 pt-2">
          <button
            onClick={() => onSuggestionClick(query)}
            className="flex items-center w-full px-4 py-2 text-left hover:bg-muted/50 transition-colors text-primary"
          >
            <Icon name="Search" size={14} className="mr-3" />
            <span className="text-sm font-body font-medium">
              Search for "{query}"
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default SearchSuggestions;