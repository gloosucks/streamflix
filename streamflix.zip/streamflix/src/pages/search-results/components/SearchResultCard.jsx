import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const SearchResultCard = ({ content }) => {
  const [isInWatchlist, setIsInWatchlist] = useState(content?.inWatchlist || false);
  const [isHovered, setIsHovered] = useState(false);
  const navigate = useNavigate();

  const handlePlayClick = () => {
    navigate(`/video-player?id=${content?.id}&title=${encodeURIComponent(content?.title)}`);
  };

  const handleWatchlistToggle = () => {
    setIsInWatchlist(!isInWatchlist);
    // Here you would typically make an API call to update the watchlist
  };

  const handleCardClick = () => {
    // Navigate to content details or start playing
    handlePlayClick();
  };

  const getRatingColor = (rating) => {
    if (rating >= 8.0) return 'text-success';
    if (rating >= 7.0) return 'text-warning';
    if (rating >= 6.0) return 'text-accent';
    return 'text-muted-foreground';
  };

  const getContentTypeIcon = (type) => {
    switch (type) {
      case 'movie': return 'Film';
      case 'tv-show': return 'Tv';
      case 'documentary': return 'FileText';
      case 'anime': return 'Sparkles';
      default: return 'Play';
    }
  };

  return (
    <div 
      className="group bg-card border border-border rounded-lg overflow-hidden hover:border-primary/50 transition-all duration-300 cursor-pointer hover-scale"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={handleCardClick}
    >
      {/* Thumbnail */}
      <div className="relative aspect-video overflow-hidden">
        <Image
          src={content?.thumbnail}
          alt={content?.title}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
        />
        
        {/* Overlay */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-all duration-300 flex items-center justify-center">
          <div className={`transform transition-all duration-300 ${isHovered ? 'scale-100 opacity-100' : 'scale-75 opacity-0'}`}>
            <Button
              variant="default"
              size="icon"
              onClick={(e) => {
                e?.stopPropagation();
                handlePlayClick();
              }}
              className="w-12 h-12 rounded-full bg-primary/90 hover:bg-primary"
            >
              <Icon name="Play" size={20} color="white" />
            </Button>
          </div>
        </div>

        {/* Content Type Badge */}
        <div className="absolute top-2 left-2">
          <div className="flex items-center space-x-1 px-2 py-1 bg-black/70 rounded-full">
            <Icon 
              name={getContentTypeIcon(content?.type)} 
              size={12} 
              className="text-white" 
            />
            <span className="text-xs text-white font-body font-medium capitalize">
              {content?.type?.replace('-', ' ')}
            </span>
          </div>
        </div>

        {/* Rating Badge */}
        {content?.rating && (
          <div className="absolute top-2 right-2">
            <div className="flex items-center space-x-1 px-2 py-1 bg-black/70 rounded-full">
              <Icon name="Star" size={12} className="text-warning fill-current" />
              <span className="text-xs text-white font-body font-medium">
                {content?.rating?.toFixed(1)}
              </span>
            </div>
          </div>
        )}

        {/* Duration */}
        {content?.duration && (
          <div className="absolute bottom-2 right-2">
            <div className="px-2 py-1 bg-black/70 rounded text-xs text-white font-body">
              {content?.duration}
            </div>
          </div>
        )}
      </div>
      {/* Content Info */}
      <div className="p-4">
        <div className="flex items-start justify-between mb-2">
          <h3 className="text-base font-heading font-semibold text-card-foreground line-clamp-1 group-hover:text-primary transition-colors">
            {content?.title}
          </h3>
          
          <Button
            variant="ghost"
            size="icon"
            onClick={(e) => {
              e?.stopPropagation();
              handleWatchlistToggle();
            }}
            className="h-8 w-8 flex-shrink-0 ml-2"
          >
            <Icon 
              name={isInWatchlist ? "BookmarkCheck" : "Bookmark"} 
              size={16} 
              className={isInWatchlist ? "text-primary" : "text-muted-foreground hover:text-primary"} 
            />
          </Button>
        </div>

        {/* Metadata */}
        <div className="flex items-center space-x-3 mb-2 text-sm text-muted-foreground">
          <span>{content?.year}</span>
          {content?.genre && (
            <>
              <span>•</span>
              <span>{content?.genre}</span>
            </>
          )}
          {content?.rating && (
            <>
              <span>•</span>
              <div className="flex items-center space-x-1">
                <Icon name="Star" size={12} className="text-warning fill-current" />
                <span className={getRatingColor(content?.rating)}>
                  {content?.rating?.toFixed(1)}
                </span>
              </div>
            </>
          )}
        </div>

        {/* Description */}
        <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
          {content?.description}
        </p>

        {/* Action Buttons */}
        <div className="flex items-center space-x-2">
          <Button
            variant="default"
            size="sm"
            onClick={(e) => {
              e?.stopPropagation();
              handlePlayClick();
            }}
            className="flex-1"
          >
            <Icon name="Play" size={14} className="mr-1" />
            Play
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={(e) => {
              e?.stopPropagation();
              // Handle more info action
            }}
          >
            <Icon name="Info" size={14} />
          </Button>
        </div>

        {/* Tags */}
        {content?.tags && content?.tags?.length > 0 && (
          <div className="flex flex-wrap gap-1 mt-3">
            {content?.tags?.slice(0, 3)?.map((tag, index) => (
              <span
                key={index}
                className="px-2 py-1 bg-muted/50 text-xs text-muted-foreground rounded-full"
              >
                {tag}
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default SearchResultCard;